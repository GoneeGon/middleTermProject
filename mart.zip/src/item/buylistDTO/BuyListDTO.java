package item.buylistDTO;

import java.sql.Date;

public class BuyListDTO {
	private int num;		//���Ÿ�Ϲ�ȣ
	private int no;			//ȸ����ȣ
	private int seq;		//��ǰ��ȣ
	private String name;	//��ǰ�̸�
	private int price;		//����
	private int count;		//���ż���
	private Date buytime;	//������
	private int delivery_stmt;	//��ۻ��� 0:�غ��� 1:����� 2:��ۿϷ�
	
	//getter
	public int getNum() {
		return num;
	}
	public int getNo() {
		return no;
	}
	public int getSeq() {
		return seq;
	}
	public String getName() {
		return name;
	}
	public int getPrice() {
		return price;
	}
	public int getCount() {
		return count;
	}
	public Date getBuytime() {
		return buytime;
	}
	public int getDelivery_stmt() {
		return delivery_stmt;
	}
	
	//setter
	public void setNum(int num) {
		this.num = num;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public void setBuytime(Date buytime) {
		this.buytime = buytime;
	}
	public void setDelivery_stmt(int delivery_stmt) {
		this.delivery_stmt = delivery_stmt;
	}
}
