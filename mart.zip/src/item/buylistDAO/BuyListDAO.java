package item.buylistDAO;

import java.sql.*;
import java.util.ArrayList;

import account.LoginForm;
import account.accountDTO.AccountDTO;
import item.buylistDTO.BuyListDTO;
import item.itemDAO.ItemDAO;
import item.itemDTO.ItemDTO;

public class BuyListDAO {
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = LoginForm.getUrl();
	private String user = "java";
	private String password = "itbank";
	
	private static BuyListDAO instance;
	
	public BuyListDAO() {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static BuyListDAO getInstance() {
		if(instance==null) {
			synchronized(BuyListDAO.class) {
				instance = new BuyListDAO();
			}
		}
		return instance;
	}
	
	public Connection getConnection() {
		Connection conn = null;
		
		try {
			conn = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	//��ü ���Ÿ�� ����Ʈ�� ��ȯ
	public ArrayList<BuyListDTO> getBuyList(){
		Connection conn = getConnection();
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from buylist ORDER BY buytime desc";
		ArrayList<BuyListDTO> list = null;
		
		try {
			pstmt = conn.prepareStatement(sql);			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				if(list==null) list = new ArrayList<BuyListDTO>();
				
				BuyListDTO dto = new BuyListDTO();
				
				dto.setNum(rs.getInt("num"));
				dto.setNo(rs.getInt("no"));
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCount(rs.getInt("count"));
				dto.setBuytime(rs.getDate("buytime"));
				dto.setDelivery_stmt(rs.getInt("delivery_stmt"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//ȸ����ȣ�� �ش��ϴ� ���Ÿ�� ����Ʈ�� ��ȯ
	public ArrayList<BuyListDTO> getBuyList(int no){
		Connection conn = getConnection();
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from buylist where no=? ORDER BY buytime desc";
		ArrayList<BuyListDTO> list = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				if(list==null) list = new ArrayList<BuyListDTO>();
				
				BuyListDTO dto = new BuyListDTO();
				
				dto.setNum(rs.getInt("num"));
				dto.setNo(rs.getInt("no"));
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCount(rs.getInt("count"));
				dto.setBuytime(rs.getDate("buytime"));
				dto.setDelivery_stmt(rs.getInt("delivery_stmt"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//no�� 0�̸� ��üȸ�� �˻�
	public ArrayList<BuyListDTO> getBuyList(int no, String start, String end) {
		Connection conn = getConnection();
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "SELECT * FROM buylist WHERE";
			
		if(start.length()==6)
			sql += " (buytime >= TO_DATE(?,'YYYYMMDD') "+
				"AND buytime < TO_DATE(?,'YYYYMMDD')) ";
		else if(start.length()==8) 
			sql += " (buytime >= TO_DATE(?,'YYYYMMDD') "+ 
				"AND buytime < TO_DATE(?,'YYYYMMDD')+1) ";
		
		if(no!=0) sql += " AND no=? ";
		sql += "ORDER BY buytime desc";
		
		ArrayList<BuyListDTO> list = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			if(start.length()==6) {
				pstmt.setString(1, start+"01");
				pstmt.setString(2, end+"01");
			}else if(start.length()==8) {
				pstmt.setString(1, start);
				pstmt.setString(2, end);
			}
			if(no!=0) pstmt.setInt(3, no);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				if(list==null) list = new ArrayList<BuyListDTO>();
				
				BuyListDTO dto = new BuyListDTO();
				
				dto.setNum(rs.getInt("num"));
				dto.setNo(rs.getInt("no"));
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCount(rs.getInt("count"));
				dto.setBuytime(rs.getDate("buytime"));
				dto.setDelivery_stmt(rs.getInt("delivery_stmt"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//��۹�ȣ num�� ��ۻ��¸� stmt�� ����
	public void setDeliveryStmt(int num, int stmt) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		String sql = "update buylist set delivery_stmt=? where num=?";
		
		try {
			ps=conn.prepareStatement(sql);
			ps.setInt(1, stmt);
			ps.setInt(2, num);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
		
	public ArrayList<BuyListDTO> getBuyList(String start, String end, int category) {
		Connection conn = getConnection();
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "SELECT b.* FROM buylist b, item i " + 
				"WHERE i.category=? AND b.seq=i.seq "+
				"AND (b.buytime >= TO_DATE(?,'YYYYMMDD') AND b.buytime < TO_DATE(?,'YYYYMMDD')+1)";
		
		ArrayList<BuyListDTO> list = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, category);
			pstmt.setString(2, start);
			pstmt.setString(3, end);			
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				if(list==null) list = new ArrayList<BuyListDTO>();
				
				BuyListDTO dto = new BuyListDTO();
				
				dto.setNo(rs.getInt("no"));
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCount(rs.getInt("count"));
				dto.setBuytime(rs.getDate("buytime"));
				dto.setDelivery_stmt(rs.getInt("delivery_stmt"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public ArrayList<BuyListDTO> getBuyList(String start, String end) {
		Connection conn = getConnection();
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "SELECT * FROM buylist " + 
				"WHERE (buytime >= TO_DATE(?,'YYYYMMDD') AND buytime < TO_DATE(?,'YYYYMMDD')+1)";
		
		ArrayList<BuyListDTO> list = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, start);
			pstmt.setString(2, end);			
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				if(list==null) list = new ArrayList<BuyListDTO>();
				
				BuyListDTO dto = new BuyListDTO();
				
				dto.setNo(rs.getInt("no"));
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCount(rs.getInt("count"));
				dto.setBuytime(rs.getDate("buytime"));
				dto.setDelivery_stmt(rs.getInt("delivery_stmt"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public int getCount(String start, String end, int category) {
		int count=0;
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select sum(b.count) from buylist b, item i, category c " + 
				"where c.code = ? and c.code=i.category and b.seq=i.seq " + 
				"and (buytime >= TO_DATE(?,'YYYYMMDD')AND buytime < TO_DATE(?,'YYYYMMDD')+1)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, category);
			pstmt.setString(2, start);
			pstmt.setString(3, end);
			rs = pstmt.executeQuery();
			
			rs.next();
			count = rs.getInt(1);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return count;
	}
	
	public int getPrice(String start, String end, int category) {
		int price=0;
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select sum(b.price) from buylist b, item i, category c " + 
				"where c.code = ? and c.code=i.category and b.seq=i.seq " + 
				"and (buytime >= TO_DATE(?,'YYYYMMDD')AND buytime < TO_DATE(?,'YYYYMMDD')+1)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, category);
			pstmt.setString(2, start);
			pstmt.setString(3, end);
			rs = pstmt.executeQuery();
			
			rs.next();
			price = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return price;
	}
	
	public int getCount() {
		int count=0;
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select sum(count) from buylist";
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			rs.next();
			count = rs.getInt(1);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		return count;
	}
	
	public int getPrice() {
		int price=0;
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select sum(price) from buylist";
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			rs.next();
			price = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return price;
	}
	
	//ȸ����ȣno�� dto��ǰ�� num�� �ֹ�
	public int orderItem(int no, ItemDTO dto, int num) {
		int su=0;
		Connection conn = getConnection();
		PreparedStatement ps = null;
		String sql = "insert into buylist values(buylist_seq.nextval, ?, ?, ?, ?, ?, sysdate, 0)";
		//insert into buylist values(buylist_seq.nextval, ȸ����ȣ, ��ǰ��ȣ, ��ǰ��, ����, ����, sysdate, 0);
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, no);
			ps.setInt(2, dto.getSeq());
			ps.setString(3, dto.getName());
			ps.setInt(4, dto.getPrice()*num);
			ps.setInt(5, num);
			
			su = ps.executeUpdate();
			//�ֹ������ϸ� ������� ����
			if(su>0) ItemDAO.getInstance().subQty(num, dto.getSeq());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return su;
	}
	
	//�� ȸ���� ���ŷ�
	public int getCount(int no, String start, String end) {
		Connection conn = getConnection();
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "SELECT count(*) FROM buylist WHERE";
		int su=0;
		
		if(start.length()==6)
			sql += " (buytime >= TO_DATE(?,'YYYYMMDD') "+
				"AND buytime < TO_DATE(?,'YYYYMMDD'))";
		else if(start.length()==8) 
			sql += " (buytime >= TO_DATE(?,'YYYYMMDD') "+ 
				"AND buytime < TO_DATE(?,'YYYYMMDD')+1)";
		
		if(no!=0) sql += " AND no=? ";
		sql += "ORDER BY buytime desc";
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			if(start.length()==6) {
				pstmt.setString(1, start+"01");
				pstmt.setString(2, end+"01");
			}else if(start.length()==8) {
				pstmt.setString(1, start);
				pstmt.setString(2, end);
			}
			if(no!=0) pstmt.setInt(3, no);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				su = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
	
	//ȸ�������� ���Ÿ�Ϻҷ�����
	public ArrayList<BuyListDTO> getBuyList2(AccountDTO dto){
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = " select * from buylist where no=?";
		ArrayList<BuyListDTO> list = null;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, dto.getNo());
			rs = ps.executeQuery();
			
			while(rs.next()) {
				if(list==null) list = new ArrayList<BuyListDTO>();
				
				 BuyListDTO dto1 = new BuyListDTO();
							
				dto1.setNum(rs.getInt("num"));
				dto1.setNo(rs.getInt("no"));
				dto1.setSeq(rs.getInt("seq"));
				dto1.setName(rs.getString("name"));
				dto1.setPrice(rs.getInt("price"));
				dto1.setCount(rs.getInt("count"));
				dto1.setBuytime(rs.getDate("buytime"));
				dto1.setDelivery_stmt(rs.getInt("delivery_stmt"));
			
				list.add(dto1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//��ȸ�� ���Ÿ�� ��������
	public ArrayList<BuyListDTO> getGuestBuyList(AccountDTO dto) {
		//select b.* from account a, buylist b where a.no=b.no and a.name='������' and a.tel1='010'
		//	and a.tel2='9198' and a.tel3='2778' and a.code=2;
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select b.* from account a, buylist b " + 
				"where a.no=b.no and a.name=? and a.tel1=? " + 
				"and a.tel2=? and a.tel3=? and a.code=2";
		ArrayList<BuyListDTO> list = null;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getTel1());
			ps.setString(3, dto.getTel2());
			ps.setString(4, dto.getTel3());
			rs = ps.executeQuery();
			
			while(rs.next()) {
				if(list==null) list=new ArrayList<BuyListDTO>();
				
				BuyListDTO dto1 = new BuyListDTO();
				dto1.setNum(rs.getInt("num"));
				dto1.setNo(rs.getInt("no"));
				dto1.setSeq(rs.getInt("seq"));
				dto1.setName(rs.getString("name"));
				dto1.setPrice(rs.getInt("price"));
				dto1.setCount(rs.getInt("count"));
				dto1.setBuytime(rs.getDate("buytime"));
				dto1.setDelivery_stmt(rs.getInt("delivery_stmt"));
				
				list.add(dto1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//�ش���� �� ����
	public int getMTotal(String year, String month) {
		int mtotal=0;
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select sum(price) from buylist where buytime>=TO_DATE(?,'YYYYMMDD') and buytime<=last_day(?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,year+month+"01");
			pstmt.setString(2,year+month+"01");
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				mtotal=rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return mtotal;
	}
	
	public ArrayList<BuyListDTO> getList(String start, String end, int delivery_stmt) {
		Connection conn = getConnection();
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "SELECT * FROM buylist " + 
				"WHERE delivery_stmt=? AND (buytime >= TO_DATE(?,'YYYYMMDD') AND buytime < TO_DATE(?,'YYYYMMDD')+1)";
		
		ArrayList<BuyListDTO> list = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, delivery_stmt);
			pstmt.setString(2, start);
			pstmt.setString(3, end);			
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				if(list==null) list = new ArrayList<BuyListDTO>();
				
				BuyListDTO dto = new BuyListDTO();
				
				dto.setNo(rs.getInt("no"));
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCount(rs.getInt("count"));
				dto.setBuytime(rs.getDate("buytime"));
				dto.setDelivery_stmt(rs.getInt("delivery_stmt"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
}
