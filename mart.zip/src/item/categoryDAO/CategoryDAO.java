package item.categoryDAO;

import java.sql.*;
import java.util.ArrayList;

import account.LoginForm;
import item.categoryDTO.CategoryDTO;
import item.itemDAO.ItemDAO;
import item.itemDTO.ItemDTO;

public class CategoryDAO {
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = LoginForm.getUrl();
	private String user = "java";
	private String password = "itbank";
	
	private static CategoryDAO instance;
	
	public CategoryDAO() {
		//����̹� �ε�
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}//������
	
	//getInstance�޼ҵ�(synchronized ����)
	public static CategoryDAO getInstance() {
		if(instance==null) {
			synchronized(ItemDAO.class) {
				instance = new CategoryDAO();
			}
		}
		return instance;
	}//getInstacne()
	
	//����-Connection 
	public Connection getConnection() {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	//��ǰ�з� ����Ʈ �ҷ����� �޼ҵ�(JList)
	public ArrayList<CategoryDTO> getCategoryList() {
		ArrayList<CategoryDTO> list = new ArrayList<CategoryDTO>();
		
		//DB����
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from category";
		
		try {
			pstmt = conn.prepareStatement(sql); //sql��  ó��
			rs=pstmt.executeQuery();			//ResultSet rs�� ��� ����
			
			//������ �� ������ list�� �ֱ� 
			while(rs.next()) {
				//dto �����ϰ� rs�� �ִ� �� dto�� �ֱ�
				CategoryDTO dto = new CategoryDTO();
				dto.setCode(rs.getInt("code"));
				dto.setName(rs.getString("name"));
				
				//dto�� list�� �ֱ�
				list.add(dto);
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
			list = null;						//���� �߻��� list�� null�� ����(list �ʱ�ȭ)
		} finally {
			try {
				if(rs!=null)rs.close();
				if(pstmt!=null)pstmt.close();	//1. PreparedStatement ����
				if(conn!=null)conn.close();	//2. Connection ����
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//�ڵ�� ��ǰ�� ��������
	public String getName(int code) {
		String name=null;
		
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select name from category where code = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, code);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				name=rs.getString("name");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return name;
	} 

	//��ǰ������ �ڵ� ��������
	public int getCode(String name) {
		int code=0;
		
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select code from category where name = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				code=rs.getInt("code");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return code;
	}
		
	public boolean checkCategory(int category) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select category from item where category=?";
		boolean result=false;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1,category);
			rs = ps.executeQuery();
			if(rs.next()) result=true;
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	public ArrayList<ItemDTO> getItem_Category(int category){ //����category item ����Ʈ
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from item where category=?";
		ArrayList<ItemDTO> list = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, category);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				if(list==null) list = new ArrayList<ItemDTO>();
				
				ItemDTO dto = new ItemDTO();
				
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCategory(rs.getInt("category"));
				dto.setProduct_qty(rs.getInt("product_qty"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	//�з������� DB�� �ֳ� Ȯ��
		public boolean checkCategoryDB(String name) {
			boolean result=false; 
			
			Connection conn = getConnection();	
			PreparedStatement pstmt =null;
			ResultSet rs =null;
			String sql = "select code from category where name = ?";
			
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, name);
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					result=true;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if(rs!=null) rs.close();
					if(pstmt!=null) pstmt.close();
					if(conn!=null) conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return result;
		}
	
	//DB�� ī�װ����߰�
		public int addCategory(CategoryDTO dto) {
			int su=0;
			Connection conn=getConnection();
			PreparedStatement pstmt=null;
			String sql="insert into category values(category_seq.nextval,?)";
			
			try {
				pstmt=conn.prepareStatement(sql); 
				pstmt.setString(1,dto.getName());
				
				su=pstmt.executeUpdate(); 
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if(pstmt!=null) pstmt.close();
					if(conn!=null) conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return su;
		}
}
