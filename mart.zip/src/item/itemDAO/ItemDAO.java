package item.itemDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import account.LoginForm;
import account.accountDAO.AccountDAO;
import item.itemDTO.ItemDTO;

public class ItemDAO {
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = LoginForm.getUrl();
	private String user = "java";
	private String password = "itbank";
	
	private static ItemDAO instance;
	
	public ItemDAO() {
		//����̹� �ε�
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}//������
	
	//getInstance�޼ҵ�(synchronized ����)
	public static ItemDAO getInstance() {
		if(instance==null) {
			synchronized(ItemDAO.class) {
				instance = new ItemDAO();
			}
		}
		return instance;
	}//getInstacne()
	
	//����-Connection 
	public Connection getConnection() {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	//��ǰ����Ʈ�� ��ǰ �ҷ����� �޼ҵ�(JList)
	public ArrayList<ItemDTO> getItemList() {
		ArrayList<ItemDTO> list = new ArrayList<ItemDTO>();
		
		//DB����
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from item";
		
		try {
			pstmt = conn.prepareStatement(sql); //sql��  ó��
			rs=pstmt.executeQuery();			//ResultSet rs�� ��� ����
			
			//������ �� ������ list�� �ֱ� 
			while(rs.next()) {
				//dto �����ϰ� rs�� �ִ� �� dto�� �ֱ�
				ItemDTO dto = new ItemDTO();
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCategory(rs.getInt("category"));
				dto.setProduct_qty(rs.getInt("product_qty"));	
				dto.setImage(rs.getString("image"));
				
				//dto�� list�� �ֱ�
				list.add(dto);
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
			list = null;						//���� �߻��� list�� null�� ����(list �ʱ�ȭ)
		} finally {
			try {
				if(rs!=null)rs.close();
				if(pstmt!=null)pstmt.close();	//1. PreparedStatement ����
				if(conn!=null)conn.close();	//2. Connection ����
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	//��ǰ����Ʈ�� ��ǰ �ҷ����� �޼ҵ�(JList)
	public ArrayList<ItemDTO> getItemList(int category) {
		ArrayList<ItemDTO> list = new ArrayList<ItemDTO>();
		
		//DB����
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from item where category=?";
		
		try {
			pstmt = conn.prepareStatement(sql); //sql��  ó��
			pstmt.setInt(1, category);
			rs=pstmt.executeQuery();			//ResultSet rs�� ��� ����
			
			//������ �� ������ list�� �ֱ� 
			while(rs.next()) {
				//dto �����ϰ� rs�� �ִ� �� dto�� �ֱ�
				ItemDTO dto = new ItemDTO();
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCategory(rs.getInt("category"));
				dto.setProduct_qty(rs.getInt("product_qty"));	
				dto.setImage(rs.getString("image"));
				
				//dto�� list�� �ֱ�
				list.add(dto);
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
			list = null;						//���� �߻��� list�� null�� ����(list �ʱ�ȭ)
		} finally {
			try {
				if(rs!=null)rs.close();
				if(pstmt!=null)pstmt.close();	//1. PreparedStatement ����
				if(conn!=null)conn.close();	//2. Connection ����
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public boolean checkName(String name) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select name from item where name=?";
		boolean result=false;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1,name);
			rs = ps.executeQuery();
			if(rs.next()) result=true;
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public boolean checkCategory(int category) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select category from item where category=?";
		boolean result=false;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1,category);
			rs = ps.executeQuery();
			if(rs.next()) result=true;
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	public ItemDTO getItem(String name) { //name���� ã�� 
		ItemDTO dto = null;
		
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from item where name = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto = new ItemDTO();
				
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCategory(rs.getInt("category"));
				dto.setProduct_qty(rs.getInt("product_qty"));
				dto.setImage(rs.getString("image"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;
	}
	
	public ArrayList<ItemDTO> getItem_Category(int category){ //����category item ����Ʈ
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from item where category=?";
		ArrayList<ItemDTO> list = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, category);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				if(list==null) list = new ArrayList<ItemDTO>();
				
				ItemDTO dto = new ItemDTO();
				
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCategory(rs.getInt("category"));
				dto.setProduct_qty(rs.getInt("product_qty"));
				dto.setImage(rs.getString("image"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public ItemDTO getItem_Seq(int seq) { //seq�� itemDTO ��������
		ItemDTO dto = null;
		
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from item where seq = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, seq);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto = new ItemDTO();
				
				dto.setSeq(rs.getInt("seq"));
				dto.setName(rs.getString("name"));
				dto.setPrice(rs.getInt("price"));
				dto.setCategory(rs.getInt("category"));
				dto.setProduct_qty(rs.getInt("product_qty"));
				dto.setImage(rs.getString("image"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;
	}

	public int updateItem(ItemDTO dto) {
		int su=0;
		Connection conn=getConnection();
		PreparedStatement pstmt=null;
		String sql="update item set seq=?"
									+",name=?"
									+",price=?"
									+",category=?"
									+",product_qty=? where seq=?";
		try {
			pstmt=conn.prepareStatement(sql); //����
			 
			pstmt.setInt(1,dto.getSeq());
			pstmt.setString(2,dto.getName());
			pstmt.setInt(3,dto.getPrice());
			pstmt.setInt(4,dto.getCategory());
			pstmt.setInt(5,dto.getProduct_qty());
			pstmt.setInt(6, dto.getSeq());
			 
			su=pstmt.executeUpdate(); //����
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}return su;
	}
	
	public int deleteItem(int seq) {
		int su=0;
		Connection conn=getConnection();
		PreparedStatement pstmt=null;
		String sql="delete item where seq=?";
		
		try {
			pstmt=conn.prepareStatement(sql); 
			pstmt.setInt(1,seq);
			su=pstmt.executeUpdate(); 
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
	
	//DB����ǰ�߰�
	public int addItem(ItemDTO dto) {
		int su=0;
		Connection conn=getConnection();
		PreparedStatement pstmt=null;
		String sql="insert into item values(item_seq.nextVal,?,?,?,?,?)";
		
		try {
			pstmt=conn.prepareStatement(sql); 
			pstmt.setString(1,dto.getName());
			pstmt.setInt(2,dto.getPrice());
			pstmt.setInt(3,dto.getCategory());
			pstmt.setInt(4,dto.getProduct_qty());
			pstmt.setString(5,dto.getImage());
			
			su=pstmt.executeUpdate(); 
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
	
	//������� Ȯ�� ������� ��ȯ
	public int checkStock(int seq) {
		int product_qty=0;
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select product_qty from item where seq=?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, seq);
			rs = ps.executeQuery();
			
			if(rs.next()) product_qty=rs.getInt("product_qty");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return product_qty;
	}
	
	//��ǰ��ȣseq�� ������� num�� ����
	public void subQty(int num, int seq) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		String sql = "update item set product_qty=product_qty-? where seq=?";
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, num);
			ps.setInt(2, seq);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//��ǰ��ȣ�� ��ǰ��
	public String getName(int seq) {
		String name=null;
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select name from item where seq = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, seq);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				name=rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return name;
	}
}
