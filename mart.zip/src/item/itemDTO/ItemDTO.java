package item.itemDTO;


public class ItemDTO{
	private int seq;			//��ǰ�ڵ�
	private String name;		//��ǰ�̸�
	private int price;			//��ǰ����
	private int category;		//��ǰ�з�
	private int product_qty;	//��ǰ���
	private String image;		//��ǰ�̹���	
	
	public ItemDTO() {
		
	}//������ 
	
	//setter
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setCategory(int category ) {
		this.category = category ;
	}
	public void setProduct_qty(int product_qty) {
		this.product_qty = product_qty;
	}
	public void setImage(String image) {
		this.image = image;
	}
	

	//getter
	public int getSeq() {
		return seq;
	}
	public String getName() {
		return name;
	}
	public int getPrice() {
		return price;
	}
	public int getCategory() {
		return category;
	}
	public int getProduct_qty() {
		return product_qty;
	}
	public String getImage() {
		return image;
	}
	
	
	@Override
	public String toString() {
		return name+" : " + product_qty;
	}
	
	
}
