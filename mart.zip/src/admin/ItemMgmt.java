package admin;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import item.categoryDAO.CategoryDAO;
import item.categoryDTO.CategoryDTO;
import item.itemDAO.ItemDAO;
import item.itemDTO.ItemDTO;

public class ItemMgmt extends JFrame implements ActionListener {
	private JTable table;
	private DefaultTableModel dtm;
	private Object[] columnNames = {"��ǰ�ڵ�", "��ǰ�̸�", "��ǰ����", "��ǰ�з�", "��ǰ���"};
	private Object[][] data = null;
	private JButton everySearchB;
	private JTextField searchT;
	private JButton searchB;
	private JButton updateB;
	private JButton deleteB;
	private JButton addItemB;
	private JComboBox<String> box;
	public MainPage_Admin mainPage;
	
	public ItemMgmt(MainPage_Admin mainPage) {
		this.mainPage = mainPage;
		
		getContentPane().setLayout(null);
		
		JScrollPane tableScroll = new JScrollPane();
		tableScroll.setBounds(0, 0, 484, 502);
		getContentPane().add(tableScroll);
		
		dtm = new DefaultTableModel(data, columnNames) {
			@Override
			public boolean isCellEditable(int row, int column) {
				boolean check=true;
				if(column==0 || column==3) check=false; //��ǰ�ڵ�� ��ǰ�з��� �����Ұ�
				return check;
			}
		};
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 501, 484, 61);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		everySearchB = new JButton("��ü���");
		everySearchB.setBounds(30, 5, 91, 26);
		
		everySearchB.setHorizontalAlignment(SwingConstants.LEADING);
		panel.add(everySearchB);
		
		String[] data= {"��ǰ��","��ǰ�з���"};
		box = new JComboBox(data);
		box.setBounds(189, 6, 86, 21);
		panel.add(box);
		
		searchT = new JTextField();
		searchT.setBounds(277, 6, 116, 21);
		panel.add(searchT);
		searchT.setColumns(10);
		
		searchB = new JButton("�˻�");
		searchB.setBounds(394, 5, 62, 25);
		panel.add(searchB);
		
		updateB=new JButton("����");
		updateB.setBounds(304, 32, 68, 25);
		panel.add(updateB);
		
		deleteB=new JButton("����");
		deleteB.setBounds(374, 32, 68, 25);
		panel.add(deleteB);
		
		addItemB=new JButton("��ǰ���");
		addItemB.setBounds(215,32,88,25);
		panel.add(addItemB);
		
		table = new JTable(dtm);
		tableScroll.setViewportView(table);
		setList();
		
		setTitle("��� ����");
		setBounds(100,100,500,600);
		setVisible(true);
		//setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		event();
	}
	
	public void setList() {
		dtm.setRowCount(0);
		ArrayList<ItemDTO> list = ItemDAO.getInstance().getItemList();
		if(list!=null) {
			for(ItemDTO dto : list) {
				Object[] rowData = setRowData(dto);
				dtm.addRow(rowData);
			}
		}
	}
	
	public Object[] setRowData(ItemDTO dto) {
		String seq=dto.getSeq()+"";
		String name=dto.getName();
		String price=dto.getPrice()+"";
		String category=CategoryDAO.getInstance().getName(dto.getCategory());
		String product_qty=dto.getProduct_qty()+"";
		
		Object[] rowData = {seq, name, price, category, product_qty};
		return rowData;
	}
	
	public void event() {
		everySearchB.addActionListener(this);
		searchB.addActionListener(this); // ��ǰ�̸� or ��ǰ�з� ��ȣ �Է� -> ���߿� ��ǰ�з������μ���(��ȣ����)
		updateB.addActionListener(this);
		deleteB.addActionListener(this);
		searchT.addActionListener(this);
		addItemB.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==everySearchB)	setList(); //��ü���
		
		if(e.getSource()==searchB || e.getSource()==searchT) { //�˻�
			String name=null;
			int category=0;
			
			if(searchT.getText().equals(""))
				JOptionPane.showMessageDialog(this, "�Է��Ͻð� ��������", "�˻� ����", JOptionPane.INFORMATION_MESSAGE);
			else {
				if(box.getSelectedIndex()==0 || box.getSelectedIndex()==-1) {
					name=searchT.getText();
					if(ItemDAO.getInstance().checkName(name)) { //name���� �˻�
						ItemDTO dto = ItemDAO.getInstance().getItem(name);
						dtm.setRowCount(0);
						dtm.addRow(setRowData(dto));
					}else 
						JOptionPane.showMessageDialog(this, "�ش� ��ǰ�� �����ϴ�", "�˻� ����", JOptionPane.INFORMATION_MESSAGE);
				}
				if(box.getSelectedIndex()==1) {
					category=CategoryDAO.getInstance().getCode(searchT.getText());
					if(ItemDAO.getInstance().checkCategory(category)) { //catetory�� �˻�
						ArrayList<ItemDTO> list = ItemDAO.getInstance().getItem_Category(category);
						dtm.setRowCount(0);
						if(list!=null) {
							for(ItemDTO dto : list) {
								Object[] rowData = setRowData(dto);
								dtm.addRow(rowData);
							}
						}
					}else 
						JOptionPane.showMessageDialog(this, "�ش� ��ǰ�� �����ϴ�", "�˻� ����", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		}
		if(e.getSource()==updateB) { //����
			int row=table.getSelectedRow();
			int seq=Integer.parseInt((String)table.getValueAt(row, 0));
			
			ItemDTO dto=ItemDAO.getInstance().getItem_Seq(seq);
			
			dto.setSeq(Integer.parseInt((String)table.getValueAt(row, 0)));
			dto.setName((String) table.getValueAt(row, 1));
			dto.setPrice(Integer.parseInt((String)table.getValueAt(row, 2)));
			dto.setCategory(CategoryDAO.getInstance().getCode((String)table.getValueAt(row, 3)));
			dto.setProduct_qty(Integer.parseInt((String)table.getValueAt(row, 4)));
			
			int su=ItemDAO.getInstance().updateItem(dto);
			
			setList();
			JOptionPane.showMessageDialog(this, su+"�� ��ǰ�� ���� �Ǿ����ϴ�", "���� �Ϸ�", JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getSource()==deleteB) {
			int row=table.getSelectedRow();
			int seq=Integer.parseInt((String)table.getValueAt(row, 0));
			int su=ItemDAO.getInstance().deleteItem(seq);
			
			setList();
			JOptionPane.showMessageDialog(this, su+"�� ��ǰ�� ���� �Ǿ����ϴ�", "���� �Ϸ�", JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getSource()==addItemB) {
			new AddItem(this);
		}
		
	}	
}























