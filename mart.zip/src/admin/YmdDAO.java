package admin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import account.LoginForm;
import admin.YmdDTO;

public class YmdDAO {

	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = LoginForm.getUrl();
	private String user = "java";
	private String password = "itbank";
	
	private static YmdDAO instance;
	
	public YmdDAO() {
		//����̹� �ε�
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static YmdDAO getInstance() {
		if(instance==null) {
			synchronized(YmdDAO.class) {
				instance = new YmdDAO();
			}
		}
		return instance;
	}

	public Connection getConnection() {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	//������ �� dto�� ����
	public YmdDTO setLastday(YmdDTO dto) {
		int lastday=0;
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select substr(last_day(?), 7)  from dual";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,dto.getYear()+"-"+dto.getMonth()+"-01");
			rs=pstmt.executeQuery();	
			
			
			while(rs.next()) {
				dto.setLastday(rs.getString(1));
				
			}//while
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)rs.close();
				if(pstmt!=null)pstmt.close();	//1. PreparedStatement ����
				if(conn!=null)conn.close();	//2. Connection ����
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;
	}

}