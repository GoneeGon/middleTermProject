package admin;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Vector;
import java.util.regex.Pattern;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;
import item.buylistDAO.BuyListDAO;
import item.buylistDTO.BuyListDTO;
import item.categoryDAO.CategoryDAO;
import item.categoryDTO.CategoryDTO;

public class SalesMgmt extends JFrame implements ActionListener, ItemListener {
	private static int no; // ȸ����ȣ
	private JPanel contentPane;
	private JComboBox<String>  yearC1, monthC1, dayC1, yearC2, monthC2, dayC2;
	private JComboBox<CategoryDTO> categC;
	private JButton searchB;
	private JScrollPane tableScroll;
	private JTable table;
	private DefaultTableModel dtm;
	private Object[] columnNames = {"������", "ȸ����ȣ","���̵�", "��ǰ��", "����", "����"};
	private Object[][] data = null;
	private JTextField totQT, totPT;
	private JButton wholeSearchB;
	private String[] dayList;
	private String[] dayList2;
	
	
	public SalesMgmt() {
		setTitle("�������");
		AccountDTO dto = AccountDAO.getInstance().getAccount(no);
		setBounds(100,100,750,600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		Vector<CategoryDTO> categList = new Vector<CategoryDTO>();
		ArrayList<CategoryDTO> list2= CategoryDAO.getInstance().getCategoryList();
		CategoryDTO tempDto = new CategoryDTO();
		tempDto.setCode(-1);
		tempDto.setName("��ü");
		categList.addElement(tempDto);
		for(CategoryDTO dto2 : list2) {
			categList.addElement(dto2);
		}
		
		String[] yearList = new String[] {"-", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010"};
		String[] monthList = new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
		String[] dayList = new String[] {"-"};
		
		wholeSearchB = new JButton("\uC804\uCCB4\uC870\uD68C");
		panel.add(wholeSearchB);
		JLabel categL = new JLabel("��ǰ");
		categL.setFont(new Font("����", Font.BOLD, 12));
		panel.add(categL);
		categC = new JComboBox<CategoryDTO>();
		categC.setModel(new DefaultComboBoxModel<CategoryDTO>(categList));
		panel.add(categC);
		
		yearC1 = new JComboBox<String>();
		yearC1.setModel(new DefaultComboBoxModel<String>(yearList));
		panel.add(yearC1);
		
		JLabel yearL = new JLabel("��");
		yearL.setFont(new Font("����", Font.BOLD, 12));
		panel.add(yearL);
		
		monthC1 = new JComboBox<String>();
		monthC1.setModel(new DefaultComboBoxModel<String>(monthList));
		panel.add(monthC1);
		
		JLabel monthL = new JLabel("��");
		monthL.setFont(new Font("����", Font.BOLD, 12));
		panel.add(monthL);
		
		
		dayC1 = new JComboBox<String>();
		dayC1.setModel(new DefaultComboBoxModel<String>(dayList));
		panel.add(dayC1);
		
		JLabel dayL = new JLabel("�� ~ ");
		dayL.setFont(new Font("����", Font.BOLD,12));
		panel.add(dayL);
		
		yearC2 = new JComboBox<String>(new DefaultComboBoxModel<String>(yearList));
		panel.add(yearC2);
		
		JLabel yearL2 = new JLabel("��");
		yearL2.setFont(new Font("����", Font.BOLD, 12));
		panel.add(yearL2);
		
		monthC2 = new JComboBox<String>(new DefaultComboBoxModel<String>(monthList));
		panel.add(monthC2);
		
		JLabel monthL2 = new JLabel("��");
		monthL2.setFont(new Font("����", Font.BOLD, 12));
		panel.add(monthL2);
		
		dayC2 = new JComboBox<String>(new DefaultComboBoxModel<String>(dayList));
		panel.add(dayC2);
		
		JLabel dayL2 = new JLabel("��");
		dayL2.setFont(new Font("����", Font.BOLD, 12));
		panel.add(dayL2);
		
		searchB= new JButton("��ȸ");
		panel.add(searchB);
		
		JPanel panel2 = new JPanel();
		contentPane.add(panel2, BorderLayout.SOUTH);
		
		JLabel totQL = new JLabel("���Ǹŷ�");
		totQL.setFont(new Font("����", Font.BOLD, 12));
		totQT = new JTextField(10);
		
		JLabel totPL = new JLabel("���Ǹűݾ�");
		totPL.setFont(new Font("����", Font.BOLD, 12));
		totPT = new JTextField(10);
		
		panel2.add(totQL);
		panel2.add(totQT);
		panel2.add(totPL);
		panel2.add(totPT);
		
		tableScroll = new JScrollPane();
		contentPane.add(tableScroll,BorderLayout.CENTER);
		
		dtm = new DefaultTableModel(data, columnNames) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table = new JTable(dtm);
		tableScroll.setViewportView(table);
		
		//���Ϸ� ����
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		yearC1.setSelectedItem(year+"");
		monthC1.setSelectedIndex(month);
		dayC1.setSelectedIndex(0);
		yearC2.setSelectedItem(year+"");
		monthC2.setSelectedIndex(month);
		dayC2.setSelectedIndex(0);
		
		setList(BuyListDAO.getInstance().getBuyList());
		setVisible(true);
		
		event();
		
	}
	
	private void setList(ArrayList<BuyListDTO> list) {
		dtm.setRowCount(0);
		int totalPrice=0, totalCount=0;
		
		if(list!=null) {
			for(BuyListDTO dto : list) {
				Object[] rowData = setRowData(dto);
				dtm.addRow(rowData);
				totalPrice += dto.getPrice();
				totalCount += dto.getCount();
			}
		}
		totQT.setText(totalCount+"");
		totPT.setText(totalPrice+"");
	}

	private Object[] setRowData(BuyListDTO dto) {
		Date buytime = dto.getBuytime();
		int no = dto.getNo();
		String name = dto.getName();
		int count = dto.getCount();
		int price = dto.getPrice();
		AccountDTO accountDto = AccountDAO.getInstance().getAccount(no);
		String id = null;
		if(accountDto==null) {
			id = "Ż����ȸ��";
		}else {
			id = accountDto.getId();
		}
		
		Object[] rowDate = {buytime, no, id, name, count, price};
		return rowDate;
	}

	private void event() {
		searchB.addActionListener(this);
		wholeSearchB.addActionListener(this);
		yearC1.addItemListener(this);
		yearC2.addItemListener(this);
		monthC1.addItemListener(this);
		monthC2.addItemListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==searchB) {
			setPeriod(); //�Ⱓ ���� ����
			String year = (String)yearC1.getSelectedItem();
			String year2 = (String)yearC2.getSelectedItem();
			String month = (String)monthC1.getSelectedItem();
			String month2 = (String)monthC2.getSelectedItem();
			String day = (String)dayC1.getSelectedItem();
			String day2 = (String)dayC2.getSelectedItem();
			
			CategoryDTO dto2 = (CategoryDTO)categC.getSelectedItem();
			
			if(day.equals("-") || day2.equals("-")) {
				day="01";
				day2= YmdDAO.getInstance().setLastday(new YmdDTO(year2, month2)).getLastday();
			}
			ArrayList<BuyListDTO> list=null;
			if(dto2.getCode()==-1)
				list = BuyListDAO.getInstance().getBuyList(year+month+day, year2+month2+day2);
			else
				list = BuyListDAO.getInstance().getBuyList(year+month+day, year2+month2+day2, dto2.getCode());
			setList(list);
		}else if(e.getSource()==wholeSearchB) {
			setList(BuyListDAO.getInstance().getBuyList());
		}
	}
	
	//���۳�¥�� ��������¥�� �Ⱓ�������� ����ִ� �޼ҵ�
	private void setPeriod() {
		int year = Integer.parseInt((String)yearC1.getSelectedItem());
		int month = Integer.parseInt((String)monthC1.getSelectedItem());		
		int year2 = Integer.parseInt((String)yearC2.getSelectedItem());
		int month2 = Integer.parseInt((String)monthC2.getSelectedItem());		
		if(year>year2) yearC2.setSelectedItem(yearC1.getSelectedItem());
		if(month>month2) monthC2.setSelectedItem(monthC1.getSelectedItem());
		
		String dayS = (String)dayC1.getSelectedItem();
		String day2S = (String)dayC2.getSelectedItem();
		if(dayS.equals("-") || day2S.equals("-")) {
			dayC1.setSelectedItem("-");
			dayC2.setSelectedItem("-");
		}else {
			int day = Integer.parseInt((String)dayC1.getSelectedItem());
			int day2 = Integer.parseInt((String)dayC2.getSelectedItem());
			if(day>day2) dayC2.setSelectedItem(dayC1.getSelectedItem());
		}
	}
	
	//daylist �� �ֱ�
	public String[] setDayList(YmdDTO dto) {
		int su=Integer.parseInt(dto.getLastday());
		dayList=new String[su+1];
		for(int i=0;i<=su;i++) {
			if(i==0) {
				dayList[0]="-";
			}else {
				dayList[i]=i+"";
			}		
		}
		return dayList;
	}

	@Override
	public void itemStateChanged(ItemEvent i) {
		if(i.getSource()==monthC1 || i.getSource()==yearC1) {
			YmdDTO dto=new YmdDTO();
			if(monthC1.getSelectedIndex()==-1) {
				dto.setMonth(01+"");
			}else {
				dto.setYear((String)yearC1.getSelectedItem());
				dto.setMonth((String)monthC1.getSelectedItem());
				YmdDAO dao=YmdDAO.getInstance();
				dto=dao.setLastday(dto);
				dayList=setDayList(dto);
				dayC1.setModel(new DefaultComboBoxModel<String>(dayList));
				dayC1.updateUI();
			}
			
		}if(i.getSource()==monthC2 || i.getSource()==yearC2) {
			YmdDTO dto=new YmdDTO();
			if(monthC2.getSelectedIndex()==-1) {
				dto.setMonth(01+"");
			}else {
				dto.setYear((String)yearC2.getSelectedItem());
				dto.setMonth((String)monthC2.getSelectedItem());
				YmdDAO dao=YmdDAO.getInstance();
				dto=dao.setLastday(dto);
				dayList2=setDayList(dto);
				dayC2.setModel(new DefaultComboBoxModel<String>(dayList2));
				dayC2.updateUI();
			}
		}
	}
	
	public static void main(String[] args) {
		new SalesMgmt();
	}
}











