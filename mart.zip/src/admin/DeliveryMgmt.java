package admin;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;
import item.buylistDAO.BuyListDAO;
import item.buylistDTO.BuyListDTO;
import item.categoryDAO.CategoryDAO;

public class DeliveryMgmt extends JFrame implements ActionListener, ListSelectionListener, ItemListener {
	private static int no; // ȸ����ȣ
	private JPanel contentPane;
	private JComboBox<String> categC, yearC1, monthC1, dayC1, yearC2, monthC2, dayC2;
	private JButton searchB;
	private JButton deliveryB;
	private JButton deliveryCB;
	private JScrollPane tableScroll;
	private JTable table;
	private Object[] columnNames = {"�ֹ���ȣ","���̵�", "�̸�", "�ּ�","��ȭ��ȣ", "��ǰ ��ȣ", "��ǰ �̸�","�� ��","���ż���","������","��ۻ���"};
	private Object[][] data = null;
	private DefaultTableModel dtm;
	private JButton wholeSearchB;
	private String[] dayList;
	private String[] dayList2;
	private JComboBox<String> comboBox;
	
	
	public DeliveryMgmt() {
		setTitle("��� ����");
		AccountDTO dto = AccountDAO.getInstance().getAccount(no);
		setBounds(100,100,850,600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		String[] yearList = new String[] {"-", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010"};
		String[] monthList = new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
		String[] dayList = new String[] {"-"};
		
		wholeSearchB = new JButton("\uC804\uCCB4\uC870\uD68C");
		panel.add(wholeSearchB);
		
		String[] stateList = new String[] {"��ü", "�غ���", "�����", "��ۿϷ�", "���"};
		comboBox = new JComboBox<String>(new DefaultComboBoxModel<String>(stateList));
		panel.add(comboBox);
		
		
		yearC1 = new JComboBox<String>();
		yearC1.setModel(new DefaultComboBoxModel<String>(yearList));
		panel.add(yearC1);
		
		JLabel yearL = new JLabel("��");
		yearL.setFont(new Font("����", Font.BOLD, 12));
		panel.add(yearL);
		
		monthC1 = new JComboBox<String>();
		monthC1.setModel(new DefaultComboBoxModel<String>(monthList));
		panel.add(monthC1);
		
		JLabel monthL = new JLabel("��");
		monthL.setFont(new Font("����", Font.BOLD, 12));
		panel.add(monthL);
		
		dayC1 = new JComboBox<String>();
		dayC1.setModel(new DefaultComboBoxModel<String>(dayList));
		panel.add(dayC1);
		
		JLabel dayL = new JLabel("�� ~ ");
		dayL.setFont(new Font("����", Font.BOLD,12));
		panel.add(dayL);
		
		yearC2 = new JComboBox<String>(new DefaultComboBoxModel<String>(yearList));
		panel.add(yearC2);
		
		JLabel yearL2 = new JLabel("��");
		yearL2.setFont(new Font("����", Font.BOLD, 12));
		panel.add(yearL2);
		
		monthC2 = new JComboBox<String>(new DefaultComboBoxModel<String>(monthList));
		panel.add(monthC2);
		
		JLabel monthL2 = new JLabel("��");
		monthL2.setFont(new Font("����", Font.BOLD, 12));
		panel.add(monthL2);
		
		dayC2 = new JComboBox<String>(new DefaultComboBoxModel<String>(dayList));
		panel.add(dayC2);
		
		JLabel dayL2 = new JLabel("��");
		dayL2.setFont(new Font("����", Font.BOLD, 12));
		panel.add(dayL2);
		
		searchB= new JButton("��ȸ");
		panel.add(searchB);
		
		deliveryB = new JButton("���");
		panel.add(deliveryB);
		
		deliveryCB= new JButton("��� �Ϸ�");
		panel.add(deliveryCB);
		
		tableScroll = new JScrollPane();
		contentPane.add(tableScroll,BorderLayout.CENTER);
		
		dtm = new DefaultTableModel(data, columnNames) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table = new JTable(dtm);
		tableScroll.setViewportView(table);
		
		//���Ϸ� ����
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		yearC1.setSelectedItem(year+"");
		monthC1.setSelectedIndex(month);
		dayC1.setSelectedIndex(0);
		yearC2.setSelectedItem(year+"");
		monthC2.setSelectedIndex(month);
		dayC2.setSelectedIndex(0);
		
		deliveryB.setEnabled(false);
		deliveryCB.setEnabled(false);
		
		setList();
		setVisible(true);
		
		event();
	}
	
	//��ü ��۳������� ����
	public void setList() {
		dtm.setRowCount(0);
		ArrayList<BuyListDTO> list = BuyListDAO.getInstance().getBuyList();
		
		AccountDAO accountDao = AccountDAO.getInstance();
		
		if(list!=null) {
			for(BuyListDTO dto : list) {
				int no = dto.getNo();
				AccountDTO dto2 = accountDao.getAccount(no);
				dtm.addRow(setRowData(dto, dto2));
			}
		}
	}
	
	//���õ� ��۳������� ����
	public void setList(ArrayList<BuyListDTO> list) {
		dtm.setRowCount(0);
		AccountDAO accountDao = AccountDAO.getInstance();
		
		if(list!=null) {
			for(BuyListDTO dto : list) {
				int no = dto.getNo();
				AccountDTO dto2 = accountDao.getAccount(no);
				dtm.addRow(setRowData(dto, dto2));
			}
		}
	}
		
	
	public Object[] setRowData(BuyListDTO dto, AccountDTO dto2) {
		int num = dto.getNum();
		if(dto2==null) {
			dto2 = new AccountDTO();
			dto2.setId("Ż����ȸ��");
			dto2.setName("Ż����ȸ��");
			dto2.setTel1("");
			dto2.setTel2("");
			dto2.setTel3("");
			dto2.setAddress1("");
			dto2.setAddress2("");
		}
		String id = dto2.getId();
		int seq = dto.getSeq();
		String name = dto.getName();
		String name2 = dto2.getName();
		int price = dto.getPrice();
		int count = dto.getCount();
		Date buytime = dto.getBuytime();
		String tel = dto2.getTel1()+"-"+dto2.getTel2()+"-"+dto2.getTel3();
		String address = dto2.getAddress1()+" "+dto2.getAddress2();
		int delivery_stmt = dto.getDelivery_stmt();
		String delivery=null;
		if (delivery_stmt == 0) {
			delivery = "�غ���";
		}else if(delivery_stmt == 1) {
			delivery = "�����";
		}else if(delivery_stmt == 2) {
			delivery = "��ۿϷ�";
		}else if(delivery_stmt == 3) {
			delivery = "���";
		}
		Object[] rowData = {num, id, name2, address, tel, seq, name, price, count, buytime, delivery};
		return rowData;
	}
	public void event() {
		searchB.addActionListener(this);
		deliveryB.addActionListener(this);
		deliveryCB.addActionListener(this);
		table.getSelectionModel().addListSelectionListener(this);
		wholeSearchB.addActionListener(this);
		monthC1.addItemListener(this);
		monthC2.addItemListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==searchB) {
			setPeriod();
			String year = (String)yearC1.getSelectedItem();
			String year2 = (String)yearC2.getSelectedItem();
			String month = (String)monthC1.getSelectedItem();
			String month2 = (String)monthC2.getSelectedItem();
			String day = (String)dayC1.getSelectedItem();
			String day2 = (String)dayC2.getSelectedItem();
			
			if(day.equals("-") || day2.equals("-")) {
				day="01";
				day2= YmdDAO.getInstance().setLastday(new YmdDTO(year2, month2)).getLastday();
			}else {
				if(day.length()==1) day = "0"+day;
				if(day2.length()==1) day2 = "0"+day2;
			}
			
			ArrayList<BuyListDTO> list = null;
			
			if(comboBox.getSelectedIndex()==0) { //��ü
				list = BuyListDAO.getInstance().getBuyList(0,  year+month+day, year2+month2+day2);
			}else if(comboBox.getSelectedIndex()==1) {//�غ���
				list = BuyListDAO.getInstance().getList(year+month+day, year2+month2+day2, comboBox.getSelectedIndex()-1);
			}else if(comboBox.getSelectedIndex()==2) {//�����
				list = BuyListDAO.getInstance().getList(year+month+day, year2+month2+day2, comboBox.getSelectedIndex()-1);
			}else if(comboBox.getSelectedIndex()==3) {//��ۿϷ�
				list = BuyListDAO.getInstance().getList(year+month+day, year2+month2+day2, comboBox.getSelectedIndex()-1);
			}else if(comboBox.getSelectedIndex()==4) {//���
				list = BuyListDAO.getInstance().getList(year+month+day, year2+month2+day2, comboBox.getSelectedIndex()-1);
			}

			setList(list);
		}else if(e.getSource()==deliveryB) {
			int row = table.getSelectedRow();
			int num = (int)table.getValueAt(row, 0); //�ֹ���ȣ			
			BuyListDAO.getInstance().setDeliveryStmt(num, 1);
			setList();
		}else if(e.getSource()==deliveryCB) {
			int row = table.getSelectedRow();
			int num = (int)table.getValueAt(row, 0); //�ֹ���ȣ			
			BuyListDAO.getInstance().setDeliveryStmt(num, 2);
			setList();
		}else if(e.getSource()==wholeSearchB) {
			setList();
		}
	}
	
	private void setPeriod() {
		int year = Integer.parseInt((String)yearC1.getSelectedItem());
		int month = Integer.parseInt((String)monthC1.getSelectedItem());
		int year2 = Integer.parseInt((String)yearC2.getSelectedItem());
		int month2 = Integer.parseInt((String)monthC2.getSelectedItem());
		if(year>year2) yearC2.setSelectedItem(yearC1.getSelectedItem());
		if(month>month2) monthC2.setSelectedItem(monthC1.getSelectedItem());
		
		String dayS = (String)dayC1.getSelectedItem();
		String day2S = (String)dayC2.getSelectedItem();
		if(dayS.equals("-") || day2S.equals("-")) {
			dayC1.setSelectedItem("-");
			dayC2.setSelectedItem("-");
		}else {
			int day = Integer.parseInt((String)dayC1.getSelectedItem());
			int day2 = Integer.parseInt((String)dayC2.getSelectedItem());
			if(day>day2) dayC2.setSelectedItem(dayC1.getSelectedItem());
		}
	}
	
	@Override
	public void valueChanged(ListSelectionEvent e) {
		int row = table.getSelectedRow();
		if(dtm.getRowCount() > 0 && row >= 0) {
			String stmt = (String)table.getValueAt(row, 10);
			int delivery_stmt=0;
			if(stmt.equals("�غ���"))
				delivery_stmt=0;
			else if(stmt.equals("�����"))
				delivery_stmt=1;
			else if(stmt.equals("��ۿϷ�"))
				delivery_stmt=2;
			else if(stmt.equals("���"))
				delivery_stmt=3;
			
			if(delivery_stmt==0) {
				deliveryB.setEnabled(true);
				deliveryCB.setEnabled(false);
			}else if(delivery_stmt==1) {
				deliveryB.setEnabled(false);
				deliveryCB.setEnabled(true);
			}else if(delivery_stmt==2 || delivery_stmt==3) {
				deliveryB.setEnabled(false);
				deliveryCB.setEnabled(false);
			}
		}
	}
	
	public String[] setDayList(YmdDTO dto) {
		int su=Integer.parseInt(dto.getLastday());
		dayList=new String[su+1];
		for(int i=0;i<=su;i++) {
			if(i==0) {
				dayList[0]="-";
			}else {
				dayList[i]=i+"";
			}		
		}
		return dayList;
	}

	@Override
	public void itemStateChanged(ItemEvent i) {
		if(i.getSource()==monthC1 || i.getSource()==yearC1) {
			YmdDTO dto=new YmdDTO();
			if(monthC1.getSelectedIndex()==-1) {
				dto.setMonth(01+"");
			}else {
				dto.setYear((String)yearC1.getSelectedItem());
				dto.setMonth((String)monthC1.getSelectedItem());
				YmdDAO dao=YmdDAO.getInstance();
				dto=dao.setLastday(dto);
				dayList=setDayList(dto);
				dayC1.setModel(new DefaultComboBoxModel<String>(dayList));
				dayC1.updateUI();
			}
			
		}if(i.getSource()==monthC2 || i.getSource()==yearC2) {
			YmdDTO dto=new YmdDTO();
			if(monthC2.getSelectedIndex()==-1) {
				dto.setMonth(01+"");
			}else {
				dto.setYear((String)yearC2.getSelectedItem());
				dto.setMonth((String)monthC2.getSelectedItem());
				YmdDAO dao=YmdDAO.getInstance();
				dto=dao.setLastday(dto);
				dayList2=setDayList(dto);
				dayC2.setModel(new DefaultComboBoxModel<String>(dayList2));
				dayC2.updateUI();
			}
		}
	}
	
	
	public static void main(String[] args) {
		new DeliveryMgmt();
	}
	
}