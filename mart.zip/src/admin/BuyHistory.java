package admin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;
import item.buylistDAO.BuyListDAO;
import item.buylistDTO.BuyListDTO;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.JScrollPane;
import javax.swing.JTable;

public class BuyHistory extends JFrame implements ActionListener {
	private int no; //ȸ����ȣ
	private JPanel contentPane;
	private JComboBox<String> yearC;
	private JComboBox<String> monthC;
	private JComboBox<String> yearC2;
	private JComboBox<String> monthC2;
	private JButton searchB;	
	private JScrollPane tableScroll;
	private JTable table;
	private DefaultTableModel dtm;
	private Object[] columnNames = {"������", "��ǰ��", "����", "����", "��ۻ���"};
	private Object[][] data = null;
	private JButton wholeSearchB;

	public BuyHistory(int no) {
		this.no = no;
		AccountDTO dto = AccountDAO.getInstance().getAccount(no);
		setTitle(dto.getName()+"���� �����̷� ��ȸ");
		setBounds(100, 100, 500, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		String[] yearList = new String[] {"2016", "2017", "2018"};
		String[] monthList = new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
		
		wholeSearchB = new JButton("\uC804\uCCB4\uC870\uD68C");
		panel.add(wholeSearchB);
		yearC = new JComboBox<String>();
		yearC.setModel(new DefaultComboBoxModel<String>(yearList));
		panel.add(yearC);
		
		JLabel yearL = new JLabel("\uB144");
		yearL.setFont(new Font("����", Font.BOLD, 12));
		panel.add(yearL);
		
		monthC = new JComboBox<String>();
		monthC.setModel(new DefaultComboBoxModel<String>(monthList));
		panel.add(monthC);
		
		JLabel monthL = new JLabel("\uC6D4 ~ ");
		monthL.setFont(new Font("����", Font.BOLD, 12));
		panel.add(monthL);
		
		yearC2 = new JComboBox<String>(new DefaultComboBoxModel<String>(yearList));
		panel.add(yearC2);
		
		JLabel yearL2 = new JLabel("\uB144");
		yearL2.setFont(new Font("����", Font.BOLD, 12));
		panel.add(yearL2);
		
		monthC2 = new JComboBox<String>(new DefaultComboBoxModel<String>(monthList));
		panel.add(monthC2);
		
		JLabel monthL2 = new JLabel("\uC6D4");
		monthL2.setFont(new Font("����", Font.BOLD, 12));
		panel.add(monthL2);
		
		searchB = new JButton("\uC870\uD68C");
		panel.add(searchB);
		
		tableScroll = new JScrollPane();
		contentPane.add(tableScroll, BorderLayout.CENTER);
		
		dtm = new DefaultTableModel(data, columnNames) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table = new JTable(dtm);
		tableScroll.setViewportView(table);
		
		//���Ϸ� ����
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH)+1;
		String monthS = month<10 ? "0"+month : month+"";
		yearC.setSelectedItem(year+"");
		monthC.setSelectedItem(monthS+"");
		yearC2.setSelectedItem(year+"");
		monthC2.setSelectedItem(monthS+"");
		
		setList(BuyListDAO.getInstance().getBuyList(no));
		setVisible(true);
		
		event();
	}
	
	//list�� ������ ���̺��� ����
	public void setList(ArrayList<BuyListDTO> list) {
		dtm.setRowCount(0);
		if(list!=null) {
			for(BuyListDTO dto : list) {
				Object[] rowData = setRowData(dto);
				dtm.addRow(rowData);
			}
		}
	}
	
	public Object[] setRowData(BuyListDTO dto) {
		Date buytime = dto.getBuytime();
		String name = dto.getName();
		int count = dto.getCount();
		int price = dto.getPrice();
		int delivery_stmt = dto.getDelivery_stmt();
		String delivery=null;
		if(delivery_stmt==0) delivery = "�غ���";
		else if(delivery_stmt==1) delivery = "�����";
		else if(delivery_stmt==2) delivery = "��ۿϷ�";
		else if(delivery_stmt==3) delivery = "���";

		Object[] rowData = {buytime, name, count, price, delivery};
		return rowData;
	}
	
	public void event() {
		searchB.addActionListener(this);
		wholeSearchB.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==searchB) {
			setPeriod();
			String year = (String)yearC.getSelectedItem();
			String month = (String)monthC.getSelectedItem();
			String year2 = (String)yearC2.getSelectedItem();
			String month2 = null;
			if(monthC2.getSelectedIndex() < 9) { //10���̸�
				month2 = "0"+(monthC2.getSelectedIndex()+2);
			}else if(monthC2.getSelectedIndex()==11) { //12��
				month2 = "01";
				year2 = Integer.parseInt(year2)+1+"";
			}
			
			ArrayList<BuyListDTO> list = BuyListDAO.getInstance().getBuyList(no, year+month, year2+month2);
			setList(list);
		}else if(e.getSource()==wholeSearchB) {
			setList(BuyListDAO.getInstance().getBuyList(no));
		}
	}
	
	//���� �˻��Ⱓ�� ������¥���� ���ĳ�¥�� �����̸� ������¥�� ����
	public void setPeriod() {
		int year = Integer.parseInt((String)yearC.getSelectedItem());
		int month = Integer.parseInt((String)monthC.getSelectedItem());
		int year2 = Integer.parseInt((String)yearC2.getSelectedItem());
		int month2 = Integer.parseInt((String)monthC2.getSelectedItem());
		if(year>year2) yearC2.setSelectedItem(yearC.getSelectedItem());
		if(month>month2) monthC2.setSelectedItem(monthC.getSelectedItem());
	}
}
