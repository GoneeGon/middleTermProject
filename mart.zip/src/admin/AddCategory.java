package admin;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.SwingConstants;

import item.categoryDAO.*;
import item.categoryDTO.CategoryDTO;


public class AddCategory extends JFrame implements ActionListener{
	private JPanel jp;
	private JLabel title;
	private JLabel nameL;
	private JTextField nameT;
	private JButton addB;
	private JButton cancelB;
	
	private AddItem ai;
	
	public AddCategory(AddItem ai) {
		this.ai = ai;
		jp = new JPanel();
		jp.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(jp);
		jp.setLayout(null);
		
		title=new JLabel("\uC0C1\uD488\uBD84\uB958\uBA85 \uCD94\uAC00");
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setFont(new Font("����", Font.BOLD, 16));
		title.setBounds(65,2,204,36);
		
		nameL=new JLabel("��ǰ�з��� �Է� : ");
		nameL.setBounds(0,46,108,21);
		
		nameT=new JTextField(20);
		nameT.setBounds(103,46,80,21);
		
		addB=new JButton("�߰�");
		addB.setBounds(193,46,64,21);
		
		cancelB=new JButton("���");
		cancelB.setBounds(261,46,64,21);
		
		jp.add(title); jp.add(nameL); 
		jp.add(nameT); jp.add(addB); jp.add(cancelB);
		
		setTitle("��ǰ�з� �߰�");
		setBounds(800, 300, 353, 138);
		setVisible(true);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		addB.addActionListener(this);
		cancelB.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==addB) {
			if(nameT.getText()=="") {
				JOptionPane.showMessageDialog(this, "�з����� �Է����ּ���", "��ǰ�з��� �߰�", JOptionPane.INFORMATION_MESSAGE);
			}else if(CategoryDAO.getInstance().checkCategoryDB((nameT.getText()))){
				JOptionPane.showMessageDialog(this, "�����ϴ� �з��� �Դϴ�", "��ǰ�з��� �߰�", JOptionPane.INFORMATION_MESSAGE);
			}else {
				int su=setCategory();
				Vector<CategoryDTO> categList = new Vector<CategoryDTO>();
				ArrayList<CategoryDTO> list= CategoryDAO.getInstance().getCategoryList();
				for(CategoryDTO dto : list) {
					categList.addElement(dto);
				}
				ai.getCategC().setModel(new DefaultComboBoxModel<CategoryDTO>(categList));
				ai.itemMgmt.mainPage.refreshComboBox(); //���������� �޺� �ʱ�ȭ
				JOptionPane.showMessageDialog(this, su+"���� ��ǰ�з����� ��ϵǾ����ϴ�", "��� ����", JOptionPane.INFORMATION_MESSAGE);
				this.dispose();
			}
		}else if(e.getSource()==cancelB)
			this.dispose();
	}
	
	public int setCategory() {
		CategoryDTO dto=new CategoryDTO();
		
		dto.setName(nameT.getText());
		
		int su=CategoryDAO.getInstance().addCategory(dto);
		return su;
	}
}


























