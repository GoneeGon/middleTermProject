package admin;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;
import chat.server.ChatServer;
import item.buylistDAO.BuyListDAO;
import item.buylistDTO.BuyListDTO;
import item.categoryDAO.CategoryDAO;
import item.categoryDTO.CategoryDTO;
import item.itemDAO.ItemDAO;
import item.itemDTO.ItemDTO;
import notice.NoticeServer;
import order.OrderServer;

public class MainPage_Admin extends JFrame implements ActionListener,ListSelectionListener{

	private JPanel backgroundPanel,productListPanel,productPanel,productInfoPanel,productInfoLabelPanel,productImgPanel,todayDoPanel;
	private JPanel productListTitlePanel,prepareDeliveryPanel,deliveryPanel,cancelPanel,finishPanel,subMartPanel;
	private JTabbedPane tabbedPane;
	private JPanel noticePanel;
	private JButton noticeSaveB, noticeResetB;
	private JTextArea noticeT;
	
	private JButton DeliveryMgmtButton,SalesMgmtButton,ItemMgmtButton,AccountMgmtButton;
	private JButton refreshB;
	
	private JList<ItemDTO> list;					//JList
	private DefaultListModel<ItemDTO> model;		//JList ���� ��� �༮
	
	private JLabel productListTitleLabel,prepareDeliveryLabel,deliveryLabel,cancelLabel,finishLabel,
	productInfoLabel,productCodeLabel,productNameLabel,productPriceLabel,productCategoryLabel,productQtyLabel,imageLabel;
	private JLabel incomeLabel,customer_1Label,customer_2Label,customer_3Label,favoriteProduct_1Label,favoriteProduct_2Label,favoriteProduct_3Label;
		
	private JTextField productCodeTextField,productNameTextField,productPriceTextField,productCategoryTextField,productQtyTextField;
	private JTextField prepareDeliveryTextField,deliveryTextField,cancelTextField,finishTextField;
	private JTextField incomeTextField,customer_1TextField,customer_2TextField,customer_3TextField,favoriteProduct_1TextField,
	favoriteProduct_2TextField,favoriteProduct_3TextField;
	
	private String passId,passPw;
	public String filename=null;
	//�̹��� path
	public String path = System.getProperty("user.dir");
	
	public int code =0;
	public boolean flag = true;
	
	private JComboBox<CategoryDTO> comboBox;
	private JComboBox<String> yearC;
	private JComboBox<String> monthC;
	private JButton rankSearchB;
	private JTextField refreshTime;
			
	public MainPage_Admin(AccountDTO login) {		
		passId = login.getId();
		passPw = login.getPassword();
		
		getContentPane().setLayout(null);
				
		//��ǰ ȭ�� �г�
		productPanel = new JPanel();
		productPanel.setBackground(new Color(153, 204, 153));
		productPanel.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		productPanel.setBounds(214, 98, 1046, 585);
		getContentPane().add(productPanel);
		productPanel.setLayout(null);
		
		//��ǰ���� �г�
		String productInfoImgPath = System.getProperty("user.dir");
		ImageIcon productInfoImgIcon = new ImageIcon(productInfoImgPath+"\\image\\vegitable2.jpg");
		productInfoPanel = new JPanel() {
			public void paintComponent(Graphics g) {
				g.drawImage(productInfoImgIcon.getImage(),0,0,null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		productInfoPanel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		productInfoPanel.setBounds(12, 255, 508, 320);
		productPanel.add(productInfoPanel);
		productInfoPanel.setLayout(null);
		
		//��ǰ���� ��
		productInfoLabel = new JLabel("\uC0C1\uD488\uC815\uBCF4");
		productInfoLabel.setForeground(Color.WHITE);
		productInfoLabel.setBackground(new Color(153, 204, 153));
		productInfoLabel.setFont(new Font("���� ����", Font.BOLD, 20));
		productInfoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		productInfoLabel.setBounds(12, 10, 113, 37);
		productInfoPanel.add(productInfoLabel);
		
		//��ǰ������ �г�
		productInfoLabelPanel = new JPanel();
		productInfoLabelPanel.setBackground(new Color(153, 204, 153));
		productInfoLabelPanel.setBounds(12, 10, 113, 37);
		productInfoPanel.add(productInfoLabelPanel);
		productInfoLabelPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, new Color(255, 153, 0), new Color(255, 153, 0), new Color(255, 204, 153), new Color(255, 204, 153)));
		productInfoLabelPanel.setLayout(null);
		
		//��ǰ�ڵ� ��
		productCodeLabel = new JLabel("\uC0C1\uD488\uCF54\uB4DC :");
		productCodeLabel.setForeground(Color.BLACK);
		productCodeLabel.setFont(new Font("���� ����", Font.BOLD, 14));
		productCodeLabel.setBounds(201, 57, 70, 30);
		productInfoPanel.add(productCodeLabel);
		
		//��ǰ�̹��� �г�
		productImgPanel = new JPanel();
		productImgPanel.setBackground(new Color(153, 204, 153));
		productImgPanel.setBorder(new CompoundBorder(new CompoundBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "\uC0C1\uD488\uC774\uBBF8\uC9C0", TitledBorder.CENTER, TitledBorder.ABOVE_TOP, null, new Color(0, 0, 0)), null), null));
		productImgPanel.setBounds(12, 57, 150, 230);
		productInfoPanel.add(productImgPanel);
		productImgPanel.setLayout(null);
		
		//��ǰ �̹��� ���� ��
		imageLabel = new JLabel("\uC774\uBBF8\uC9C0");
		imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		imageLabel.setBounds(12, 24, 126, 196);
		productImgPanel.add(imageLabel);
		
		//��ǰ�̸� ��
		productNameLabel = new JLabel("\uC0C1\uD488\uC774\uB984 :");
		productNameLabel.setForeground(Color.BLACK);
		productNameLabel.setFont(new Font("���� ����", Font.BOLD, 14));
		productNameLabel.setBounds(201, 97, 70, 30);
		productInfoPanel.add(productNameLabel);
		
		//��ǰ���� ��
		productPriceLabel = new JLabel("\uC0C1\uD488\uAC00\uACA9 :");
		productPriceLabel.setForeground(Color.BLACK);
		productPriceLabel.setFont(new Font("���� ����", Font.BOLD, 14));
		productPriceLabel.setBounds(201, 137, 70, 30);
		productInfoPanel.add(productPriceLabel);
		
		//��ǰ�з� ��
		productCategoryLabel = new JLabel("\uC0C1\uD488\uBD84\uB958 :");
		productCategoryLabel.setForeground(Color.BLACK);
		productCategoryLabel.setFont(new Font("���� ����", Font.BOLD, 14));
		productCategoryLabel.setBounds(201, 177, 70, 30);
		productInfoPanel.add(productCategoryLabel);
		
		//��ǰ��� ��
		productQtyLabel = new JLabel("\uC0C1\uD488\uC7AC\uACE0 :");
		productQtyLabel.setForeground(Color.BLACK);
		productQtyLabel.setFont(new Font("���� ����", Font.BOLD, 14));
		productQtyLabel.setBounds(201, 217, 70, 30);
		productInfoPanel.add(productQtyLabel);
		
		//��ǰ�ڵ� �ؽ�Ʈ�ʵ�
		productCodeTextField = new JTextField();
		productCodeTextField.setBackground(new Color(153, 204, 153));
		productCodeTextField.setHorizontalAlignment(SwingConstants.CENTER);
		productCodeTextField.setEditable(false);
		productCodeTextField.setBounds(283, 63, 96, 21);
		productInfoPanel.add(productCodeTextField);
		productCodeTextField.setColumns(10);
		
		//��ǰ�̸� �ؽ�Ʈ�ʵ�
		productNameTextField = new JTextField();
		productNameTextField.setBackground(new Color(153, 204, 153));
		productNameTextField.setHorizontalAlignment(SwingConstants.CENTER);
		productNameTextField.setEditable(false);
		productNameTextField.setColumns(10);
		productNameTextField.setBounds(283, 103, 96, 21);
		productInfoPanel.add(productNameTextField);
		
		//��ǰ���� �ؽ�Ʈ�ʵ�
		productPriceTextField = new JTextField();
		productPriceTextField.setBackground(new Color(153, 204, 153));
		productPriceTextField.setHorizontalAlignment(SwingConstants.CENTER);
		productPriceTextField.setEditable(false);
		productPriceTextField.setColumns(10);
		productPriceTextField.setBounds(283, 143, 96, 21);
		productInfoPanel.add(productPriceTextField);
		
		//��ǰ�з� �ؽ�Ʈ�ʵ�
		productCategoryTextField = new JTextField();
		productCategoryTextField.setBackground(new Color(153, 204, 153));
		productCategoryTextField.setHorizontalAlignment(SwingConstants.CENTER);
		productCategoryTextField.setEditable(false);
		productCategoryTextField.setColumns(10);
		productCategoryTextField.setBounds(283, 183, 96, 21);
		productInfoPanel.add(productCategoryTextField);
		
		//��ǰ��� �ؽ�Ʈ�ʵ�
		productQtyTextField = new JTextField();
		productQtyTextField.setBackground(new Color(153, 204, 153));
		productQtyTextField.setHorizontalAlignment(SwingConstants.CENTER);
		productQtyTextField.setEditable(false);
		productQtyTextField.setColumns(10);
		productQtyTextField.setBounds(283, 223, 96, 21);
		productInfoPanel.add(productQtyTextField);
				
		//��Ʈ��Ȳ �г�
		subMartPanel = new JPanel() {
			public void paintComponent(Graphics g) {
				g.drawImage(productInfoImgIcon.getImage(),0,0,null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		subMartPanel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		subMartPanel.setBounds(532, 255, 502, 320);
		productPanel.add(subMartPanel);
		subMartPanel.setLayout(null);
		
		//��Ʈ��Ȳ ���� �г�
		JPanel martTitlePanel = new JPanel();
		martTitlePanel.setBackground(new Color(153, 204, 153));
		martTitlePanel.setLayout(null);
		martTitlePanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, new Color(255, 153, 0), new Color(255, 153, 0), new Color(255, 204, 153), new Color(255, 204, 153)));
		martTitlePanel.setBounds(12, 10, 113, 37);
		subMartPanel.add(martTitlePanel);
		
		//��Ʈ��Ȳ ���� �ؽ�Ʈ �ʵ�
		JLabel martTitleTextField = new JLabel("\uB9C8\uD2B8\uD604\uD669");
		martTitleTextField.setForeground(Color.WHITE);
		martTitleTextField.setBackground(new Color(153, 204, 153));
		martTitleTextField.setHorizontalAlignment(SwingConstants.CENTER);
		martTitleTextField.setFont(new Font("���� ����", Font.BOLD, 16));
		martTitleTextField.setBounds(0, 0, 113, 37);
		martTitlePanel.add(martTitleTextField);
		
		//���� ��
		incomeLabel = new JLabel("\uCD1D\uC218\uC785 :");
		incomeLabel.setForeground(Color.BLACK);
		incomeLabel.setFont(new Font("���� ����", Font.BOLD, 14));
		incomeLabel.setBounds(279, 265, 67, 30);
		subMartPanel.add(incomeLabel);
		
		//���� �ؽ�Ʈ �ʵ�
		incomeTextField = new JTextField();
		incomeTextField.setBackground(new Color(153, 204, 153));
		incomeTextField.setHorizontalAlignment(SwingConstants.CENTER);
		incomeTextField.setEditable(false);
		incomeTextField.setColumns(10);
		incomeTextField.setBounds(339, 271, 96, 21);
		subMartPanel.add(incomeTextField);
		
		//�ܰ����1 ��
		customer_1Label = new JLabel("\uB2E8\uACE8\uACE0\uAC1D 1\uC704 :");
		customer_1Label.setForeground(Color.BLACK);
		customer_1Label.setFont(new Font("���� ����", Font.BOLD, 14));
		customer_1Label.setBounds(12, 90, 104, 30);
		subMartPanel.add(customer_1Label);
		
		//�ܰ����2 �ؽ�Ʈ �ʵ�
		customer_1TextField = new JTextField();
		customer_1TextField.setBackground(new Color(153, 204, 153));
		customer_1TextField.setHorizontalAlignment(SwingConstants.CENTER);
		customer_1TextField.setEditable(false);
		customer_1TextField.setColumns(10);
		customer_1TextField.setBounds(112, 96, 96, 21);
		subMartPanel.add(customer_1TextField);
		
		//�ܰ����2 ��
		customer_2Label = new JLabel("\uB2E8\uACE8\uACE0\uAC1D 2\uC704 :");
		customer_2Label.setForeground(Color.BLACK);
		customer_2Label.setFont(new Font("���� ����", Font.BOLD, 14));
		customer_2Label.setBounds(12, 150, 104, 30);
		subMartPanel.add(customer_2Label);
		
		//�ܰ����2 �ؽ�Ʈ �ʵ�
		customer_2TextField = new JTextField();
		customer_2TextField.setBackground(new Color(153, 204, 153));
		customer_2TextField.setHorizontalAlignment(SwingConstants.CENTER);
		customer_2TextField.setEditable(false);
		customer_2TextField.setColumns(10);
		customer_2TextField.setBounds(112, 156, 96, 21);
		subMartPanel.add(customer_2TextField);
		
		//�ܰ����3 ��
		customer_3Label = new JLabel("\uB2E8\uACE8\uACE0\uAC1D 3\uC704 :");
		customer_3Label.setForeground(Color.BLACK);
		customer_3Label.setFont(new Font("���� ����", Font.BOLD, 14));
		customer_3Label.setBounds(12, 210, 104, 30);
		subMartPanel.add(customer_3Label);
		
		//�ܰ����3 �ؽ�Ʈ �ʵ�
		customer_3TextField = new JTextField();
		customer_3TextField.setBackground(new Color(153, 204, 153));
		customer_3TextField.setHorizontalAlignment(SwingConstants.CENTER);
		customer_3TextField.setEditable(false);
		customer_3TextField.setColumns(10);
		customer_3TextField.setBounds(112, 216, 96, 21);
		subMartPanel.add(customer_3TextField);
		
		//�Ǹ�1�� ��ǰ ��
		favoriteProduct_1Label = new JLabel("\uD310\uB9E4\uC0C1\uD488 1\uC704 :");
		favoriteProduct_1Label.setForeground(Color.BLACK);
		favoriteProduct_1Label.setFont(new Font("���� ����", Font.BOLD, 14));
		favoriteProduct_1Label.setBounds(237, 90, 104, 30);
		subMartPanel.add(favoriteProduct_1Label);
		
		//�Ǹ�1�� ��ǰ �ؽ�Ʈ �ʵ�
		favoriteProduct_1TextField = new JTextField();
		favoriteProduct_1TextField.setBackground(new Color(153, 204, 153));
		favoriteProduct_1TextField.setHorizontalAlignment(SwingConstants.CENTER);
		favoriteProduct_1TextField.setEditable(false);
		favoriteProduct_1TextField.setColumns(10);
		favoriteProduct_1TextField.setBounds(339, 96, 96, 21);
		subMartPanel.add(favoriteProduct_1TextField);
		
		//�Ǹ�2�� ��ǰ ��
		favoriteProduct_2Label = new JLabel("\uD310\uB9E4\uC0C1\uD488 2\uC704 :");
		favoriteProduct_2Label.setForeground(Color.BLACK);
		favoriteProduct_2Label.setFont(new Font("���� ����", Font.BOLD, 14));
		favoriteProduct_2Label.setBounds(237, 150, 104, 30);
		subMartPanel.add(favoriteProduct_2Label);
		
		//�Ǹ�2�� ��ǰ �ؽ�Ʈ �ʵ�
		favoriteProduct_2TextField = new JTextField();
		favoriteProduct_2TextField.setBackground(new Color(153, 204, 153));
		favoriteProduct_2TextField.setHorizontalAlignment(SwingConstants.CENTER);
		favoriteProduct_2TextField.setEditable(false);
		favoriteProduct_2TextField.setColumns(10);
		favoriteProduct_2TextField.setBounds(339, 156, 96, 21);
		subMartPanel.add(favoriteProduct_2TextField);
		
		//�Ǹ�3�� ��ǰ ��
		favoriteProduct_3Label = new JLabel("\uD310\uB9E4\uC0C1\uD488 3\uC704 :");
		favoriteProduct_3Label.setForeground(Color.BLACK);
		favoriteProduct_3Label.setFont(new Font("���� ����", Font.BOLD, 14));
		favoriteProduct_3Label.setBounds(237, 210, 104, 30);
		subMartPanel.add(favoriteProduct_3Label);
		
		//�Ǹ�3�� ��ǰ �ؽ�Ʈ �ʵ�
		favoriteProduct_3TextField = new JTextField();
		favoriteProduct_3TextField.setBackground(new Color(153, 204, 153));
		favoriteProduct_3TextField.setHorizontalAlignment(SwingConstants.CENTER);
		favoriteProduct_3TextField.setEditable(false);
		favoriteProduct_3TextField.setColumns(10);
		favoriteProduct_3TextField.setBounds(339, 216, 96, 21);
		subMartPanel.add(favoriteProduct_3TextField);
		
		yearC = new JComboBox<String>();
		yearC.setModel(new DefaultComboBoxModel<String>(new String[] {"2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010"}));
		yearC.setBackground(new Color(153, 204, 153));
		yearC.setBounds(205, 20, 80, 21);
		subMartPanel.add(yearC);
		
		monthC = new JComboBox<String>();
		monthC.setModel(new DefaultComboBoxModel<String>(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"}));
		monthC.setBackground(new Color(153, 204, 153));
		monthC.setBounds(315, 20, 60, 21);
		subMartPanel.add(monthC);
		
		rankSearchB = new JButton("��ȸ");
		rankSearchB.setBounds(405, 19, 60, 23);
		subMartPanel.add(rankSearchB);
		
		JLabel yearL = new JLabel("\uB144");
		yearL.setFont(new Font("����", Font.BOLD, 12));
		yearL.setBounds(290, 23, 30, 15);
		subMartPanel.add(yearL);
		
		JLabel monthL = new JLabel("\uC6D4");
		monthL.setFont(new Font("����", Font.BOLD, 12));
		monthL.setBounds(380, 23, 30, 15);
		subMartPanel.add(monthL);
		
		
		//������ ���� ��
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(Color.LIGHT_GRAY);
		tabbedPane.setBounds(12, 10, 1022, 224);
		productPanel.add(tabbedPane);
				
		//������ ���� �г�
		todayDoPanel = new JPanel(); 
		todayDoPanel.setBackground(new Color(153, 204, 153));
		tabbedPane.addTab("\uC624\uB298\uC758 \uD560\uC77C", null, todayDoPanel, null);
		todayDoPanel.setLayout(null);
		
		//�������� �г�
		noticePanel = new JPanel();
		noticePanel.setBackground(new Color(153, 204, 153));
		tabbedPane.addTab("��������", null, noticePanel, null);
		noticePanel.setLayout(new BorderLayout());
		
		//�������� �ϴ� �г�
		JPanel noticeBottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		noticeBottomPanel.setBackground(new Color(153, 204, 153));
		noticePanel.add(noticeBottomPanel, BorderLayout.SOUTH);
		noticeSaveB = new JButton("����");
		noticeBottomPanel.add(noticeSaveB);
		noticeResetB = new JButton("�ٽþ���");
		noticeBottomPanel.add(noticeResetB);
		noticeSaveB.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				noticeSave();				
			}
		});
		noticeResetB.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				noticeT.setText("");
			}
		});			
		//�������� ���� �г�
		JScrollPane noticeScroll = new JScrollPane();
		noticePanel.add(noticeScroll, BorderLayout.CENTER);
		
		noticeT = new JTextArea();
		noticeScroll.setViewportView(noticeT);
		noticeRead(); //�������� �ҷ�����
		
		//����غ��� �г�
		prepareDeliveryPanel = new JPanel();
		prepareDeliveryPanel.setBackground(new Color(153, 204, 153));
		prepareDeliveryPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, new Color(255, 215, 0), null, new Color(255, 215, 0), null));
		prepareDeliveryPanel.setBounds(63, 66, 118, 90);
		todayDoPanel.add(prepareDeliveryPanel);
		prepareDeliveryPanel.setLayout(null);
		
		//����غ��� �ؽ�Ʈ �ʵ�
		prepareDeliveryTextField = new JTextField();
		prepareDeliveryTextField.setText("2\uAC74");
		prepareDeliveryTextField.setHorizontalAlignment(SwingConstants.CENTER);
		prepareDeliveryTextField.setColumns(10);
		prepareDeliveryTextField.setBackground(new Color(153, 204, 153));
		prepareDeliveryTextField.setBounds(30, 36, 60, 21);
		prepareDeliveryPanel.add(prepareDeliveryTextField);
		
		//����غ��� ��
		prepareDeliveryLabel = new JLabel("\uBC30\uC1A1\uC900\uBE44\uC911");
		prepareDeliveryLabel.setHorizontalAlignment(SwingConstants.CENTER);
		prepareDeliveryLabel.setFont(new Font("�޸հ���", Font.BOLD, 15));
		prepareDeliveryLabel.setBounds(63, 53, 118, 15);
		todayDoPanel.add(prepareDeliveryLabel);
		
		//����� �г�
		deliveryPanel = new JPanel();
		deliveryPanel.setBackground(new Color(153, 204, 153));
		deliveryPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, new Color(255, 215, 0), null, new Color(255, 215, 0), null));
		deliveryPanel.setBounds(310, 66, 118, 90);
		todayDoPanel.add(deliveryPanel);
		deliveryPanel.setLayout(null);
		
		//�м��� �ؽ�Ʈ �ʵ�
		deliveryTextField = new JTextField();
		deliveryTextField.setHorizontalAlignment(SwingConstants.CENTER);
		deliveryTextField.setText("10\uAC74");
		deliveryTextField.setColumns(10);
		deliveryTextField.setBackground(new Color(153, 204, 153));
		deliveryTextField.setBounds(30, 36, 60, 21);
		deliveryPanel.add(deliveryTextField);
		
		//����� ��
		deliveryLabel = new JLabel("\uBC30\uC1A1\uC911");
		deliveryLabel.setHorizontalAlignment(SwingConstants.CENTER);
		deliveryLabel.setFont(new Font("�޸հ���", Font.BOLD, 15));
		deliveryLabel.setBounds(310, 53, 118, 15);
		todayDoPanel.add(deliveryLabel);
		
		//��ҽ�û �г�
		cancelPanel = new JPanel();
		cancelPanel.setBackground(new Color(153, 204, 153));
		cancelPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, new Color(255, 215, 0), null, new Color(255, 215, 0), null));
		cancelPanel.setBounds(570, 66, 118, 90);
		todayDoPanel.add(cancelPanel);
		cancelPanel.setLayout(null);
		
		//��ҽ�û �ؽ�Ʈ �ʵ�
		cancelTextField = new JTextField();
		cancelTextField.setText("2\uAC74");
		cancelTextField.setHorizontalAlignment(SwingConstants.CENTER);
		cancelTextField.setColumns(10);
		cancelTextField.setBackground(new Color(153, 204, 153));
		cancelTextField.setBounds(30, 36, 60, 21);
		cancelPanel.add(cancelTextField);
		
		//��ҽ�û ��
		cancelLabel = new JLabel("\uCDE8\uC18C\uC2E0\uCCAD");
		cancelLabel.setHorizontalAlignment(SwingConstants.CENTER);
		cancelLabel.setFont(new Font("�޸հ���", Font.BOLD, 15));
		cancelLabel.setBounds(570, 53, 118, 15);
		todayDoPanel.add(cancelLabel);
		
		//��ۿϷ� �г�
		finishPanel = new JPanel();
		finishPanel.setBackground(new Color(153, 204, 153));
		finishPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, new Color(255, 215, 0), null, new Color(255, 215, 0), null));
		finishPanel.setBounds(830, 66, 118, 90);
		todayDoPanel.add(finishPanel);
		finishPanel.setLayout(null);
		
		//��ۿϷ� �ؽ�Ʈ �ʵ�
		finishTextField = new JTextField();
		finishTextField.setText("50\uAC74");
		finishTextField.setHorizontalAlignment(SwingConstants.CENTER);
		finishTextField.setColumns(10);
		finishTextField.setBackground(new Color(153, 204, 153));
		finishTextField.setBounds(30, 36, 60, 21);
		finishPanel.add(finishTextField);
		
		//��ۿϷ� ��
		finishLabel = new JLabel("\uBC30\uC1A1\uC644\uB8CC");
		finishLabel.setHorizontalAlignment(SwingConstants.CENTER);
		finishLabel.setFont(new Font("�޸հ���", Font.BOLD, 15));
		finishLabel.setBounds(830, 53, 118, 15);
		todayDoPanel.add(finishLabel);
		
		//���ΰ�ħ ��ư
		refreshB = new JButton();
		ImageIcon icon = new ImageIcon(System.getProperty("user.dir")+"\\image\\refresh.png");
		Image image = icon.getImage();
		Image resizedImage = image.getScaledInstance(29, 29, Image.SCALE_SMOOTH);
		refreshB.setIcon(new ImageIcon(resizedImage));
		refreshB.setBackground(new Color(153, 204, 153));
		refreshB.setBounds(975, 10, 30, 30);
		refreshB.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setTodayPanel();
			}
		});
		todayDoPanel.add(refreshB);
		
		//���ΰ�ħ �ð�
		refreshTime = new JTextField();
		refreshTime.setBounds(849, 10, 116, 30);
		refreshTime.setBackground(new Color(153, 204, 153));
		todayDoPanel.add(refreshTime);
		refreshTime.setEditable(false);
		refreshTime.setColumns(10);
		
		JLabel refreshL = new JLabel("\uC0C8\uB85C\uACE0\uCE68 : ");
		refreshL.setFont(new Font("����", Font.BOLD, 12));
		refreshL.setHorizontalAlignment(SwingConstants.RIGHT);
		refreshL.setBounds(775, 10, 70, 30);
		todayDoPanel.add(refreshL);
		
		//�������� �ʱ�ȭ
		setTodayPanel();
		
		//��׶��� �г�(�ǵ�)+����̹���
		String backgroundImgPath = System.getProperty("user.dir");
		ImageIcon backgroundIcon = new ImageIcon(backgroundImgPath+"\\image\\vegitable.jpg");
		backgroundPanel = new JPanel(){
			public void paintComponent(Graphics g) {
				g.drawImage(backgroundIcon.getImage(),0,0,null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		backgroundPanel.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		backgroundPanel.setBounds(12, 10, 1248, 673);
		backgroundPanel.setLayout(null);
		getContentPane().add(backgroundPanel);
		
		//ȸ������ ��ư
		AccountMgmtButton = new JButton("\uD68C\uC6D0\uC815\uBCF4\uAD00\uB9AC");
		AccountMgmtButton.setIcon(new ImageIcon(path+"\\image\\AccountMgmt_icon.jpg"));
		AccountMgmtButton.setToolTipText("\uD68C\uC6D0\uC815\uBCF4\uAD00\uB9AC");
		AccountMgmtButton.setBounds(908, 10, 73, 71);
		backgroundPanel.add(AccountMgmtButton);
		
		//������� ��ư
		ItemMgmtButton = new JButton("\uC7AC\uACE0\uAD00\uB9AC");
		ItemMgmtButton.setIcon(new ImageIcon(path+"\\image\\ItemMgmt_icon.jpg"));
		ItemMgmtButton.setToolTipText("\uC7AC\uACE0\uAD00\uB9AC");
		ItemMgmtButton.setBounds(993, 10, 73, 71);
		backgroundPanel.add(ItemMgmtButton);
		
		//������� ��ư
		SalesMgmtButton = new JButton("\uB9E4\uCD9C\uAD00\uB9AC");
		SalesMgmtButton.setIcon(new ImageIcon(path+"\\image\\SalesMgmt_icon.jpg"));
		SalesMgmtButton.setToolTipText("\uB9E4\uCD9C\uAD00\uB9AC");
		SalesMgmtButton.setBounds(1078, 10, 73, 71);
		backgroundPanel.add(SalesMgmtButton);
		
		//��۰��� ��ư
		DeliveryMgmtButton = new JButton("\uBC30\uC1A1\uAD00\uB9AC");
		DeliveryMgmtButton.setIcon(new ImageIcon(path+"\\image\\DeliveryMgmt_icon.jpg"));
		DeliveryMgmtButton.setToolTipText("\uBC30\uC1A1\uAD00\uB9AC");
		DeliveryMgmtButton.setBounds(1163, 10, 73, 71);
		backgroundPanel.add(DeliveryMgmtButton);
		
		//��ǰ��� �г�(JList �ø� �г�)
		productListPanel = new JPanel();
		productListPanel.setBounds(12, 181, 180, 482);
		backgroundPanel.add(productListPanel);
		productListPanel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		productListPanel.setBackground(Color.WHITE);
		productListPanel.setLayout(new BorderLayout(0, 0));
		
		//JList ��ǰ����Ʈ
		list = new JList<ItemDTO>(new DefaultListModel<ItemDTO>());
		list.setBackground(new Color(153, 204, 153));
		model = (DefaultListModel<ItemDTO>) list.getModel();
		JScrollPane scroll = new JScrollPane(list);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		list.setBounds(22, 98, 180, 585);
		productListPanel.add(scroll);
		
		//��ǰ����Ʈ ���� �г�
		productListTitlePanel = new JPanel();
		productListTitlePanel.setBackground(new Color(153, 204, 153));
		productListTitlePanel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		productListTitlePanel.setBounds(12, 89, 180, 40);
		backgroundPanel.add(productListTitlePanel);
		productListTitlePanel.setLayout(null);
		
		//��ǰ����Ʈ ���� ��
		productListTitleLabel = new JLabel("\uC0C1\uD488\uB9AC\uC2A4\uD2B8");
		productListTitleLabel.setForeground(Color.WHITE);
		productListTitleLabel.setBackground(new Color(153, 204, 153));
		productListTitleLabel.setBounds(0, 5, 180, 35);
		productListTitlePanel.add(productListTitleLabel);
		productListTitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		productListTitleLabel.setFont(new Font("�޸հ���", Font.BOLD, 20));
		
		
		comboBox = new JComboBox<CategoryDTO>();
		comboBox.setForeground(Color.BLACK);
		comboBox.setBackground(new Color(153, 204, 153));
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refresh(); //�޺��ڽ� ���� ������ JList �ʱ�ȭ
				int code = ((CategoryDTO)comboBox.getSelectedItem()).getCode();
				getItemList(code);
			}
		});
		
		//ī�װ��� ����Ʈ ����
		ArrayList<CategoryDTO> categoryList = CategoryDAO.getInstance().getCategoryList();
		comboBox.setModel(new DefaultComboBoxModel<CategoryDTO>(new Vector<CategoryDTO>(categoryList)));
		comboBox.setBounds(12, 139, 180, 32);
		backgroundPanel.add(comboBox);
		
		setTitle("����ȭ��");	
		setVisible(true);
		setBounds(100,100,1280,720);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//DB�� �ִ� ��ǰ  ��������
		getItemList(code);
		
		//�̺�Ʈ ���
		AccountMgmtButton.addActionListener(this);
		ItemMgmtButton.addActionListener(this);
		SalesMgmtButton.addActionListener(this);
		DeliveryMgmtButton.addActionListener(this);
		list.addListSelectionListener(this);
		rankSearchB.addActionListener(this);
		
		//ä�ü��� ����
		new ChatServer().start();
		//�ֹ����� ����
		new OrderServer(this).start();
		//�������׼��� ����
		new NoticeServer(this).start();
	}//������	
	
	//JList �ʱ�ȭ �޼ҵ�1
	public void refresh() {
        updateListModel();
        list.setModel(model);
    }
	
	//JList �ʱ�ȭ �޼ҵ�2
	public void updateListModel() {
        if (list.size()==null)   System.out.println("No Objects In Array!");  
        else model.clear();
    }
	
	//DB�� �ִ� ��ǰ �������� �޼ҵ�
	public void getItemList(int code) {
		ItemDAO dao = ItemDAO.getInstance();
		//itemDTO�� ��� ���� ���-> ArrayList �̿��Ͽ� itemDTO ��ü ��Ƽ� ���� ����(���Ͻ�, itemDTO�� �Ѱ��� ������)
		ArrayList<ItemDTO> list_2 = dao.getItemList(code);
		for(ItemDTO dto:list_2) {
			model.addElement(dto);
		}//for
	}//getitemList()	

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==AccountMgmtButton) new AccountMgmt();
		else if(e.getSource()==ItemMgmtButton) new ItemMgmt(this);
		else if(e.getSource()==SalesMgmtButton) new SalesMgmt();
		else if(e.getSource()==DeliveryMgmtButton) new DeliveryMgmt();
		else if(e.getSource()==rankSearchB) {
			setRanking();
			setPRanking();
			setIncome();
		}
	}
	
	//��ǰ����Ʈ(JList)�� ��ǰ�׸� ���� ��,
	@Override
	public void valueChanged(ListSelectionEvent e) {
		
		//�̹��� path
		String path = System.getProperty("user.dir");
		
		//���� ��, �ε��� ���� �������Ƿ� -1�� ��ȯ�ȴ� -> -1�̸� �ؿ� ���� ����X(�׷��� ���� ����)
		if(list.getSelectedIndex()==-1) return;
		//���õ� JList ���� dto�� ����
		ItemDTO dto = list.getSelectedValue();
		//JList���� ���õ� ��ü ���� �����ͼ� �����ֱ�
		productCodeTextField.setText(dto.getSeq()+"");
		productNameTextField.setText(dto.getName());
		productPriceTextField.setText(dto.getPrice()+"");
		productCategoryTextField.setText(dto.getCategory()+"");
		productQtyTextField.setText(dto.getProduct_qty()+"");
			
		ImageIcon icon = new ImageIcon(path+"\\image\\"+dto.getImage());
		Image image = icon.getImage();
		Image resizedImage = image.getScaledInstance(126, 200, Image.SCALE_SMOOTH);
		imageLabel.setIcon(new ImageIcon(resizedImage));
	}
	
	public void refreshComboBox() {
		ArrayList<CategoryDTO> categoryList = CategoryDAO.getInstance().getCategoryList();
		comboBox.setModel(new DefaultComboBoxModel<CategoryDTO>(new Vector<CategoryDTO>(categoryList)));
	}
	
	//������ ���� ����
	public void setTodayPanel() {
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMdd");
		Date date = new Date();
		String today = sdf.format(date);
		int pre=0;
		int delivery=0;
		int finish = 0;
		int cancel = 0;
		
		refreshTime.setText(new SimpleDateFormat("MM�� dd�� HH:mm:ss").format(date));
		
		ArrayList<BuyListDTO> list = BuyListDAO.getInstance().getBuyList(0, today, today);
		if(list!=null) {
			for(BuyListDTO dto : list) {
				if(dto.getDelivery_stmt()==0) pre++;
				else if(dto.getDelivery_stmt()==1) delivery++;
				else if(dto.getDelivery_stmt()==2) finish++;
				else if(dto.getDelivery_stmt()==3) cancel++;
			}
			prepareDeliveryTextField.setText(pre+"");
			deliveryTextField.setText(delivery+"");
			cancelTextField.setText(cancel+"");
			finishTextField.setText(finish+"");
		}else {
			prepareDeliveryTextField.setText("0");
			deliveryTextField.setText("0");
			cancelTextField.setText("0");
			finishTextField.setText("0");
		}
	}
	
	//customer_TextField ����
	public void setRanking() {
		String bestCustomer1="";
		String bestCustomer2="";
		String bestCustomer3="";
		
		int[] customerNo;
		int[] total;
		
		String year;
		if(yearC.getSelectedIndex()==-1) {
			year="2018";
		}else
			year= (String)yearC.getSelectedItem();
		
		String month;
		if(monthC.getSelectedIndex()==-1) {
			month="01";
		}else {
			month= (String)monthC.getSelectedItem();
		}
		
		RankDTO dto=new RankDTO();
		dto.setYear(year);
		dto.setMonth(month);
		
		
		RankDAO.getInstance().getCustomNo(dto);
		
		customerNo=RankDAO.getInstance().getNo(dto);
		total=new int[customerNo.length];
		
		for(int i=0;i<customerNo.length;i++) {
			total[i]=RankDAO.getInstance().getTotal(customerNo[i], year, month);
		}
		
		ArrayList<Rank> customerList=new ArrayList<Rank>();
		Rank[] r=new Rank[customerNo.length];
		
		
		//ȸ�� ��ȣ, �ѱ��Ű��� ����
		for(int i=0;i<customerNo.length;i++) {
			r[i]=new Rank(customerNo[i],total[i],0,0);
			customerList.add(r[i]);
		}
			
		//�ѱ��Ű��ݺ��� �з�, customerList[1]�� ���� ���̻�
		Collections.sort(customerList, new Comparator<Rank>() {

			@Override
			public int compare(Rank r0, Rank r1) {
				if(r0.getTotal()<r1.getTotal()) {
					return 1;
				}else if(r0.getTotal()>r1.getTotal()) {
					return -1;
				}else {
					return 0;
				}
			}
		});
		
		switch(customerList.size()) {
		case 0: break;
		case 3: bestCustomer3=AccountDAO.getInstance().getName(customerList.get(2).getNo());
		case 2: bestCustomer2=AccountDAO.getInstance().getName(customerList.get(1).getNo());
		case 1: bestCustomer1=AccountDAO.getInstance().getName(customerList.get(0).getNo()); break;		
		default:
			bestCustomer1=AccountDAO.getInstance().getName(customerList.get(0).getNo());
			bestCustomer2=AccountDAO.getInstance().getName(customerList.get(1).getNo());
			bestCustomer3=AccountDAO.getInstance().getName(customerList.get(2).getNo());
		}
		
		customer_1TextField.setText(bestCustomer1);
		customer_2TextField.setText(bestCustomer2);
		customer_3TextField.setText(bestCustomer3);
	
	}
	
	//favoriteProduct_TextField ����
	public void setPRanking() {
		String favoriteProduct1="";
		String favoriteProduct2="";
		String favoriteProduct3="";
		
		int[] productNo;
		int[] ptotal;
		
		String year;
		if(yearC.getSelectedIndex()==-1) {
			year="2018";
		}else
			year= (String)yearC.getSelectedItem();
		
		String month;
		if(monthC.getSelectedIndex()==-1) {
			month="01";
		}else {
			month= (String)monthC.getSelectedItem();
		}
		
		RankDTO dto=new RankDTO();
		dto.setYear(year);
		dto.setMonth(month);
		
		
		RankDAO.getInstance().getProductCnt(dto);
		
		productNo=RankDAO.getInstance().getProductNo(dto);
		ptotal=new int[productNo.length];
		
		for(int i=0;i<productNo.length;i++) {
			ptotal[i]=RankDAO.getInstance().getPTotal(productNo[i], year, month);
		}
		
		ArrayList<Rank> productList=new ArrayList<Rank>();
		Rank[] r=new Rank[productNo.length];
		
		
		//��ǰ ��ȣ, �ѱ��ż��� ����
		for(int i=0;i<productNo.length;i++) {
			r[i]=new Rank(0,0,productNo[i],ptotal[i]);
			productList.add(r[i]);
		}
			
		//�ѱ��Ű��ݺ��� �з�, customerList[1]�� ���� ���̻�
		Collections.sort(productList, new Comparator<Rank>() {

			@Override
			public int compare(Rank r0, Rank r1) {
				if(r0.getPtotal()<r1.getPtotal()) {
					return 1;
				}else if(r0.getPtotal()>r1.getPtotal()) {
					return -1;
				}else {
					return 0;
				}
			}
		});
		
		switch(productList.size()) {
		case 0: break;
		case 3: favoriteProduct3=ItemDAO.getInstance().getName(productList.get(2).getProductNo());
		case 2: favoriteProduct2=ItemDAO.getInstance().getName(productList.get(1).getProductNo());
		case 1: favoriteProduct1=ItemDAO.getInstance().getName(productList.get(0).getProductNo());break;
		default :
			favoriteProduct1=ItemDAO.getInstance().getName(productList.get(0).getProductNo());
			favoriteProduct2=ItemDAO.getInstance().getName(productList.get(1).getProductNo());
			favoriteProduct3=ItemDAO.getInstance().getName(productList.get(2).getProductNo());
		}
		
		favoriteProduct_1TextField.setText(favoriteProduct1);
		favoriteProduct_2TextField.setText(favoriteProduct2);
		favoriteProduct_3TextField.setText(favoriteProduct3);
		
	}

	//incomeTextField ����
	public void setIncome() {
		int mtotal;
		String year;
		if(yearC.getSelectedIndex()==-1) {
			year="2018";
		}else
			year= (String)yearC.getSelectedItem();
		
		String month;
		if(monthC.getSelectedIndex()==-1) {
			month="01";
		}else {
			month= (String)monthC.getSelectedItem();
		}
		
		mtotal=BuyListDAO.getInstance().getMTotal(year, month);
		
		incomeTextField.setText("");
		incomeTextField.setText(mtotal+"");
	}
	
	//�������� �о����
	public void noticeRead() {
		try {
			File file = new File(System.getProperty("user.dir")+"\\notice\\notice.txt"); 
			BufferedReader br = new BufferedReader(new FileReader(file));
			int size = (int)file.length();
			char[] b = new char[size];
			br.read(b, 0, size);
			noticeT.setText(new String(b));
			br.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void noticeSave() {
		try {
			File file = new File(System.getProperty("user.dir")+"\\notice\\notice.txt");
			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			String content = noticeT.getText();
			content = content.replaceAll("\n","\r\n");
			bw.write(content, 0, content.length());
			bw.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public JTextArea getNoticeT() {
		return noticeT;
	}
}



















