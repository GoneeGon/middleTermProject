package admin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

public class RankDAO {

	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String user = "java";
	private String password = "itbank";
	private int customNo;
	private int productCnt;
	
	private static RankDAO instance;
	
	public RankDAO() {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static RankDAO getInstance() {
		if(instance==null) {
			synchronized(RankDAO.class) {
				instance = new RankDAO();
			}
		}
		return instance;
	}
	
	public Connection getConnection() {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	//buylist�� �ִ� �޺� ȸ���� 
	public void getCustomNo(RankDTO dto) {
		int rowCnt=0;
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select distinct no from buylist where buytime>=TO_DATE(?,'YYYYMMDD') and buytime<=last_day(?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,dto.getYear()+dto.getMonth()+"01");
			pstmt.setString(2,dto.getYear()+dto.getMonth()+"01");
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				rowCnt++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		customNo=rowCnt;
	}
	
	//buylist�� �ִ� �޺� ȸ����ȣ ��ȸ
	public int[] getNo(RankDTO dto) {
		
		int[] customerNo=null;
		int cnt=0;
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select distinct no from buylist where buytime>=TO_DATE(?,'YYYYMMDD') and buytime<=last_day(?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,dto.getYear()+dto.getMonth()+"01");
			pstmt.setString(2,dto.getYear()+dto.getMonth()+"01");
			rs = pstmt.executeQuery();
			
			customerNo = new int[customNo];
			while(rs.next()) {
				customerNo[cnt]=rs.getInt(1);
				cnt++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return customerNo;
	}
	
	//ȸ����ȣ�� �� ���԰��� ��ȸ
	public int getTotal(int customerNo, String year, String month) {
		int total=0;
		
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select sum(price) from buylist where no=? and buytime>=TO_DATE(?,'YYYYMMDD') and buytime<=last_day(?)";
		
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,customerNo);
			pstmt.setString(2,year+month+"01");
			pstmt.setString(3,year+month+"01");
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				total=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return total;
	}
	
	
	//buylist�� �ִ� �޺� ��ǰ��
	public void getProductCnt(RankDTO dto) {
		int rowCnt=0;
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select distinct seq from buylist where buytime>=TO_DATE(?,'YYYYMMDD') and buytime<=last_day(?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,dto.getYear()+dto.getMonth()+"01");
			pstmt.setString(2,dto.getYear()+dto.getMonth()+"01");
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				rowCnt++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		productCnt=rowCnt;
	}

	//buylist�� �ִ� �޺� ��ǰ��ȣ ��ȸ
	public int[] getProductNo(RankDTO dto) {
		int[] ProductNo=null;
		int cnt=0;
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select distinct seq from buylist where buytime>=TO_DATE(?,'YYYYMMDD') and buytime<=last_day(?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,dto.getYear()+dto.getMonth()+"01");
			pstmt.setString(2,dto.getYear()+dto.getMonth()+"01");
			rs = pstmt.executeQuery();
			
			ProductNo = new int[productCnt];
			while(rs.next()) {
				ProductNo[cnt]=rs.getInt(1);
				cnt++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return ProductNo;
	}
	
	//��ǰ��ȣ�� �� ���԰���
	public int getPTotal(int productNo,String year,String month) {
		int ptotal=0;
		
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select sum(count) from buylist where seq=? and buytime>=TO_DATE(?,'YYYYMMDD') and buytime<=last_day(?)";
		
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,productNo);
			pstmt.setString(2,year+month+"01");
			pstmt.setString(3,year+month+"01");
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				ptotal=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return ptotal;
	}

	
}

























