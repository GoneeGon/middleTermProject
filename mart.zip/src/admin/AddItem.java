package admin;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import item.categoryDAO.CategoryDAO;
import item.categoryDTO.CategoryDTO;
import item.itemDAO.ItemDAO;
import item.itemDTO.ItemDTO;

import java.awt.Font;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Vector;


public class AddItem extends JFrame implements ActionListener {
	private JPanel jp;
	
	private JLabel titleL;
	private JLabel nameL;
	private JLabel priceL;
	private JLabel categoryL;
	private JLabel product_qtyL;
	private JLabel imageL;
	
	private JTextField nameT;
	private JTextField priceT;
	private JComboBox<CategoryDTO> categC;
	private JTextField product_qtyT;
	private JTextField imageT;
	
	private JButton addB; 
	private JButton cancelB;
	private JButton searchB;
	private JButton plusB;
	
	private File file;
	private String image;
	
	private AddCategory ac;
	public ItemMgmt itemMgmt;
	
	public AddItem(ItemMgmt itemMgmt) {
		this.itemMgmt = itemMgmt;
		
		jp = new JPanel();
		jp.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(jp);
		jp.setLayout(null);
		
		titleL=new JLabel("��ǰ��� ");
		titleL.setHorizontalAlignment(SwingConstants.CENTER);
		titleL.setFont(new Font("����", Font.BOLD, 20));
		titleL.setBounds(80, 0, 100, 50);
		
		nameL=new JLabel("��ǰ�̸� : ");
		nameL.setHorizontalAlignment(SwingConstants.RIGHT);
		nameL.setFont(new Font("����", Font.BOLD, 12));
		nameL.setBounds(12, 60, 100, 20);
		
		priceL=new JLabel("��ǰ���� : ");
		priceL.setHorizontalAlignment(SwingConstants.RIGHT);
		priceL.setFont(new Font("����", Font.BOLD, 12));
		priceL.setBounds(12, 90, 100, 20);
		
		categoryL=new JLabel("��ǰ�з� : ");
		categoryL.setHorizontalAlignment(SwingConstants.RIGHT);
		categoryL.setFont(new Font("����", Font.BOLD, 12));
		categoryL.setBounds(12, 120, 100, 20);
		
		product_qtyL=new JLabel("��ǰ��� : ");
		product_qtyL.setHorizontalAlignment(SwingConstants.RIGHT);
		product_qtyL.setFont(new Font("����", Font.BOLD, 12));
		product_qtyL.setBounds(12, 150, 100, 20);
		
		imageL=new JLabel("��ǰ�̹��� : ");
		imageL.setHorizontalAlignment(SwingConstants.RIGHT);
		imageL.setFont(new Font("����", Font.BOLD, 12));
		imageL.setBounds(12, 180, 100, 20);
		
		nameT=new JTextField(40);
		nameT.setBounds(112,60,80,20);
		priceT=new JTextField(40);
		priceT.setBounds(112,90,80,20);
		
		
		categC = new JComboBox<CategoryDTO>();
		Vector<CategoryDTO> categList = new Vector<CategoryDTO>();
		ArrayList<CategoryDTO> list= CategoryDAO.getInstance().getCategoryList();
		for(CategoryDTO dto : list) {
			categList.addElement(dto);
		}
		categC.setModel(new DefaultComboBoxModel<CategoryDTO>(categList));
		categC.setBounds(112, 120, 80, 20);
		
		product_qtyT=new JTextField(40);
		product_qtyT.setBounds(112,150,80,20);
		imageT=new JTextField(40);
		imageT.setBounds(112,180,80,20);
 
		jp.add(titleL);
		jp.add(nameL); jp.add(nameT);
		jp.add(priceL); jp.add(priceT);
		jp.add(categoryL); jp.add(categC); 
		jp.add(product_qtyL); jp.add(product_qtyT);
		jp.add(imageL); jp.add(imageT);
		
		addB=new JButton("����ϱ�");
		addB.setBounds(58,226,86,50);
		jp.add(addB);
		
		cancelB=new JButton("���");
		cancelB.setBounds(156,226,60,50);
		jp.add(cancelB);
		
		searchB=new JButton("\uCC3E\uC544\uBCF4\uAE30");
		searchB.setBounds(195,180,80,20);
		jp.add(searchB);
		
		plusB=new JButton("�߰�");
		plusB.setBounds(195,120,60,20);
		jp.add(plusB);
		
		setTitle("��ǰ �߰�");
		setBounds(800, 300, 300, 350);
		setVisible(true);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		event();
	}
	
	public void event() {
		searchB.addActionListener(this);
		addB.addActionListener(this);
		cancelB.addActionListener(this);
		plusB.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==searchB) {
			imageT.setText(openDialog());
		}else if(e.getSource()==addB) {
			if(nameT.getText().equals("")){
				JOptionPane.showMessageDialog(this, "��ǰ�̸��� �Է����ּ���", "��� ����", JOptionPane.WARNING_MESSAGE);
			}else if(priceT.getText().equals("")){
				JOptionPane.showMessageDialog(this, "��ǰ������ �Է����ּ���", "��� ����", JOptionPane.WARNING_MESSAGE);
			}else if(categC.getSelectedIndex()==-1) {
				JOptionPane.showMessageDialog(this, "��ǰ������ ����ּ���", "��� ����", JOptionPane.WARNING_MESSAGE);
			}else if(product_qtyT.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "����� �Է����ּ���", "��� ����", JOptionPane.WARNING_MESSAGE);
			}else if(imageT.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "������ ����ּ���", "��� ����", JOptionPane.WARNING_MESSAGE);
			}else {
				int su=setDTO();
				JOptionPane.showMessageDialog(this, su+"���� ��ǰ�� ��ϵǾ����ϴ�", "��� ����", JOptionPane.INFORMATION_MESSAGE);
				itemMgmt.setList();
				itemMgmt.mainPage.getItemList(0);
				this.dispose();
			}
		}else if(e.getSource()==cancelB) {
			this.dispose();
		}else if(e.getSource()==plusB) {
			new AddCategory(this);
		}
	}
	
	public String openDialog(){
		String path = System.getProperty("user.dir");
		JFileChooser chooser=new JFileChooser(path);
		int result=chooser.showOpenDialog(this);

		if(result==JFileChooser.APPROVE_OPTION){
			file=chooser.getSelectedFile();
			image=file.getName();
			if(!file.getAbsolutePath().equals(System.getProperty("user.dir")+"\\image\\"+image))
				fileCopy(file.getAbsolutePath(), System.getProperty("user.dir")+"\\image\\"+image);
		}
		return image;
	}
	
	public void fileCopy(String inFileName, String outFileName) {
		try {
			FileInputStream fis = new FileInputStream(inFileName);
			FileOutputStream fos = new FileOutputStream(outFileName);
			
			int data = 0;
			while((data=fis.read())!=-1) {
				fos.write(data);
			}
			
			fis.close();
			fos.close();
		   
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//DTO ���� �� DAO���� ItemDB�� �߰�
	public int setDTO() {
		ItemDTO dto=new ItemDTO();
		
		dto.setName(nameT.getText());
		dto.setPrice(Integer.parseInt(priceT.getText()));
		CategoryDTO categoryDto = (CategoryDTO)categC.getSelectedItem();
		dto.setCategory(categoryDto.getCode());
		dto.setProduct_qty(Integer.parseInt(product_qtyT.getText()));
		dto.setImage(imageT.getText());
		
		int su=ItemDAO.getInstance().addItem(dto);
		return su;
	}
	
	public JComboBox<CategoryDTO> getCategC() {
		return categC;
	}
}

















