package admin;

public class Rank {
	
	private int no;
	private int total;
	private int productNo;
	private int ptotal;
	
	public Rank(int no, int total,int productNo, int ptotal) {
		this.no=no;
		this.total=total;
		this.productNo=productNo;
		this.ptotal=ptotal;
	}

	public int getNo() {
		return no;
	}

	public int getTotal() {
		return total;
	}

	public int getProductNo() {
		return productNo;
	}

	public int getPtotal() {
		return ptotal;
	}


}
