package admin;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;

public class AccountMgmt extends JFrame implements ActionListener {
	private JTable table;
	private JButton everyoneSearchB;
	private JButton buyHistoryB;
	private JTextField searchT;
	private JButton searchB;
	private DefaultTableModel dtm;
	private Object[] columnNames = {"ȸ����ȣ", "���̵�", "�̸�", "��ȭ��ȣ", "�̸���", "�ּ�"};
	private Object[][] data = null;
	
	
	public AccountMgmt() {
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.SOUTH);
		
		everyoneSearchB = new JButton("��ü��ȸ");
		everyoneSearchB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		everyoneSearchB.setHorizontalAlignment(SwingConstants.LEADING);
		panel.add(everyoneSearchB);
		
		buyHistoryB = new JButton("�����̷� ��ȸ");
		panel.add(buyHistoryB);
		
		JLabel searchL = new JLabel("  ���̵�");
		searchL.setFont(new Font("����", Font.BOLD, 12));
		panel.add(searchL);
		
		searchT = new JTextField();
		panel.add(searchT);
		searchT.setColumns(10);
		
		searchB = new JButton("�˻�");
		panel.add(searchB);
		
		JScrollPane tableScroll = new JScrollPane();
		getContentPane().add(tableScroll, BorderLayout.CENTER);
		
		dtm = new DefaultTableModel(data, columnNames) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table = new JTable(dtm);
		tableScroll.setViewportView(table);
		setList();
		
		setTitle("ȸ�� ����");
		setBounds(100,100,500,600);
		setVisible(true);
		//setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		event();
	}
	
	public void setList() {
		dtm.setRowCount(0);
		ArrayList<AccountDTO> list = AccountDAO.getInstance().getAccountList();
		if(list!=null) {
			for(AccountDTO dto : list) {
				Object[] rowData = setRowData(dto);
				dtm.addRow(rowData);
			}
		}
	}
	
	public Object[] setRowData(AccountDTO dto) {
		int no = dto.getNo();
		String id = dto.getId();
		String name = dto.getName();
		String tel = dto.getTel1()+"-"+dto.getTel2()+"-"+dto.getTel3();
		String email = dto.getEmail();
		String address = dto.getAddress1()+" "+dto.getAddress2();
		Object[] rowData = {no, id, name, tel, email, address};
		return rowData;
	}
	
	public void event() {
		everyoneSearchB.addActionListener(this);
		buyHistoryB.addActionListener(this);
		searchB.addActionListener(this);
		searchT.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==searchB || e.getSource()==searchT) {
			String id = searchT.getText();
			if(AccountDAO.getInstance().checkId(id)) {
				AccountDTO dto = AccountDAO.getInstance().getAccount(id, null);
				dtm.setRowCount(0);//dtm �ʱ�ȭ
				dtm.addRow(setRowData(dto));
			}else {
				JOptionPane.showMessageDialog(this, "�ش� ���̵� �����ϴ�", "�˻� ����", JOptionPane.INFORMATION_MESSAGE);
			}
		}else if(e.getSource()==everyoneSearchB) {
			setList();
		}else if(e.getSource()==buyHistoryB) {
			int row = table.getSelectedRow();
			if(row>=0) {
				int no = (Integer)table.getValueAt(row, 0);
				new BuyHistory(no);
			}else {
				JOptionPane.showMessageDialog(this, "ȸ���� �������ּ���");
			}
		}
	}
}
