package customer;

import java.awt.event.*;
import javax.swing.*;

import account.LoginForm;
import account.UpdateAccount;
import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;
import java.awt.Font;

public class AccountCheck extends JFrame implements ActionListener {
	private JLabel x1L, pw1;
	private JPasswordField pw1T;
	private JButton okB, cancelB;
	private String passId;
	private String passPw;
	private boolean result;
	private JPasswordField pw2T;
	
	public AccountCheck() {
		setTitle("��й�ȣ Ȯ��");
		pw1 = new JLabel("\uBE44\uBC00\uBC88\uD638 : ");
		pw1.setHorizontalAlignment(SwingConstants.RIGHT);
		pw1.setFont(new Font("����", Font.BOLD, 16));
		x1L = new JLabel("��й�ȣ�� �Է����ּ���");
		
		okB = new JButton("Ȯ��");
		cancelB = new JButton("���");
		
		pw1T = new JPasswordField();

		
		x1L.setBounds(140, 10, 150, 40);
		pw1.setBounds(40, 58, 130, 30);
		pw1T.setBounds(170, 60, 180, 30);

		
		okB.setBounds(109, 150, 100, 40);
		cancelB.setBounds(222, 150, 100, 40);
		
		getContentPane().add(okB);
		getContentPane().add(cancelB);
		getContentPane().add(x1L);
		getContentPane().add(pw1T);
		getContentPane().add(pw1);

		
		getContentPane().setLayout(null);
		
		JLabel pw2 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778 : ");
		pw2.setHorizontalAlignment(SwingConstants.RIGHT);
		pw2.setFont(new Font("����", Font.BOLD, 16));
		pw2.setBounds(40, 98, 130, 30);
		getContentPane().add(pw2);
		
		pw2T = new JPasswordField();
		pw2T.setBounds(170, 98, 180, 30);
		getContentPane().add(pw2T);
		setBounds(700, 100, 450 , 250);
		setVisible(true);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		okB.addActionListener(this);
		pw2T.addActionListener(this);
		cancelB.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==okB || e.getSource()==pw2T) {
			if(pw1T.getText().equals(pw2T.getText())) {
				if(pw1T.getText().equals(LoginForm.getLogin().getPassword())) {
					new UpdateAccount(LoginForm.getLogin());
					this.dispose();
				}else {
					JOptionPane.showMessageDialog(this, "��й�ȣ�� Ʋ�Ƚ��ϴ�", "����", JOptionPane.WARNING_MESSAGE);
				}
			}else {
				JOptionPane.showMessageDialog(this, "��й�ȣ�� ���� �ٸ��ϴ�", "����", JOptionPane.WARNING_MESSAGE);
			}
		}else if(e.getSource()==cancelB) {
			this.dispose();
		}
	}
}
	