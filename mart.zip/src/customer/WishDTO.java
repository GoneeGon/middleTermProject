package customer;

import item.itemDTO.ItemDTO;

public class WishDTO {
	private ItemDTO dto;
	private int num;
	
	public ItemDTO getDto() {
		return dto;
	}
	public void setDto(ItemDTO dto) {
		this.dto = dto;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
}
