package customer;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import item.itemDTO.ItemDTO;

public class WishItemPanel extends JPanel{
	private JCheckBox check;
	private JLabel wishImage;
	private JLabel nameL;
	private JSpinner count;
	private JTextField price;
	private WishDTO dto;
	
	//getter
	public JCheckBox getCheck() {
		return check;
	}
	public JLabel getWishImage() {
		return wishImage;
	}
	public JLabel getNameL() {
		return nameL;
	}
	public JSpinner getCount() {
		return count;
	}
	public JTextField getPrice() {
		return price;
	}
	public WishDTO getDto() {
		return dto;
	}
	
	//setter
	public void setCheck(JCheckBox check) {
		this.check = check;
	}
	public void setWishImage(JLabel wishImage) {
		this.wishImage = wishImage;
	}
	public void setNameL(JLabel nameL) {
		this.nameL = nameL;
	}
	public void setCount(JSpinner count) {
		this.count = count;
	}
	public void setPrice(JTextField price) {
		this.price = price;
	}
	public void setDto(WishDTO dto) {
		this.dto = dto;
	}
	
	//������
	public WishItemPanel(WishDTO dto) {
		this.dto = dto;
		setLayout(null);
		setSize(600, 80);
		setBorder(new LineBorder(Color.GRAY, 1));
		
		//üũ�ڽ�
		check = new JCheckBox();
		check.setBounds(10, 25, 20, 20);
		this.add(check);
		
		//�̹���
		String imageName = dto.getDto().getImage();
		ImageIcon productIcon = new ImageIcon(System.getProperty("user.dir")+"\\image\\"+imageName);
		Image image = productIcon.getImage();
		Image resizedImage = image.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
		wishImage = new JLabel("�ƺ�ī��");
		wishImage.setBounds(70, 0, 80, 80);
		wishImage.setIcon(new ImageIcon(resizedImage));
		wishImage.setBorder(new LineBorder(Color.LIGHT_GRAY, 1));
		this.add(wishImage);
		
		//��ǰ��
		nameL = new JLabel(dto.getDto().getName());
		nameL.setHorizontalAlignment(SwingConstants.CENTER);
		nameL.setBounds(200, 25, 100, 20);
		this.add(nameL);
		
		//����
		count = new JSpinner();
		SpinnerNumberModel numModel = new SpinnerNumberModel(1, 1, 99, 1);//�ʱⰪ, �ּҰ�, �ִ밪, �ܰ�
		count.setModel(numModel);
		count.setValue(dto.getNum());
		count.setBounds(350, 25, 70, 20);
		this.add(count);
		
		//����
		price = new JTextField();
		price.setText(dto.getDto().getPrice()*dto.getNum()+"");
		price.setHorizontalAlignment(JLabel.RIGHT);
		price.setBounds(470, 25, 70, 20);
		price.setEditable(false);
		this.add(price);
	}
}
