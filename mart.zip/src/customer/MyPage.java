package customer;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;

import account.UpdateAccount;
import account.DeleteAccount;
import account.LoginForm;
import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Vector;
import java.awt.event.ActionEvent;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import java.awt.SystemColor;


public class MyPage extends JFrame {
	private JPanel centerPanel, backgroundPanel;
	private JButton deleteButton, updateB;
	private JTextField nameTextField,idTextField,genderTextField,emailTextField1,postTextField,tel1TextField,tel2TextField,tel3TextField,address1TextField,address2TextField,pointTextField,joinDateTextField;
	private JLabel nameLabel,idLabel,genderLabel,emailLabel,postLabel,postDashLabel,phoneLabel,phoneDashLabel1,phoneDashLabel2,addressLabel,pointLabel,joinDateLabel;
	
	private String name,id,email,post,address1,address2,tel1,tel2,tel3,date;
	private int gender,point;
	private Date joinDate;
	private AccountDAO dao = AccountDAO.getInstance();
	private AccountDTO dto;
	private String passId,passPw;
	private MyPage my;
	
	public MyPage(String passId, String passPw) {
		this.my = this;
		
		this.passId = passId;
		this.passPw = passPw;
	
		// �߾� �г�
		centerPanel = new JPanel();
		centerPanel.setBackground(new Color(153, 204, 153));
		centerPanel.setBounds(33, 24, 495, 581);
		getContentPane().add(centerPanel);
		centerPanel.setLayout(null);
		
		// �̸� ��
		nameLabel = new JLabel("��   �� :");
		nameLabel.setForeground(Color.WHITE);
		nameLabel.setFont(new Font("����", Font.BOLD, 16));
		nameLabel.setBounds(12, 33, 70, 39);
		centerPanel.add(nameLabel);
		
		// �̸� �ؽ�Ʈ �ʵ�
		nameTextField = new JTextField();
		nameTextField.setEditable(false);
		nameTextField.setFont(new Font("����", Font.PLAIN, 16));
		nameTextField.setHorizontalAlignment(SwingConstants.CENTER);
		nameTextField.setBounds(89, 33, 125, 39);
		centerPanel.add(nameTextField);
		nameTextField.setColumns(10);
		
		
		// ���̵� ��
		idLabel = new JLabel("���̵� :");
		idLabel.setForeground(Color.WHITE);
		idLabel.setFont(new Font("����", Font.BOLD, 16));
		idLabel.setBounds(12, 90, 70, 39);
		centerPanel.add(idLabel);
		
		// ���̵� �ؽ�Ʈ �ʵ�
		idTextField = new JTextField();
		idTextField.setEditable(false);
		idTextField.setFont(new Font("����", Font.PLAIN, 16));
		idTextField.setHorizontalAlignment(SwingConstants.CENTER);
		idTextField.setText((String) null);
		idTextField.setColumns(10);
		idTextField.setBounds(89, 90, 125, 39);
		centerPanel.add(idTextField);
		
		// ���� ��
		genderLabel = new JLabel("\uC131   \uBCC4 :");
		genderLabel.setForeground(Color.WHITE);
		genderLabel.setFont(new Font("����", Font.BOLD, 16));
		genderLabel.setBounds(12, 139, 70, 39);
		centerPanel.add(genderLabel);
		
		// ���� �ؽ�Ʈ �ʵ�
		genderTextField = new JTextField();
		genderTextField.setEditable(false);
		genderTextField.setFont(new Font("����", Font.PLAIN, 16));
		genderTextField.setHorizontalAlignment(SwingConstants.CENTER);
		genderTextField.setText((String) null);
		genderTextField.setColumns(10);
		genderTextField.setBounds(89, 139, 125, 39);
		centerPanel.add(genderTextField);
		
		// �̸��� ��
		emailLabel = new JLabel("\uC774\uBA54\uC77C :");
		emailLabel.setForeground(Color.WHITE);
		emailLabel.setFont(new Font("����", Font.BOLD, 16));
		emailLabel.setBounds(12, 196, 70, 39);
		centerPanel.add(emailLabel);
		
		// �̸��� �ؽ�Ʈ �ʵ�1
		emailTextField1 = new JTextField();
		emailTextField1.setEditable(false);
		emailTextField1.setFont(new Font("����", Font.PLAIN, 16));
		emailTextField1.setHorizontalAlignment(SwingConstants.CENTER);
		emailTextField1.setText((String) null);
		emailTextField1.setColumns(10);
		emailTextField1.setBounds(89, 196, 195, 39);
		centerPanel.add(emailTextField1);
		
		// ������ȣ1 ��
		postLabel = new JLabel("\uC6B0\uD3B8\uBC88\uD638:");
		postLabel.setForeground(Color.WHITE);
		postLabel.setFont(new Font("����", Font.BOLD, 16));
		postLabel.setBounds(12, 263, 82, 39);
		centerPanel.add(postLabel);
		
		// ������ȣ1 �ؽ�Ʈ �ʵ�
		postTextField = new JTextField();
		postTextField.setEditable(false);
		postTextField.setFont(new Font("����", Font.PLAIN, 16));
		postTextField.setHorizontalAlignment(SwingConstants.CENTER);
		postTextField.setText((String) null);
		postTextField.setColumns(10);
		postTextField.setBounds(89, 264, 125, 39);
		centerPanel.add(postTextField);
		
		// ������ȣ - ��
		postDashLabel = new JLabel("-");
		postDashLabel.setFont(new Font("����", Font.PLAIN, 16));
		postDashLabel.setBounds(183, 263, 18, 39);
		centerPanel.add(postDashLabel);
		
		// ����ó ��
		phoneLabel = new JLabel("\uC804\uD654\uBC88\uD638:");
		phoneLabel.setForeground(Color.WHITE);
		phoneLabel.setFont(new Font("����", Font.BOLD, 16));
		phoneLabel.setBounds(12, 329, 82, 39);
		centerPanel.add(phoneLabel);
		
		// ����ó1 �ؽ�Ʈ �ʵ�
		tel1TextField = new JTextField();
		tel1TextField.setEditable(false);
		tel1TextField.setFont(new Font("����", Font.PLAIN, 16));
		tel1TextField.setHorizontalAlignment(SwingConstants.CENTER);
		tel1TextField.setText((String) null);
		tel1TextField.setColumns(10);
		tel1TextField.setBounds(89, 329, 82, 39);
		centerPanel.add(tel1TextField);
		
		// ����ó ù��° - ��
		phoneDashLabel1 = new JLabel("-");
		phoneDashLabel1.setFont(new Font("����", Font.PLAIN, 16));
		phoneDashLabel1.setBounds(172, 329, 18, 39);
		centerPanel.add(phoneDashLabel1);
		
		// ����ó2 �ؽ�Ʈ �ʵ�
		tel2TextField = new JTextField();
		tel2TextField.setEditable(false);
		tel2TextField.setFont(new Font("����", Font.PLAIN, 16));
		tel2TextField.setHorizontalAlignment(SwingConstants.CENTER);
		tel2TextField.setText((String) null);
		tel2TextField.setColumns(10);
		tel2TextField.setBounds(182, 329, 82, 39);
		centerPanel.add(tel2TextField);
		
		// ����ó �ι�° - ��
		phoneDashLabel2 = new JLabel("-");
		phoneDashLabel2.setFont(new Font("����", Font.PLAIN, 16));
		phoneDashLabel2.setBounds(266, 329, 18, 39);
		centerPanel.add(phoneDashLabel2);
		
		// ����ó3 �ؽ�Ʈ �ʵ�
		tel3TextField = new JTextField();
		tel3TextField.setEditable(false);
		tel3TextField.setFont(new Font("����", Font.PLAIN, 16));
		tel3TextField.setHorizontalAlignment(SwingConstants.CENTER);
		tel3TextField.setText((String) null);
		tel3TextField.setColumns(10);
		tel3TextField.setBounds(276, 329, 82, 39);
		centerPanel.add(tel3TextField);
		
		// �ּ� ��
		addressLabel = new JLabel("\uC8FC   \uC18C :");
		addressLabel.setForeground(Color.WHITE);
		addressLabel.setFont(new Font("����", Font.BOLD, 16));
		addressLabel.setBounds(12, 378, 70, 39);
		centerPanel.add(addressLabel);
		
		// �ּ�1 �ؽ�Ʈ �ʵ�
		address1TextField = new JTextField();
		address1TextField.setEditable(false);
		address1TextField.setFont(new Font("����", Font.PLAIN, 16));
		address1TextField.setHorizontalAlignment(SwingConstants.CENTER);
		address1TextField.setText((String) null);
		address1TextField.setColumns(10);
		address1TextField.setBounds(89, 378, 346, 39);
		centerPanel.add(address1TextField);

		// �ּ�2 �ؽ�Ʈ �ʵ�
		address2TextField = new JTextField();
		address2TextField.setEditable(false);
		address2TextField.setFont(new Font("����", Font.PLAIN, 16));
		address2TextField.setHorizontalAlignment(SwingConstants.CENTER);
		address2TextField.setText((String) null);
		address2TextField.setColumns(10);
		address2TextField.setBounds(89, 427, 346, 39);
		centerPanel.add(address2TextField);
		
		// ����Ʈ ��
		pointLabel = new JLabel("\uD3EC\uC778\uD2B8 :");
		pointLabel.setForeground(Color.WHITE);
		pointLabel.setFont(new Font("����", Font.BOLD, 16));
		pointLabel.setBounds(12, 474, 70, 39);
		centerPanel.add(pointLabel);
		
		// ����Ʈ �ؽ�Ʈ �ʵ�
		pointTextField = new JTextField();
		pointTextField.setEditable(false);
		pointTextField.setFont(new Font("����", Font.PLAIN, 16));
		pointTextField.setHorizontalAlignment(SwingConstants.CENTER);
		pointTextField.setText((String) null);
		pointTextField.setColumns(10);
		pointTextField.setBounds(89, 476, 82, 39);
		centerPanel.add(pointTextField);
		
		// �������� ��
		joinDateLabel = new JLabel("\uAC00\uC785\uC77C\uC790:");
		joinDateLabel.setForeground(Color.WHITE);
		joinDateLabel.setFont(new Font("����", Font.BOLD, 16));
		joinDateLabel.setBounds(12, 523, 82, 39);
		centerPanel.add(joinDateLabel);
		
		// �������� �ؽ�Ʈ �ʵ�
		joinDateTextField = new JTextField();
		joinDateTextField.setEditable(false);
		joinDateTextField.setFont(new Font("����", Font.PLAIN, 16));
		joinDateTextField.setHorizontalAlignment(SwingConstants.CENTER);
		joinDateTextField.setText((String) null);
		joinDateTextField.setColumns(10);
		joinDateTextField.setBounds(89, 525, 125, 39);
		centerPanel.add(joinDateTextField);

		// ���������� ��ư(����)
		deleteButton = new JButton("\uD68C\uC6D0\uD0C8\uD1F4");
		deleteButton.setIcon(null);
		deleteButton.setBounds(439, 617, 89, 39);
		getContentPane().add(deleteButton);
		
		updateB = new JButton("\uC815\uBCF4\uBCC0\uACBD");
		updateB.setIcon(null);
		updateB.setBounds(320, 617, 89, 39);
		getContentPane().add(updateB);
		
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DeleteAccount();
			}
		});
		updateB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new AccountCheck();
			}
		});
		
		String backgroundImgPath = System.getProperty("user.dir");
		ImageIcon backgroundIcon = new ImageIcon(backgroundImgPath+"\\image\\vegitable.jpg");
		backgroundPanel = new JPanel(){
			public void paintComponent(Graphics g) {
				g.drawImage(backgroundIcon.getImage(),0,0,null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		backgroundPanel.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		backgroundPanel.setBounds(12, 10, 1248, 673);
		backgroundPanel.setLayout(null);
		getContentPane().add(backgroundPanel);

		getCustomerInfo();
		
		setTitle("MyPage_Customer");
		setVisible(true);
		setResizable(false);
		setBounds(100, 100, 580, 720);
		//setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				my.dispose();
			}
		});
		//�α��ν�, DB���� ȸ�� ���� ��������
	}//������
	

	//DB���� ȸ�� ������ �������� �޼ҵ�(���� �׽�Ʈ ���̵�-ȸ���� 1���� ����)
	public void getCustomerInfo() {
		AccountDAO dao =AccountDAO.getInstance();
		AccountDTO login = dao.getAccount(LoginForm.getLogin().getNo());
				
		if(login!=null) {
			name = login.getName();
			id=login.getId();
			email=login.getEmail();
			post=login.getPost();
			address1=login.getAddress1();
			address2=login.getAddress2();
			tel1=login.getTel1();
			tel2=login.getTel2();
			tel3=login.getTel3();
			gender=login.getGender();
			point=login.getPoint();
			joinDate = login.getJoindate();
			date=joinDate.toString();
						
			nameTextField.setText(name);
			idTextField.setText(id);
			emailTextField1.setText(email);
			postTextField.setText(post);
			address1TextField.setText(address1);
			address2TextField.setText(address2);
			tel1TextField.setText(tel1);
			tel2TextField.setText(tel2);
			tel3TextField.setText(tel3);
			if(gender==0) genderTextField.setText("����");
			if(gender==1) genderTextField.setText("����");
			pointTextField.setText(login.getPoint()+"");
			joinDateTextField.setText(date);
		}
	}//�޼ҵ�
}
