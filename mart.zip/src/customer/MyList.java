package customer;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import account.LoginForm;
import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;
import item.buylistDAO.BuyListDAO;
import item.itemDAO.ItemDAO;
import item.itemDTO.ItemDTO;
import order.OrderClient;

public class MyList extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JButton orderB, deleteB, cancelB;
	private JPanel borderP;
	private JPanel southP;
	private JLabel totalPriceL;
	private JTextField totalPriceT;
	private JLabel totalCountL;
	private JTextField totalCountT;
	private JPanel mainP;
	private JLabel infoL;
	private JCheckBox wholeC;
	private JLabel countL;
	private JLabel priceL;
	private JPanel itemP;
	
	//private ArrayList<ItemDTO> itemList;
	private ArrayList<WishDTO> wishList;
	private ArrayList<WishItemPanel> panelList;
	private ChangeListener listener;
	private MyList my = this;

	public MyList(ArrayList<WishDTO> wishList) {
		this.wishList=wishList;
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		//�ϴ� ��ư �߰�
		JPanel buttonP = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		contentPane.add(buttonP, BorderLayout.SOUTH);
		
		orderB = new JButton("�ֹ��ϱ�");
		buttonP.add(orderB);
		
		deleteB = new JButton("����");
		buttonP.add(deleteB);
		
		cancelB = new JButton("���");
		buttonP.add(cancelB);
		
		//��� BorderLayout
		borderP = new JPanel(new BorderLayout());
		contentPane.add(borderP, BorderLayout.CENTER);
		
		//�Ʒ� �г� (���ŷ�, �����ݾ�)
		southP = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		borderP.add(southP, BorderLayout.SOUTH);
		
		totalCountL = new JLabel("�� ���ŷ� : ");
		southP.add(totalCountL);
		
		totalCountT = new JTextField();
		southP.add(totalCountT);
		totalCountT.setEditable(false);
		totalCountT.setColumns(10);
		totalCountT.setHorizontalAlignment(JLabel.RIGHT);
		
		totalPriceL = new JLabel("    �����ݾ� : ");
		southP.add(totalPriceL);
		
		totalPriceT = new JTextField();
		southP.add(totalPriceT);
		totalPriceT.setEditable(false);
		totalPriceT.setColumns(10);
		totalPriceT.setHorizontalAlignment(JLabel.RIGHT);
		
		//���� �г�
		mainP = new JPanel(null);
		borderP.add(mainP, BorderLayout.CENTER);
		
		//�÷���
		JPanel labelP = new JPanel(null);
		labelP.setBounds(0, 0, 600, 30);
		wholeC = new JCheckBox("");
		wholeC.setSize(20, 20);
		wholeC.setLocation(10, 5);
		labelP.add(wholeC);
		
		infoL = new JLabel("��ǰ�̹���");
		infoL.setHorizontalAlignment(SwingConstants.CENTER);
		infoL.setFont(new Font("����", Font.BOLD, 14));
		infoL.setSize(80, 20);
		infoL.setLocation(70, 5);
		labelP.add(infoL);
		
		JLabel itemNameL = new JLabel("��ǰ��");
		itemNameL.setHorizontalAlignment(SwingConstants.CENTER);
		itemNameL.setFont(new Font("����", Font.BOLD, 14));
		itemNameL.setBounds(200, 5, 100, 20);
		labelP.add(itemNameL);
		
		countL = new JLabel("����");
		countL.setHorizontalAlignment(SwingConstants.CENTER);
		countL.setLocation(350, 5);
		countL.setSize(70, 20);
		countL.setFont(new Font("����", Font.BOLD, 14));
		labelP.add(countL);
		
		priceL = new JLabel("��ǰ����");
		priceL.setHorizontalAlignment(SwingConstants.CENTER);
		priceL.setFont(new Font("����", Font.BOLD, 14));
		priceL.setBounds(470, 5, 70, 20);
		labelP.add(priceL);
		
		mainP.add(labelP);
		
		//��ٱ��� ����
		itemP = new JPanel(null);
		itemP.setBackground(Color.WHITE);
		JScrollPane mainScroll = new JScrollPane(itemP);
		mainScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		mainScroll.setBounds(0, 30, 574, 450);
		mainP.add(mainScroll);
		/*
		itemList = new ArrayList<ItemDTO>();
		for(WishDTO dto : wishList) {
			itemList.add(dto.getDto());
		}
		*/
		//itemList = ItemDAO.getInstance().getItemList(1); //�ӽ� ����Ʈ ����  ��ǰ�ڵ� 1�� ��ǰ����Ʈ
		panelList = new ArrayList<WishItemPanel>();
		event();
		setPanel(wishList);
		
		setResult();
		
		
		setTitle("��ٱ���");
		setVisible(true);
	}
	
	//�̺�Ʈ ������ �߰�
	public void event() {
		orderB.addActionListener(this);
		deleteB.addActionListener(this);
		cancelB.addActionListener(this);
		wholeC.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getComponent()==wholeC) {
					if(wholeC.isSelected()) {
						for(WishItemPanel p : panelList) {
							p.getCheck().setSelected(true);
						}
					}else {
						for(WishItemPanel p : panelList) {
							p.getCheck().setSelected(false);
						}
					}
				}
			}
		});
		
		//��������� �۵�
		listener = new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				JSpinner tmpS = (JSpinner)e.getSource();
				int cnt = (int)tmpS.getValue();
				for(WishItemPanel p : panelList) {
					if(p.getCount()==tmpS) {
						p.getPrice().setText(p.getDto().getDto().getPrice()*cnt+"");
						p.updateUI();
					}
				}
				setResult();
				itemP.updateUI();
			}
		};
		
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				itemP.removeAll();
				my.dispose();
			}
		});
	}
	
	//���ø���Ʈ�� ����ִ� ���������� �гη� ����
	public void setPanel(ArrayList<WishDTO> wishList) {
		int y=0;
		itemP.removeAll();
		
		for(WishDTO dto : wishList) {
			WishItemPanel tempP = new WishItemPanel(dto);
			tempP.setLocation(0, y);
			itemP.add(tempP);
			panelList.add(tempP);
			tempP.getCount().addChangeListener(listener);
			y+=80;
		}
	}
	
	//�гθ���Ʈ�� ����ִ� ������ ���ؼ� �Ѽ���, �� �����ݾ� ����
	public void setResult() {
		int totalPrice=0, totalCount=0;
		for(WishItemPanel p : panelList) {
			int count = (int)p.getCount().getValue();
			totalCount += count;
			totalPrice += Integer.parseInt(p.getPrice().getText());
		}
		totalCountT.setText(totalCount+"");
		totalPriceT.setText(totalPrice+"");
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==orderB) {
			AccountDTO login = LoginForm.getLogin();
			if(login!=null) {
				int no = login.getNo();
				//���Ȯ��
				for(WishItemPanel p : panelList) {
					ItemDTO dto = p.getDto().getDto();
					int num = (Integer)p.getCount().getValue(); //�ֹ�����
					int qty = ItemDAO.getInstance().checkStock(dto.getSeq()); //�������
					if(num > qty) {
						JOptionPane.showMessageDialog(this, dto.getName()+" ����� �����մϴ� [���� ���� : "+qty+" ]", "�������", JOptionPane.WARNING_MESSAGE);
						return;
					}
				}
				//�ֹ�
				int loopCount = panelList.size();
				for(int i=loopCount-1 ; i>=0; i--) {
					WishItemPanel p = panelList.get(i);
					ItemDTO dto = p.getDto().getDto();
					int num = (Integer)p.getCount().getValue(); //�ֹ�����
					int qty = ItemDAO.getInstance().checkStock(dto.getSeq()); //�������
					BuyListDAO.getInstance().orderItem(no, dto, num);
					AccountDTO accountDto = AccountDAO.getInstance().getAccount(no);
					AccountDAO.getInstance().givePoint(accountDto, (int)(dto.getPrice()*num*0.1)); //����Ʈ����
					wishList.remove(p.getDto());
					panelList.remove(p);
					p.getCount().removeChangeListener(listener);
				}
				JOptionPane.showMessageDialog(this, "�ֹ��� ����ó�� �Ǿ����ϴ�", "�ֹ� �Ϸ�", JOptionPane.INFORMATION_MESSAGE);
				setPanel(wishList);
				setResult();
				itemP.updateUI();
				new OrderClient(LoginForm.getLogin());
			}
		}else if(e.getSource()==deleteB) {
			int loopCount = panelList.size();
			for(int i=loopCount-1 ; i>=0; i--) {
				WishItemPanel p = panelList.get(i);
				if(p.getCheck().isSelected()) {
					wishList.remove(p.getDto());
				}
				panelList.remove(p);
				p.getCount().removeChangeListener(listener);
			}
			setPanel(wishList);
			setResult();
			itemP.updateUI();
		}else if(e.getSource()==cancelB) {
			this.dispose();
		}
	}
}
