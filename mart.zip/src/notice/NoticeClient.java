package notice;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

import javax.swing.*;

import account.LoginForm;
import account.accountDTO.AccountDTO;

public class NoticeClient extends JFrame {
	private Socket socket;
	private String ip = LoginForm.getServerIp();;
	private int port = 9900;
	
	private DataInputStream in;
	private DataOutputStream out;
	private String msg;
	
	private String id;
	
	public NoticeClient(){
		setBounds(100,100,450,500);
		setTitle("��������");
		
		JScrollPane scrollPane = new JScrollPane();
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setEditable(false);
		
		try {
			socket = new Socket(ip, port);
			in = new DataInputStream(socket.getInputStream());
			String notice = in.readUTF();
			textArea.setText(notice);
			
			in.close();
			socket.close();
		} catch (UnknownHostException e) {
			return;
		} catch (IOException e) {
			return;
		}
		
		setVisible(true);
	}
}
