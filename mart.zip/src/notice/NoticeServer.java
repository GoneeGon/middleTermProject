package notice;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JOptionPane;

import admin.MainPage_Admin;
import customer.MyPage;

public class NoticeServer extends Thread {
	private ServerSocket ss;
	private Socket socket;
	private int port = 9900;
	private MainPage_Admin admin;
	
	public NoticeServer(MainPage_Admin admin) {
		this.admin = admin;
	}
		
	@Override
	public void run() {
		try {
			ss = new ServerSocket(port);
			
			while(true) {
				socket = ss.accept(); //Ŭ���̾�Ʈ�� ���� ���
				
				DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
				String notice = admin.getNoticeT().getText();
				dos.writeUTF(notice);
				dos.flush();
				dos.close();
				socket.close();				
			}
		} catch (IOException e) {
			//e.printStackTrace();
		}
	}
}
