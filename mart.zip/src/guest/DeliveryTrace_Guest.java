package guest;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import account.LoginForm;
import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;
import admin.YmdDAO;
import admin.YmdDTO;
import item.buylistDAO.BuyListDAO;
import item.buylistDTO.BuyListDTO;
import item.categoryDAO.CategoryDAO;

public class DeliveryTrace_Guest extends JFrame implements ActionListener, ListSelectionListener {
	
	private int no; // ȸ����ȣ
	private JPanel contentPane;
	private JScrollPane tableScroll;
	private JTable table;
	private Object[] columnNames = {"�ֹ���ȣ","�� ��", "��ǰ ��ȣ", "��ǰ �̸�","�� ��","���ż���","������","��ۻ���"};
	private Object[][] data = null;
	private DefaultTableModel dtm;
	private ArrayList<BuyListDTO> list;
	private AccountDTO dto;
	private JButton cancelB;
	
	public DeliveryTrace_Guest(ArrayList<BuyListDTO> list, AccountDTO dto) {
		this.list=list;
		this.dto=dto;
		setTitle("��� ��ȸ");
		setBounds(100,100,800,600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		cancelB = new JButton("�ֹ����");
		cancelB.setFont(new Font("����", Font.BOLD, 14));
		cancelB.setEnabled(false);
		panel.add(cancelB);
		contentPane.add(panel, BorderLayout.SOUTH);
		
		tableScroll = new JScrollPane();
		contentPane.add(tableScroll,BorderLayout.CENTER);
		
		dtm = new DefaultTableModel(data, columnNames) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table = new JTable(dtm);
		tableScroll.setViewportView(table);
		
		cancelB.addActionListener(this);
		table.getSelectionModel().addListSelectionListener(this);	
		
		setList(list);
		setVisible(true);
	}
		
	//���õ� ��۳������� ����
	public void setList(ArrayList<BuyListDTO> list) {
		dtm.setRowCount(0);
		AccountDAO accountDao = AccountDAO.getInstance();
		
		if(list!=null) {
			for(BuyListDTO dto : list) {
				int no = dto.getNo();
				AccountDTO dto2 = accountDao.getAccount(no);
				dtm.addRow(setRowData(dto,dto2));
			}
		}
	}
		
	
	public Object[] setRowData(BuyListDTO dto, AccountDTO dto2) {
		int num = dto.getNum();
		int seq = dto.getSeq();
		String name = dto.getName();
		String name2 = dto2.getName();
		int price = dto.getPrice();
		int count = dto.getCount();
		Date buytime = dto.getBuytime();
		int delivery_stmt = dto.getDelivery_stmt();
		String delivery=null;
		if (delivery_stmt == 0) {
			delivery = "�غ���";
		}else if(delivery_stmt == 1) {
			delivery = "�����";
		}else if(delivery_stmt == 2) {
			delivery = "��ۿϷ�";
		}else if(delivery_stmt == 3) {
			delivery = "���";
		}
		Object[] rowData = {num, name2, seq, name, price, count, buytime, delivery};
		return rowData;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		int row = table.getSelectedRow();
		if(row>=0) {
			int num = (int)table.getValueAt(row, 0); //�ֹ���ȣ
			ArrayList<BuyListDTO> list = BuyListDAO.getInstance().getGuestBuyList(dto);
			BuyListDAO.getInstance().setDeliveryStmt(num, 3);
			setList(list);
			table.updateUI();
		}
	}
	
	@Override
	public void valueChanged(ListSelectionEvent e) {
		int row = table.getSelectedRow();
		if(dtm.getRowCount() > 0 && row >= 0) {
			String stmt = (String)table.getValueAt(row, 7);
			int delivery_stmt=0;
			if(stmt.equals("�غ���"))
				delivery_stmt=0;
			else delivery_stmt=1;
			
			if(delivery_stmt==0) {
				cancelB.setEnabled(true);
			}else {
				cancelB.setEnabled(false);
			}
		}
	}
}
