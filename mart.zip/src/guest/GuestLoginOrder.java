package guest;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import account.LoginForm;
import account.PostSearch;
import account.accountDTO.AccountDTO;
import customer.WishDTO;
import customer.WishItemPanel;
import account.accountDAO.*;
import guest.MyList_Guest;
import item.buylistDAO.BuyListDAO;
import item.itemDAO.ItemDAO;
import item.itemDTO.ItemDTO;
import order.OrderClient;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;

public class GuestLoginOrder extends JFrame implements ActionListener{
	private JTextField tel2;
	private JTextField tel3;
	private JTextField nameT;
	private JComboBox<String> tel1; 
	private JButton joinB;
	private JButton cancelB, PostSearch;
	private AccountDAO dao = AccountDAO.getInstance();
	private JTextField postT;
	private JTextField addressT1;
	private JTextField addressT2;
	
	private ArrayList<ItemDTO> itemList;
	private MyList_Guest my;
	
	public GuestLoginOrder(MyList_Guest my) {
		this.my=my;
		getContentPane().setLayout(null);
		
		JLabel name = new JLabel("\uC774\uB984 :\r\n");
		name.setHorizontalAlignment(SwingConstants.RIGHT);
		name.setFont(new Font("����", Font.BOLD, 14));
		name.setBounds(30, 60, 80, 15);
		getContentPane().add(name);
		
		JLabel tel = new JLabel("\uBC88\uD638 :\r\n");
		tel.setHorizontalAlignment(SwingConstants.RIGHT);
		tel.setFont(new Font("����", Font.BOLD, 14));
		tel.setBounds(30, 100, 80, 15);
		getContentPane().add(tel);
		
		tel2 = new JTextField();
		tel2.setBounds(195, 98, 45, 21);
		getContentPane().add(tel2);
		tel2.setColumns(10);
		
		tel3 = new JTextField();
		tel3.setBounds(260, 98, 45, 21);
		getContentPane().add(tel3);
		tel3.setColumns(10);
		
		nameT = new JTextField();
		nameT.setBounds(122, 58, 116, 21);
		getContentPane().add(nameT);
		nameT.setColumns(10);
		
		DefaultComboBoxModel<String> dcb = new DefaultComboBoxModel<>(new String[] {"010", "011", "016", "017", "019"});
		tel1 = new JComboBox<String>(dcb);
		tel1.setBounds(122, 98, 53, 21);
		getContentPane().add(tel1);
		
		joinB = new JButton("\uC644\uB8CC");
		joinB.setBounds(122, 254, 65, 23);
		getContentPane().add(joinB);
		
		cancelB = new JButton("\uCDE8\uC18C\r\n");
		cancelB.setBounds(213, 254, 65, 23);
		getContentPane().add(cancelB);
		
		JLabel post = new JLabel("\uC6B0\uD3B8\uBC88\uD638 :\r\n");
		post.setHorizontalAlignment(SwingConstants.RIGHT);
		post.setFont(new Font("����", Font.BOLD, 14));
		post.setBounds(30, 138, 80, 15);
		getContentPane().add(post);
		
		postT = new JTextField();
		postT.setBounds(122, 136, 116, 21);
		getContentPane().add(postT);
		postT.setColumns(10);
		
		PostSearch = new JButton("\uC8FC\uC18C \uCC3E\uAE30");
		PostSearch.setBounds(250, 135, 95, 23);
		getContentPane().add(PostSearch);
		
		JLabel address = new JLabel("\uC8FC\uC18C :");
		address.setHorizontalAlignment(SwingConstants.RIGHT);
		address.setFont(new Font("����", Font.BOLD, 14));
		address.setBounds(30, 175, 80, 15);
		getContentPane().add(address);
		
		addressT1 = new JTextField();
		addressT1.setBounds(122, 173, 226, 21);
		getContentPane().add(addressT1);
		addressT1.setColumns(10);
		
		addressT2 = new JTextField();
		addressT2.setBounds(122, 204, 226, 21);
		getContentPane().add(addressT2);
		addressT2.setColumns(10);
		
		JLabel dashL = new JLabel("-");
		dashL.setHorizontalAlignment(SwingConstants.CENTER);
		dashL.setBounds(175, 101, 20, 15);
		getContentPane().add(dashL);
		
		JLabel label = new JLabel("-");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(240, 101, 20, 15);
		getContentPane().add(label);
		
		setTitle("��ȸ�� �ֹ� ���");
		addListener();
		setResizable(false);
		setVisible(true);
		setBounds(100, 100, 425, 350);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);	 
	}
	private void addListener() {
		joinB.addActionListener(this);
		cancelB.addActionListener(this);
		PostSearch.addActionListener(this);
	}
	
	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==joinB) {
			int reply = JOptionPane.showConfirmDialog(this, "�̸��� ��ȭ��ȣ�� �����ȸ�� �� �ʿ��� �����Դϴ�.\n�ùٸ��� �Է��ϼ̽��ϱ�?", "�ֹ� ���� Ȯ��", JOptionPane.OK_CANCEL_OPTION);
			if(reply==JOptionPane.CANCEL_OPTION) return;
			if(reply==JOptionPane.CLOSED_OPTION) return;
			if(checkInputForm()) {
				String name = nameT.getText();
				String tel1 = (String)this.tel1.getSelectedItem();
				String tel2 = this.tel2.getText();
				String tel3 = this.tel3.getText();
				String post = postT.getText();
				String address1 = addressT1.getText();
				String address2 = addressT2.getText();
				
				
				AccountDTO dto = new AccountDTO();
				dto.setName(name);
				dto.setTel1(tel1);
				dto.setTel2(tel2);
				dto.setTel3(tel3);
				dto.setPost(post);
				dto.setAddress1(address1);
				dto.setAddress2(address2);
				AccountDAO dao = AccountDAO.getInstance();
				if(dao.getAccount2(dto) > 0) {
					int no = AccountDAO.getInstance().getNowSeq()-1;
					AccountDTO login = AccountDAO.getInstance().getAccount(no);
					my.order(login);
					new OrderClient(login);
					this.dispose();
				}else 
					JOptionPane.showMessageDialog(this, "�α��� ����", "��ȸ���α���", JOptionPane.WARNING_MESSAGE);
			}
	
		}else if(e.getSource()==cancelB) {
			this.dispose();
		}else if(e.getSource()==PostSearch) {
			new PostSearch(postT, addressT1);
		}
	}
	private boolean checkInputForm() {
		boolean check=true;
		
		if(nameT.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "�̸��� �Է��ϼ���", "�̸� Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
			
		}else if(tel2.getText().equals("") || tel3.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "��ȭ��ȣ�� �Է��ϼ���", "��ȭ��ȣ Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(postT.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "������ȣ�� �Է��ϼ���", "������ȣ Ȯ��", JOptionPane.WARNING_MESSAGE);
			check = false;
		}else if(addressT1.getText().equals("") || addressT2.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "�ּҸ� �Է��ϼ���", "�ּ� Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}
		return check;
	}
}
