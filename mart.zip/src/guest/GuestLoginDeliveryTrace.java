package guest;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import account.LoginForm;
import account.accountDTO.AccountDTO;
import account.accountDAO.*;
import item.buylistDAO.BuyListDAO;
import item.buylistDTO.BuyListDTO;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;

public class GuestLoginDeliveryTrace extends JFrame implements ActionListener{
	private JTextField tel2;
	private JTextField tel3;
	private JTextField nameT;
	private JComboBox<String> tel1; 
	private JButton enterB;
	private JButton cancelB;
	private AccountDAO dao = AccountDAO.getInstance();
	
	
	public GuestLoginDeliveryTrace() {
		getContentPane().setLayout(null);
		
		JLabel name = new JLabel("\uC774\uB984 :\r\n");
		name.setFont(new Font("����", Font.BOLD, 14));
		name.setHorizontalAlignment(SwingConstants.RIGHT);
		name.setBounds(30, 40, 60, 15);
		getContentPane().add(name);
		
		JLabel tel = new JLabel("\uBC88\uD638 :\r\n");
		tel.setHorizontalAlignment(SwingConstants.RIGHT);
		tel.setFont(new Font("����", Font.BOLD, 14));
		tel.setBounds(30, 85, 60, 15);
		getContentPane().add(tel);
		
		tel2 = new JTextField();
		tel2.setBounds(165, 83, 45, 21);
		getContentPane().add(tel2);
		tel2.setColumns(10);
		
		tel3 = new JTextField();
		tel3.setBounds(225, 83, 45, 21);
		getContentPane().add(tel3);
		tel3.setColumns(10);
		
		nameT = new JTextField();
		nameT.setBounds(100, 38, 100, 21);
		getContentPane().add(nameT);
		nameT.setColumns(10);
		
		DefaultComboBoxModel<String> dcb = new DefaultComboBoxModel<>(new String[] {"010", "011", "016", "017", "019"});
		tel1 = new JComboBox<String>(dcb);
		tel1.setBounds(100, 83, 50, 21);
		getContentPane().add(tel1);
		
		enterB = new JButton("Ȯ ��");
		enterB.setBounds(90, 125, 70, 30);
		getContentPane().add(enterB);
		
		cancelB = new JButton("�� ��");
		cancelB.setBounds(170, 125, 70, 30);
		getContentPane().add(cancelB);
		
		JLabel label = new JLabel("-");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(150, 86, 15, 15);
		getContentPane().add(label);
		
		JLabel label_1 = new JLabel("-");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setBounds(210, 86, 15, 15);
		getContentPane().add(label_1);
		
		setTitle("��ȸ�� ��� ��ȸ");
		addListener();
		setResizable(false);
		setVisible(true);
		setBounds(100, 100, 335, 200);		 
	}
	private void addListener() {
		enterB.addActionListener(this);
		cancelB.addActionListener(this);
	}
	
	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==enterB) {
			if(checkInputForm()) {
				String name = nameT.getText();
				String tel1 = (String)this.tel1.getSelectedItem();
				String tel2 = this.tel2.getText();
				String tel3 = this.tel3.getText();
				
				
				AccountDTO dto = new AccountDTO();
				dto.setName(name);
				dto.setTel1(tel1);
				dto.setTel2(tel2);
				dto.setTel3(tel3);
				
			    BuyListDAO dao = BuyListDAO.getInstance();			    
			    ArrayList<BuyListDTO> list = dao.getGuestBuyList(dto);
			    if(list==null) {
			    	JOptionPane.showMessageDialog(this, "�ֹ������� �����ϴ�.\n������ �ٽ� �ѹ� Ȯ�����ּ���", "�����ȸ ����", JOptionPane.WARNING_MESSAGE);
			    }else {
			    	new DeliveryTrace_Guest(list,dto);
			    	this.dispose();
			    }
			}
			
		}else if(e.getSource()==cancelB) {
			dispose();
		}
	}
	private boolean checkInputForm() {
		boolean check=true;
		
		if(nameT.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "�̸��� �Է��ϼ���", "�̸� Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(tel2.getText().equals("") || tel3.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "��ȭ��ȣ�� �Է��ϼ���", "��ȭ��ȣ Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}
		return check;
	}
}
