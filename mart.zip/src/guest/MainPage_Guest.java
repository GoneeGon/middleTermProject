package guest;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileNameExtensionFilter;

import account.LoginForm;
import account.accountDTO.AccountDTO;
import admin.BuyHistory;
import chat.client.ChatClient;
import customer.DeliveryTrace;
import customer.MainPage_Customer;
import customer.MyList;
import customer.MyPage;
import customer.WishDTO;
import item.categoryDAO.CategoryDAO;
import item.categoryDTO.CategoryDTO;
import item.itemDAO.ItemDAO;
import item.itemDTO.ItemDTO;
import notice.NoticeClient;

import javax.swing.JComboBox;
import javax.swing.AbstractButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MainPage_Guest extends JFrame implements ActionListener,ListSelectionListener{
	
	private JPanel backgroundPanel,productListPanel,productPanel,productListTitlePanel;
	private JLabel productListTitleLabel;
	private JButton deliveryTraceButton,myListButton,leftButton,rightButton;
	
	private JList<CategoryDTO> list;					//JList
	private DefaultListModel<CategoryDTO> model;		//JList ���� ��� �༮
	
	JLabel lblNewLabel,lblNewLabel_1;
	
	private JPanel[] eachProductPanel = new JPanel[8];
	private JLabel[] eachProductImageLabel = new JLabel[8];
	private JLabel[] product_qtyLabel = new JLabel[8];
	private JLabel[] product_nameLabel = new JLabel[8];
	private JTextField[] product_nameT = new JTextField[8];
	private JLabel[] product_priceLabel = new JLabel[8];
	private JTextField[] product_priceT = new JTextField[8];
	private JSpinner[] product_qty_Spinner = new JSpinner[8];
	private SpinnerNumberModel numModel;
	private JTextField[] buyTextField = new JTextField[8];
	private JButton[] wishListB = new JButton[8];
	
	private String passId,passPw;
	public String filename=null;
	//�̹��� path
	public String path = System.getProperty("user.dir");
	
	private int code=0;
	private int page=0;
	private ArrayList<ItemDTO> itemList;
	private ArrayList<WishDTO> wishList = new ArrayList<WishDTO>();
	
	
	int x = 45;
	int y = 10;
	int sizeX = 213;
	int sizeY = 267;
	int cnt=0;
	int check_qty=0;
	
	public MainPage_Guest() {		
		getContentPane().setLayout(null);
	
		//��ǰ ȭ�� �г�
		productPanel = new JPanel();
		productPanel.setBackground(new Color(153, 204, 153));
		productPanel.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		productPanel.setBounds(214, 98, 1046, 585);
		getContentPane().add(productPanel);
		productPanel.setLayout(null);
		
		//��ǰ���� �г�
		String productInfoImgPath = System.getProperty("user.dir");
		ImageIcon productInfoImgIcon = new ImageIcon(productInfoImgPath+"\\image\\vegitable2.jpg");
		
		//��׶��� �г�(�ǵ�)+����̹���
		String backgroundImgPath = System.getProperty("user.dir");
		ImageIcon backgroundIcon = new ImageIcon(backgroundImgPath+"\\image\\vegitable.jpg");
		backgroundPanel = new JPanel(){
			public void paintComponent(Graphics g) {
				g.drawImage(backgroundIcon.getImage(),0,0,null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		backgroundPanel.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		backgroundPanel.setBounds(12, 10, 1248, 673);
		backgroundPanel.setLayout(null);
		getContentPane().add(backgroundPanel);

		// �� ��ǰ �̹��� �� ���� â
		//-----------------------------------------------------------------------------------------
		for(int i=0; i<eachProductPanel.length; i++) {
			eachProductPanel[i] = new JPanel();
			eachProductPanel[i].setLayout(null);
			eachProductPanel[i].setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
			eachProductPanel[i].setBackground(new Color(153, 204, 153));
			eachProductPanel[i].setBounds(x, y, sizeX, sizeY);
			productPanel.add(eachProductPanel[i]);
			
			eachProductImageLabel[i]  = new JLabel();
			eachProductImageLabel[i].setBackground(new Color(25,0,0));
			eachProductImageLabel[i].setBounds(49, 8, 120, 160);
			eachProductPanel[i].add(eachProductImageLabel[i]);
			
			product_qtyLabel[i] = new JLabel("���� :");
			product_qtyLabel[i].setBackground(new Color(255,0,255));
			product_qtyLabel[i].setBounds(50,175, 50, 50);
			eachProductPanel[i].add(product_qtyLabel[i]);
			
			numModel = new SpinnerNumberModel(0, 0, 99, 1);//�ʱⰪ, �ּҰ�, �ִ밪, �ܰ�			
			product_qty_Spinner[i] = new JSpinner();
			product_qty_Spinner[i].setModel(numModel);
			product_qty_Spinner[i].setBounds(95, 190, 70, 20);
			product_qty_Spinner[i].setBackground(new Color(255,0,255));
			eachProductPanel[i].add(product_qty_Spinner[i]);
			
			product_nameLabel[i] = new JLabel("ǰ�� :");
			product_nameLabel[i].setBackground(new Color(153, 204, 153));
			product_nameLabel[i].setBounds(50,155, 50, 50);
			eachProductPanel[i].add(product_nameLabel[i]);
			
			product_nameT[i] = new JTextField();
			product_nameT[i].setBounds(95,170,70,20);
			product_nameT[i].setBackground(new Color(153, 204, 153));
			product_nameT[i].setForeground(new Color(0,0,0));
			product_nameT[i].setHorizontalAlignment(SwingConstants.CENTER);
			product_nameT[i].setEditable(false);
			product_nameT[i].setEnabled(true);
			eachProductPanel[i].add(product_nameT[i]);
			
			product_priceLabel[i] = new JLabel("���� :");
			product_priceLabel[i].setBackground(new Color(255,0,255));
			product_priceLabel[i].setBounds(50,195, 50, 50);
			eachProductPanel[i].add(product_priceLabel[i]);
			
			product_priceT[i] = new JTextField();
			product_priceT[i].setBounds(95,210,70,20);
			product_priceT[i].setBackground(new Color(153, 204, 153));
			product_priceT[i].setForeground(new Color(0,0,0));
			product_priceT[i].setHorizontalAlignment(SwingConstants.CENTER);
			product_priceT[i].setEditable(false);
			product_priceT[i].setEnabled(true);
			eachProductPanel[i].add(product_priceT[i]);
			
			buyTextField[i] = new JTextField("ǰ��");
			buyTextField[i].setBackground(new Color(153, 204, 153));
			buyTextField[i].setBounds(10, 230, 90, 30);
			buyTextField[i].setForeground(new Color(255,255,255));
			eachProductPanel[i].add(buyTextField[i]);
			
			wishListB[i] = new JButton("��ٱ���");
			wishListB[i].setBackground(new Color(100,100,100));
			wishListB[i].setBounds(110, 230, 90, 30);
			wishListB[i].setForeground(new Color(255,255,255));
			eachProductPanel[i].add(wishListB[i]);	
			wishListB[i].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					//System.out.println("��ٱ��Ͽ� �߰��մϴ�!!");
										
					for(int i=0; i<wishListB.length; i++) {
						if(arg0.getSource()==wishListB[i]) {
							//���� ��������
							int num = (int)product_qty_Spinner[i].getValue();
							
							//������ 0�����̸� ����x
							if(num<=0) return;
							
							//�ش� ��ǰ ���� ��������
							ItemDAO dao = ItemDAO.getInstance();
							ItemDTO itemdto = dao.getItem(product_nameT[i].getText());
														
							//wishDTO ��ü�� ������ ����  �ֱ�
							WishDTO dto = new WishDTO();
							dto.setDto(itemdto);
							dto.setNum(num);
							
							//ArrayList<WishDTO> wishList�� �߰�
							wishList.add(dto);
							
							//���� �ʱ�ȭ
							product_qty_Spinner[i].setValue(0);
							JOptionPane.showMessageDialog(MainPage_Guest.this, "��ٱ��Ͽ� �߰��մϴ�", "��ٱ��� �߰�", JOptionPane.INFORMATION_MESSAGE);
						}
					}
				}
			});
			
			x += 250;
			cnt++;
			
			//��ó�� �α��� ��, ������ǰ�г� �Ⱥ����ֱ�
			eachProductPanel[i].setVisible(false);
			
		
			if(cnt%4==0) {
				y+=280;
				x=45;
			}
		}
		
		//��ٱ��� ��ư
		myListButton = new JButton("");
		myListButton.setIcon(new ImageIcon(path+"\\image\\MyList_icon.jpg"));
		myListButton.setToolTipText("\uC7A5\uBC14\uAD6C\uB2C8");
		myListButton.setBounds(1078, 10, 73, 71);
		backgroundPanel.add(myListButton);
		
		//�����ȸ ��ư
		deliveryTraceButton = new JButton("");
		deliveryTraceButton.setIcon(new ImageIcon(path+"\\image\\DeliveryMgmt_icon.jpg"));
		deliveryTraceButton.setToolTipText("\uBC30\uC1A1\uC870\uD68C");
		deliveryTraceButton.setBounds(1163, 10, 73, 71);
		backgroundPanel.add(deliveryTraceButton);
		
		//��ǰ��� �г�(JList �ø� �г�)
		productListPanel = new JPanel();
		productListPanel.setBounds(12, 139, 180, 407);
		backgroundPanel.add(productListPanel);
		productListPanel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		productListPanel.setBackground(Color.WHITE);
		productListPanel.setLayout(new BorderLayout(0, 0));
		
		//JList ��ǰ����Ʈ
		list = new JList<CategoryDTO>(new DefaultListModel<CategoryDTO>());
		list.setBackground(new Color(153, 204, 153));
		model = (DefaultListModel<CategoryDTO>) list.getModel();
		JScrollPane scroll = new JScrollPane(list);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		list.setBounds(22, 98, 180, 585);
		productListPanel.add(scroll);
		
		//��ǰ����Ʈ ���� �г�
		productListTitlePanel = new JPanel();
		productListTitlePanel.setBackground(new Color(153, 204, 153));
		productListTitlePanel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		productListTitlePanel.setBounds(12, 89, 180, 40);
		backgroundPanel.add(productListTitlePanel);
		productListTitlePanel.setLayout(null);
		
		//��ǰ����Ʈ ���� ��(Ŭ�� ��, �ʱ�ȭ�� ������)
		productListTitleLabel = new JLabel("\uC0C1\uD488\uB9AC\uC2A4\uD2B8");
		productListTitleLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				System.out.println("�ʱ�ȭ���� �����ݴϴ�");
				//��ǰ����Ʈ Ŭ�� ��, �ʱ�ȭ�� �̹��� �����ֱ�
				String InfoImgPath = System.getProperty("user.dir");
				ImageIcon infoImg = new ImageIcon(InfoImgPath+"\\image\\infomation.jpg");
				ImageIcon infoImg2 = new ImageIcon(InfoImgPath+"\\image\\information2.jpg");
				lblNewLabel.setIcon(infoImg);
				lblNewLabel_1.setIcon(infoImg2);
				rightButton.setEnabled(false);
				leftButton.setEnabled(false);
				
				//��ǰ����Ʈ Ŭ�� ��, ������ǰ �г� �������
				for(int i=0; i<eachProductPanel.length;i++) {
					eachProductPanel[i].setVisible(false);
				}
				
			}
		});
		productListTitleLabel.setForeground(Color.WHITE);
		productListTitleLabel.setBackground(new Color(153, 204, 153));
		productListTitleLabel.setBounds(0, 5, 180, 35);
		productListTitlePanel.add(productListTitleLabel);
		productListTitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		productListTitleLabel.setFont(new Font("�޸հ���", Font.BOLD, 20));
			
		//���� ��ư
		leftButton = new JButton("<---");
		leftButton.setBounds(12, 588, 84, 46);
		leftButton.setIcon(new ImageIcon(path+"\\image\\Ldirection_icon.jpg"));
		leftButton.setEnabled(false);
		backgroundPanel.add(leftButton);
		leftButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				page--; //����������
				settingPage();
			}	
		});
		
		//������ ��ư
		rightButton = new JButton("--->");
		rightButton.setBounds(108, 588, 84, 46);
		rightButton.setIcon(new ImageIcon(path+"\\image\\Rdirection_icon.jpg"));
		rightButton.setEnabled(false);
		backgroundPanel.add(rightButton);
		rightButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				page++; //����������
				settingPage();
			}
		});
				
		//DB�� �ִ� ��ǰ  ��������
		getCategoryList();
		
		//�α��� ��, ���ȭ�� �����ֱ�
		String InfoImgPath = System.getProperty("user.dir");
		ImageIcon infoImg = new ImageIcon(InfoImgPath+"\\image\\infomation.jpg");
		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(53, 44, 925, 131);
		lblNewLabel.setIcon(infoImg);
		productPanel.add(lblNewLabel);
		
		//�α��� ��, ���ȭ�� �����ֱ�
		ImageIcon infoImg2 = new ImageIcon(InfoImgPath+"\\image\\information2.jpg");
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(53, 201, 925, 313);
		lblNewLabel_1.setIcon(infoImg2);	
		productPanel.add(lblNewLabel_1);
					
		setTitle("����ȭ��");	
		setVisible(true);
		setBounds(100,100,1280,720);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		myListButton.addActionListener(this);
		deliveryTraceButton.addActionListener(this);
		list.addListSelectionListener(this);
		
		new NoticeClient();
	}//������	
	
	//DB�� �ִ� ��ǰ �������� �޼ҵ�
	public void getCategoryList() {
		CategoryDAO dao = CategoryDAO.getInstance();
		//itemDTO�� ��� ���� ���-> ArrayList �̿��Ͽ� itemDTO ��ü ��Ƽ� ���� ����(���Ͻ�, itemDTO�� �Ѱ��� ������)
		ArrayList<CategoryDTO> list_2 = dao.getCategoryList();
		model.removeAllElements();
		for(CategoryDTO dto:list_2) {
			model.addElement(dto);
		}//for
	}//getitemList()

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==myListButton) {
			new MyList_Guest(wishList);
		}else if(e.getSource()==deliveryTraceButton) {
			new GuestLoginDeliveryTrace();
		}
	}
	
	//��ǰ����Ʈ(JList)�� ��ǰ�׸� ���� ��, �̹��� �ѷ��ֱ�
	@Override
	public void valueChanged(ListSelectionEvent e) {
		lblNewLabel.setIcon(null);
		lblNewLabel_1.setIcon(null);
		
		//������ �ʱ�ȭ
		page=0;	
		
		//��ǰ�з��� �´� ��ǰ��� �ҷ�����
		CategoryDTO dto = (CategoryDTO)list.getSelectedValue();
		itemList = ItemDAO.getInstance().getItemList(dto.getCode());
		
		settingPage();
	}
	
	//�ֵ�ƿ�
	public void settingSoldout(int i, int seq) {
		int qty = ItemDAO.getInstance().checkStock(seq);
		if(qty==0) {
			buyTextField[i].setText("ǰ��");	//0 �ֱ�
			buyTextField[i].setForeground(Color.RED);
			buyTextField[i].setHorizontalAlignment(SwingConstants.CENTER);
			wishListB[i].setEnabled(false);
		}
		else {
			buyTextField[i].setText("�Ǹ���");
			buyTextField[i].setForeground(Color.WHITE);
			buyTextField[i].setHorizontalAlignment(SwingConstants.CENTER);
			wishListB[i].setEnabled(true);
		} 
	}
	
	//������ ����
	public void settingPage() {		
		//�������̵���ư Ȱ�� ��/�� ����
		if(itemList.size() > (page+1)*8) rightButton.setEnabled(true);
		else rightButton.setEnabled(false);
		if(page > 0) leftButton.setEnabled(true);
		else leftButton.setEnabled(false);
		
		//�г� ����
		for(int i=page*8; i<page*8+8; i++) {
			if(i<itemList.size()) eachProductPanel[i%8].setVisible(true);
			else eachProductPanel[i%8].setVisible(false);
		}
		
		//���ǳ� �ʱ�ȭ
		for(int i=0; i<eachProductPanel.length; i++) {
			numModel = new SpinnerNumberModel(0, 0, 99, 1);//�ʱⰪ, �ּҰ�, �ִ밪, �ܰ�	
			product_qty_Spinner[i].setModel(numModel);
		}	
		
		ImageIcon icon = null;
		
		if(list.getSelectedIndex()==-1) return;
		
		//���� ������ �׸� ��������
		for(int i=page*8; i<page*8+8 && i<itemList.size(); i++) {
			ItemDTO data = itemList.get(i);					
			String image1 = data.getImage();
			
			//��������ǥ��
			settingSoldout(i%8,data.getSeq());
			
			//�̹��� ������ ����
			icon = new ImageIcon(path+"\\image\\"+image1);
			Image originalimage = icon.getImage();
			Image resizedImage = originalimage.getScaledInstance(120, 160, Image.SCALE_SMOOTH);
			
			eachProductImageLabel[i%8].setIcon(new ImageIcon(resizedImage));
			product_nameT[i%8].setText(data.getName());
			product_priceT[i%8].setText(data.getPrice()+"");
		}
	}
}	




