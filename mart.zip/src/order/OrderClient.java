package order;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

import javax.swing.*;

import account.LoginForm;
import account.accountDTO.AccountDTO;

public class OrderClient {
	private Socket socket;
	private String ip = LoginForm.getServerIp();;
	private int port = 9700;
	
	private DataInputStream in;
	private DataOutputStream out;
	private String msg;
	
	private String id;
	
	public OrderClient(AccountDTO dto) {
		try {
			socket = new Socket(ip, port);
			out = new DataOutputStream(socket.getOutputStream());
			out.writeUTF(dto.getId());
			out.flush();
			out.close();
			socket.close();
		} catch (UnknownHostException e) {
			
		} catch (IOException e) {
			
		}
	}
}
