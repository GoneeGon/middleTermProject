package order;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JOptionPane;

import admin.MainPage_Admin;
import customer.MyPage;

public class OrderServer extends Thread {
	private ServerSocket ss;
	private Socket socket;
	private int port = 9700;
	private MainPage_Admin admin;
	
	public OrderServer(MainPage_Admin admin) {
		this.admin = admin;
	}
		
	@Override
	public void run() {
		try {
			ss = new ServerSocket(port);
			
			while(true) {
				socket = ss.accept(); //Ŭ���̾�Ʈ�� ���� ���

				DataInputStream dis = new DataInputStream(socket.getInputStream());
				String id = dis.readUTF();
				JOptionPane.showMessageDialog(admin, id+"���� �ֹ��Ͽ����ϴ�");
				admin.setTodayPanel();
				dis.close();
				socket.close();
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
