package chat.server;

import java.io.IOException;
import java.net.*;

public class ChatServer extends Thread {
	private ServerSocket ss;
	private Socket socket;
	private int port = 9500;
	
	public ChatServer() {
	}
		
	@Override
	public void run() {
		try {
			ss = new ServerSocket(port);
			
			while(true) {
				socket = ss.accept(); //Ŭ���̾�Ʈ�� ���� ���
				
				new ChatHandler(socket); //������ ä��â ����
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		new ChatServer().start();
	}
}
