package account;

import java.awt.event.*;
import javax.swing.*;
import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;
import java.awt.Font;

public class DeleteAccount extends JFrame implements ActionListener {
	private JLabel x1L, pw1, pw2;
	private JPasswordField pw1T, pw2T;
	private JButton okB, cancelB;
	
	public DeleteAccount() {
		pw1 = new JLabel("\uBE44\uBC00\uBC88\uD638 : ");
		pw1.setHorizontalAlignment(SwingConstants.RIGHT);
		pw1.setFont(new Font("����", Font.BOLD, 16));
		pw2 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778 : ");
		pw2.setHorizontalAlignment(SwingConstants.RIGHT);
		pw2.setFont(new Font("����", Font.BOLD, 16));
		x1L = new JLabel("��й�ȣ�� �Է����ּ���");
		
		okB = new JButton("Ȯ��");
		cancelB = new JButton("���");
		
		pw1T = new JPasswordField();
		pw2T = new JPasswordField();
		
		x1L.setBounds(140, 10, 150, 40);
		pw1.setBounds(40, 58, 130, 30);
		pw1T.setBounds(170, 60, 180, 30);
		pw2.setBounds(40, 97, 130, 30);
		pw2T.setBounds(170, 98, 180, 30);
		
		okB.setBounds(109, 166, 100, 20);
		cancelB.setBounds(231, 166, 100, 20);
		
		getContentPane().add(okB);
		getContentPane().add(cancelB);
		getContentPane().add(x1L);
		getContentPane().add(pw1T);
		getContentPane().add(pw2T);
		getContentPane().add(pw1);
		getContentPane().add(pw2);
		
		getContentPane().setLayout(null);
		setBounds(700, 100, 450 , 250);
		setVisible(true);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		okB.addActionListener(this);
		pw2T.addActionListener(this);
		cancelB.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==okB || e.getSource()==pw2T) {
			if(pw1T.getText().equals(pw2T.getText())) {
				if(pw1T.getText().equals(LoginForm.getLogin().getPassword())) {
					JOptionPane.showMessageDialog(this, "ȸ��Ż�� ���������� ó���Ǿ����ϴ�", "ȸ��Ż��", JOptionPane.INFORMATION_MESSAGE);
					AccountDAO.getInstance().deleteArticle(LoginForm.getLogin());
					System.exit(0);
				}else {
					JOptionPane.showMessageDialog(this, "��й�ȣ�� ��ġ���� �ʽ��ϴ�", "����", JOptionPane.WARNING_MESSAGE);
				}
			}else
				JOptionPane.showMessageDialog(this, "��й�ȣ�� ���� �ٸ��ϴ�", "����", JOptionPane.WARNING_MESSAGE);
		}else if(e.getSource()==cancelB) {
			this.dispose();
		}
	}
}
	

