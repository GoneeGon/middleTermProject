package account;

import java.awt.*;
import java.awt.event.*;
import java.util.regex.Pattern;

import javax.swing.*;

import account.accountDAO.AccountDAO;
import account.accountDTO.AccountDTO;

public class JoinForm extends JFrame implements ActionListener {
	private JPanel contentPane;
	private JTextField idT;
	private JTextField nameT;
	private JRadioButton maleB;
	private JRadioButton femaleB;
	private JTextField emailT1;
	private JTextField emailT2;
	private JTextField postT;
	private JTextField addressT1;
	private JTextField addressT2;
	private JComboBox<String> tel1, combo;
	private JTextField tel2;
	private JTextField tel3;
	private JPasswordField passwordT;
	private JPasswordField checkPwT;
	private JButton joinB;
	private JButton cancelB;
	private JButton idCheckB;
	private JButton addressFindB;
	private JLabel idCheckL;
	private String idCheckS;
	private StringBuffer authNum; //������ȣ
	
	private AccountDAO dao = AccountDAO.getInstance();
		
	//Create the frame.
	public JoinForm() {
		setBounds(100, 100, 425, 400);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel titleL = new JLabel("\uD68C \uC6D0 \uAC00 \uC785");
		titleL.setFont(new Font("����", Font.BOLD, 18));
		titleL.setBounds(5, 5, 399, 25);
		titleL.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(titleL);
		
		JLabel idL = new JLabel("\uC544   \uC774   \uB514 :");
		idL.setBounds(30, 55, 77, 15);
		contentPane.add(idL);
		
		idT = new JTextField();
		idT.setBounds(119, 52, 100, 21);
		contentPane.add(idT);
		idT.setColumns(10);
		
		JLabel passwordL = new JLabel("\uBE44 \uBC00 \uBC88 \uD638 :");
		passwordL.setBounds(30, 80, 77, 15);
		contentPane.add(passwordL);
		
		passwordT = new JPasswordField();
		passwordT.setBounds(119, 77, 100, 21);
		contentPane.add(passwordT);
		
		JLabel checkPwL = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778 :");
		checkPwL.setBounds(30, 105, 100, 15);
		contentPane.add(checkPwL);
		
		checkPwT = new JPasswordField();
		checkPwT.setBounds(119, 102, 100, 21);
		contentPane.add(checkPwT);
		
		JLabel nameL = new JLabel("\uC774        \uB984 :");
		nameL.setBounds(30, 130, 77, 15);
		contentPane.add(nameL);
		
		nameT = new JTextField();
		nameT.setBounds(119, 127, 100, 21);
		contentPane.add(nameT);
		nameT.setColumns(10);
		
		JLabel genderL = new JLabel("\uC131        \uBCC4 :");
		genderL.setBounds(30, 155, 80, 15);
		contentPane.add(genderL);
		
		maleB = new JRadioButton("\uB0A8\uC790",true);
		maleB.setBounds(119, 151, 71, 23);
		contentPane.add(maleB);
		
		femaleB = new JRadioButton("\uC5EC\uC790");
		femaleB.setBounds(192, 151, 121, 23);
		contentPane.add(femaleB);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(maleB); bg.add(femaleB);
		
		JLabel emailL = new JLabel("\uC774   \uBA54   \uC77C :");
		emailL.setBounds(30, 178, 77, 15);
		contentPane.add(emailL);
		
		emailT1 = new JTextField();
		emailT1.setColumns(10);
		emailT1.setBounds(119, 175, 71, 21);
		contentPane.add(emailT1);
		
		combo = new JComboBox<String>(new String[] {"���� �Է�", "naver.com", "daum.net", "gmail.com", "paran.com", "yahoo.co.kr"});
		combo.setBounds(286, 175, 98, 21);
		contentPane.add(combo);
		
		JLabel lblNewLabel = new JLabel("@");
		lblNewLabel.setBounds(195, 175, 26, 15);
		contentPane.add(lblNewLabel);
		
		emailT2 = new JTextField();
		emailT2.setColumns(10);
		emailT2.setBounds(212, 175, 71, 21);
	
		contentPane.add(emailT2);
		
		combo.addItemListener(new ItemListener() {		
			@Override
			public void itemStateChanged(ItemEvent e) {
				String comboE = (String)combo.getSelectedItem();
				if(comboE.equals(combo.getItemAt(0))) emailT2.setText("");
				else emailT2.setText(comboE);
			}
		});
		
		JLabel postL = new JLabel("\uC6B0 \uD3B8 \uBC88 \uD638 :");
		postL.setBounds(30, 203, 77, 15);
		contentPane.add(postL);
		
		postT = new JTextField();
		postT.setBounds(119, 200, 164, 21);
		contentPane.add(postT);
		postT.setColumns(10);
		
		JLabel addressL = new JLabel("\uC8FC        \uC18C :");
		addressL.setBounds(30, 234, 77, 15);
		contentPane.add(addressL);
		
		addressT1 = new JTextField();
		addressT1.setColumns(10);
		addressT1.setBounds(119, 231, 264, 21);
		contentPane.add(addressT1);
		
		addressT2 = new JTextField();
		addressT2.setColumns(10);
		addressT2.setBounds(119, 262, 264, 21);
		contentPane.add(addressT2);
		
		JLabel telL = new JLabel("\uC804 \uD654 \uBC88 \uD638 :");
		telL.setBounds(30, 296, 77, 15);
		contentPane.add(telL);
		
		tel1 = new JComboBox<String>(new String[] {"010", "011", "016", "017", "019"});
		tel1.setBounds(119, 293, 53, 21);
		contentPane.add(tel1);
		
		JLabel label = new JLabel("-");
		label.setBounds(174, 296, 16, 15);
		contentPane.add(label);
		
		tel2 = new JTextField();
		tel2.setBounds(184, 293, 44, 21);
		contentPane.add(tel2);
		tel2.setColumns(10);
		
		JLabel label_1 = new JLabel("-");
		label_1.setBounds(229, 296, 16, 15);
		contentPane.add(label_1);
		
		tel3 = new JTextField();
		tel3.setColumns(10);
		tel3.setBounds(239, 293, 44, 21);
		contentPane.add(tel3);
		
		joinB = new JButton("\uD68C\uC6D0\uAC00\uC785");
		joinB.setBounds(93, 330, 97, 23);
		contentPane.add(joinB);
		
		cancelB = new JButton("\uCDE8\uC18C");
		cancelB.setBounds(204, 330, 97, 23);
		contentPane.add(cancelB);
		
		idCheckB = new JButton("\uC911\uBCF5 \uD655\uC778");
		idCheckB.setBounds(230, 51, 97, 23);
		contentPane.add(idCheckB);
		
		addressFindB = new JButton("\uC8FC\uC18C \uCC3E\uAE30");
		addressFindB.setBounds(286, 199, 98, 23);
		contentPane.add(addressFindB);
		
		idCheckL = new JLabel();
		idCheckL.setBounds(339, 55, 61, 15);
		contentPane.add(idCheckL);
		
		setTitle("ȸ�� ����");
		addListener();
		setResizable(false);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				new LoginForm();
			}
		});
	}
	
	//Add Event Listener
	public void addListener() {
		joinB.addActionListener(this);
		cancelB.addActionListener(this);
		idCheckB.addActionListener(this);
		addressFindB.addActionListener(this);
	}
	
	
	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==joinB) {
			if(checkInputForm()) {
				String id = idT.getText();
				String password = passwordT.getText();
				String name = nameT.getText();
				int gender = maleB.isSelected() ? 0 : 1;
				String email = emailT1.getText()+"@"+emailT2.getText();
				String post = postT.getText();
				String address1 = addressT1.getText();
				String address2 = addressT2.getText();
				String tel1 = (String)this.tel1.getSelectedItem();
				String tel2 = this.tel2.getText();
				String tel3 = this.tel3.getText();
				
				AccountDTO dto = new AccountDTO();
				dto.setId(id);
				dto.setPassword(password);
				dto.setName(name);
				dto.setGender(gender);
				dto.setEmail(email);
				dto.setPost(post);
				dto.setAddress1(address1);
				dto.setAddress2(address2);
				dto.setTel1(tel1);
				dto.setTel2(tel2);
				dto.setTel3(tel3);
				
				//������ȣ ����
				authNum = new StringBuffer();
				for(int i=0; i<6; i++) {
					authNum.append((int)(Math.random()*10));
				}
				new MailSend(email, authNum.toString());
				
				String auth = JOptionPane.showInputDialog(this, "������ȣ�� �Է��ϼ���", "�̸��� ����", JOptionPane.INFORMATION_MESSAGE);
				if(auth.equals(authNum.toString())) {
					dao.insertArticle(dto);
					JOptionPane.showMessageDialog(this, "ȸ������ �Ǿ����ϴ�", "ȸ������", JOptionPane.INFORMATION_MESSAGE);
					new LoginForm();
					this.dispose();
					return;
				}
				
				if(auth!=null) {
					for(int i=2; i>0; i--) {
						auth = JOptionPane.showInputDialog(this, "������ȣ�� Ʋ�Ƚ��ϴ� [������ȸ : "+i+" ]", "�̸��� ����", JOptionPane.WARNING_MESSAGE);
						if(auth.equals(authNum.toString())) {
							if(dao.insertArticle(dto)<0)
								JOptionPane.showMessageDialog(this, "ȸ�����Կ� �����߽��ϴ�", "ȸ������", JOptionPane.WARNING_MESSAGE);
							JOptionPane.showMessageDialog(this, "ȸ������ �Ǿ����ϴ�", "ȸ������", JOptionPane.INFORMATION_MESSAGE);
							new LoginForm();
							this.dispose();
							return;
						}
					}
					JOptionPane.showMessageDialog(this, "ȸ�����Կ� �����߽��ϴ�", "ȸ������", JOptionPane.WARNING_MESSAGE);
				}
			}
		}else if(e.getSource()==cancelB) {
			new LoginForm();
			this.dispose();//�ҽ� ���ս� dispose�� ����
		}else if(e.getSource()==idCheckB) {
			if(idT.getText().equals("") || idT.getText().length() < 6) {
				JOptionPane.showMessageDialog(this, "���̵� �Է��ϼ���(6�� �̻�)", "���̵� �ߺ� Ȯ��", JOptionPane.WARNING_MESSAGE);
			}else if(!dao.checkId(idT.getText())) {
				idCheckL.setForeground(Color.GREEN);
				idCheckS = "��� ����";
				idCheckL.setText(idCheckS);
			}else {
				idCheckL.setForeground(Color.RED);
				idCheckS ="�����";
				idCheckL.setText(idCheckS);
			}
		}else if(e.getSource()==addressFindB) {
			new PostSearch(postT, addressT1);
		}
	}
	
	//�Է¾�� �ۼ� ���� Ȯ�� (��� �̻������ true / �̻������� false)
	public boolean checkInputForm() {
		boolean check=true;
		Pattern p = Pattern.compile("(^[a-zA-z0-9]*$)");
		
		if(idT.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "���̵� �Է��ϼ���", "���̵� Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(!p.matcher(idT.getText()).find()) {
			JOptionPane.showMessageDialog(this, "���̵�� ����,���ڸ� �Է��ϼ���", "���̵� Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(passwordT.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "��й�ȣ�� �Է��ϼ���", "��й�ȣ Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(checkPwT.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "��й�ȣ�� Ȯ���ϼ���", "��й�ȣ Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(!passwordT.getText().equals(checkPwT.getText())) {
			JOptionPane.showMessageDialog(this, "��й�ȣ�� ���� �ٸ��ϴ�", "��й�ȣ Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(nameT.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "�̸��� �Է��ϼ���", "�̸� Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(emailT1.getText().equals("") || emailT2.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "�̸����� �Է��ϼ���", "�̸��� Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(postT.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "������ȣ�� �Է��ϼ���", "������ȣ Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(addressT1.getText().equals("") || addressT2.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "�ּҸ� �Է��ϼ���", "�ּ� Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}else if(tel2.getText().equals("") || tel3.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "��ȭ��ȣ�� �Է��ϼ���", "��ȭ��ȣ Ȯ��", JOptionPane.WARNING_MESSAGE);
			check=false;
		}
		
		return check;
	}	
}
