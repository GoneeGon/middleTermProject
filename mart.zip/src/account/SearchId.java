package account;

import javax.swing.*;

import account.accountDAO.AccountDAO;

import java.awt.*;
import java.awt.event.*;

public class SearchId extends JFrame implements ActionListener {
	private JLabel nameL, emailL;
	private JTextField nameF;
	private JTextField emailF;
	private JButton findIdB, backB;
	private AccountDAO dao= AccountDAO.getInstance();
	private JTextField idT;
	
	public SearchId(JTextField idT) {
		this.idT = idT;
		nameL=new JLabel("\uC774\uB984  : ");
		nameL.setFont(new Font("����", Font.BOLD, 16));
		emailL=new JLabel("\uBA54\uC77C\uC8FC\uC18C : ");
		emailL.setFont(new Font("����", Font.BOLD, 16));
		nameF=new JTextField(8);
		emailF=new JTextField(8);
		findIdB=new JButton("���̵� ã��");
		backB=new JButton("���");
		
		nameL.setBounds(0, 6, 90, 36);
		nameL.setHorizontalAlignment(SwingConstants.RIGHT);
		emailL.setBounds(0, 6, 90, 36);
		emailL.setHorizontalAlignment(SwingConstants.RIGHT);
		nameF.setBounds(90, 6, 189, 35);
		emailF.setBounds(90, 6, 189, 35);
		
		JPanel p1 = new JPanel();p1.add(nameF);
		p1.setLayout(null);
		p1.add(nameL); p1.add(nameF);
		
		JPanel p2 = new JPanel();
		p2.setLayout(null);
		p2.add(emailL); p2.add(emailF);
		
		JPanel p3 = new JPanel(); 
		p3.add(findIdB); p3.add(backB);
		
		p1.setBounds(62, 40, 279, 44);
		p2.setBounds(62, 85, 279, 44);
		p3.setBounds(62, 139, 279, 44);

		
		Container c = this.getContentPane();
		c.setLayout(null);
		c.add(p1); c.add(p2); c.add(p3);
		
		setTitle("���̵� ã��");
		setBounds(100, 100, 450, 250);
		setBackground(new Color(255, 200, 230));
		setVisible(true);
		
		event();
	}
	
	public void event() {
		findIdB.addActionListener(this);
		backB.addActionListener(this);
		emailF.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==findIdB || e.getSource()==emailF) {
			if(nameF.getText().equals("")){
				JOptionPane.showMessageDialog(this, "�̸��� �Է����ּ���", "���̵�ã�� ����", JOptionPane.WARNING_MESSAGE);
			}else if(emailF.getText().equals("")){
				JOptionPane.showMessageDialog(this, "�̸����� �Է����ּ���", "���̵�ã�� ����", JOptionPane.WARNING_MESSAGE);
			}else if(!dao.checkName(nameF.getText())) {
				JOptionPane.showMessageDialog(this, "�������� �ʴ� �̸��Դϴ�", "���̵�ã�� ����", JOptionPane.WARNING_MESSAGE);
			}else if(!dao.checkEmail(emailF.getText())) {
				JOptionPane.showMessageDialog(this, "�������� �ʴ� �̸����Դϴ�", "���̵�ã�� ����", JOptionPane.WARNING_MESSAGE);
			}else {
				String id = dao.checkName_Email(nameF.getText(), emailF.getText());
				if(id!=null){
					idT.setText(id);
					JOptionPane.showMessageDialog(this, "���̵�� "+id+"�Դϴ�", "���̵�ã�Ⱑ��", JOptionPane.INFORMATION_MESSAGE);
					this.dispose();
				}else{
					JOptionPane.showMessageDialog(this, "Ʋ�� �����Դϴ�", "���̵�ã�����", JOptionPane.WARNING_MESSAGE);
				}
			}
			
		}else if(e.getSource()==backB) {
			this.dispose();
		}
	}	
}




















