package account.accountDAO;

import java.sql.*;
import java.util.ArrayList;

import account.LoginForm;
import account.accountDTO.AccountDTO;
import oracle.jdbc.proxy.annotation.Pre;

public class AccountDAO {
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = LoginForm.getUrl();
	private String user = "java";
	private String password = "itbank";
	
	private static AccountDAO instance;
	
	public AccountDAO() {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static AccountDAO getInstance() {
		if(instance==null) {
			synchronized(AccountDAO.class) {
				instance = new AccountDAO();
			}
		}
		return instance;
	}
	
	public Connection getConnection() {
		Connection conn = null;
		
		try {
			conn = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	//ȸ�� ����
	public int insertArticle(AccountDTO dto) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		String sql = "insert into account values(account_seq.nextval,?,?,?,?,?,?,?,?,?,?,?,0,1,sysdate)";
		int su=0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getPassword());
			ps.setString(3, dto.getName());
			ps.setInt(4, dto.getGender());
			ps.setString(5, dto.getEmail());
			ps.setString(6, dto.getPost());
			ps.setString(7, dto.getAddress1());
			ps.setString(8, dto.getAddress2());
			ps.setString(9, dto.getTel1());
			ps.setString(10, dto.getTel2());
			ps.setString(11, dto.getTel3());
			su = ps.executeUpdate();			
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
	
	//ȸ������ ����
	public int updateArticle(AccountDTO dto) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		String sql = "update account set password=?, name=?, gender=?, email=?, post=?, address1=?, address2=?, tel1=?, tel2=?, tel3=? where id=?";
		int su=0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, dto.getPassword());
			ps.setString(2, dto.getName());
			ps.setInt(3, dto.getGender());
			ps.setString(4, dto.getEmail());
			ps.setString(5, dto.getPost());
			ps.setString(6, dto.getAddress1());
			ps.setString(7, dto.getAddress2());
			ps.setString(8, dto.getTel1());
			ps.setString(9, dto.getTel2());
			ps.setString(10, dto.getTel3());
			ps.setString(11, dto.getId());
			su = ps.executeUpdate();		
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
	
	//�α��� �� �� DB ���̵� ��й�ȣ��, �ۼ���  ���̵�,��й�ȣ �� �� �ϰ�
	// ������ �α��� ����, Ʋ���� �α��� ����
	public boolean loginCheck(String id, String password) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select id,password from account where id = ?";
		boolean result = false;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1,id);
			rs = ps.executeQuery();
			if(rs.next()) {
				if(rs.getString("id").equals(id) && rs.getString("password").equals(password)) {
					result=true;
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	//���̵� �����ϸ� true ������ false
	public boolean checkId(String id) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select id from account where id=?";
		boolean result=false;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1,id);
			rs = ps.executeQuery();
			if(rs.next()) result=true;
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	// �̸��� �����ϸ� true , ������  false
	public boolean checkName(String name) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select name from account where name=?";
		boolean result=false;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1,name);
			rs = ps.executeQuery();
			if(rs.next()) result=true;
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	//�̸����� �����ϸ� true, ������ false
	public boolean checkEmail(String email) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select email from account where email=?";
		boolean result=false;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1,email);
			rs = ps.executeQuery();
			if(rs.next()) result=true;
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	//�̸��� �̸����� Ȯ���ؼ� ���̵� ��ȯ, ������ null
	public String checkName_Email(String name, String email) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select id,name,email from account where name = ?";
		String id = null;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1,name);
			rs = ps.executeQuery();
			if(rs.next()) {
				if(rs.getString("name").equals(name) && rs.getString("email").equals(email)) {
					id = rs.getString("id");
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return id;
	}
	
	//�̸��� ���̵� Ȯ���ؼ� ��й�ȣ�� ��ȯ, ������ null
	public String checkName_Id(String name, String id) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select password, name, id from account where name = ?";
		String password = null;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1,name);
			rs = ps.executeQuery();
			if(rs.next()) {
				if(rs.getString("name").equals(name) && rs.getString("id").equals(id)) {
					password = rs.getString("password");
				}
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return password;
	}
	
	//�α��� ��, ȸ������ ��������
	public AccountDTO getAccount(String passId, String passPw){
		AccountDTO dto = null;
		
		//DB����
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from account where id = ?";
		if(passPw!=null)
			sql = "select * from account where id = ? and password = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, passId); //id
			if(passPw!=null)
				pstmt.setString(2, passPw); //password
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto = new AccountDTO();
				
				dto.setNo(rs.getInt("no"));
				dto.setId(rs.getString("id"));
				dto.setPassword(rs.getString("password"));
				dto.setName(rs.getString("name"));
				dto.setGender(rs.getInt("gender"));
				dto.setEmail(rs.getString("email"));
				dto.setPost(rs.getString("post"));
				dto.setAddress1(rs.getString("address1"));
				dto.setAddress2(rs.getString("address2"));
				dto.setTel1(rs.getString("tel1"));
				dto.setTel2(rs.getString("tel2"));
				dto.setTel3(rs.getString("tel3"));
				dto.setPoint(rs.getInt("point"));
				dto.setCode(rs.getInt("code"));
				dto.setJoindate(rs.getDate("joindate"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;
	}
	
	//ȸ��Ż�� ����ó���� 1, ���н� 0
	public int deleteArticle(AccountDTO dto) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		String sql = "delete account where no=?";
		int su = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, dto.getNo());
			su = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
	
	//ȸ������ ����Ʈ
	public ArrayList<AccountDTO> getAccountList(){
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from account order by no asc";
		ArrayList<AccountDTO> list = null;
		
		try {
			pstmt = conn.prepareStatement(sql);			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				if(list==null) list = new ArrayList<AccountDTO>();
				
				AccountDTO dto = new AccountDTO();
				
				dto.setNo(rs.getInt("no"));
				dto.setId(rs.getString("id"));
				dto.setPassword(rs.getString("password"));
				dto.setName(rs.getString("name"));
				dto.setGender(rs.getInt("gender"));
				dto.setEmail(rs.getString("email"));
				dto.setPost(rs.getString("post"));
				dto.setAddress1(rs.getString("address1"));
				dto.setAddress2(rs.getString("address2"));
				dto.setTel1(rs.getString("tel1"));
				dto.setTel2(rs.getString("tel2"));
				dto.setTel3(rs.getString("tel3"));
				dto.setPoint(rs.getInt("point"));
				dto.setCode(rs.getInt("code"));
				dto.setJoindate(rs.getDate("joindate"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public AccountDTO getAccount(int no){
		AccountDTO dto = null;
		
		//DB����
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select * from account where no = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no); //id
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto = new AccountDTO();
				
				dto.setNo(rs.getInt("no"));
				dto.setId(rs.getString("id"));
				dto.setPassword(rs.getString("password"));
				dto.setName(rs.getString("name"));
				dto.setGender(rs.getInt("gender"));
				dto.setEmail(rs.getString("email"));
				dto.setPost(rs.getString("post"));
				dto.setAddress1(rs.getString("address1"));
				dto.setAddress2(rs.getString("address2"));
				dto.setTel1(rs.getString("tel1"));
				dto.setTel2(rs.getString("tel2"));
				dto.setTel3(rs.getString("tel3"));
				dto.setPoint(rs.getInt("point"));
				dto.setCode(rs.getInt("code"));
				dto.setJoindate(rs.getDate("joindate"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;
	}
	
	public int getAccount2(AccountDTO dto){
		
		//DB����
		Connection conn = getConnection();
		PreparedStatement ps = null;
		String sql = "insert into account values(account_seq.nextval,?,?,?,?,?,?,?,?,?,?,?, 0, 2, sysdate) ";
		int su=0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, "guest"+(getNowSeq()+1));
			ps.setString(2, "guest");
			ps.setString(3, dto.getName());
			ps.setInt(4, 0);
			ps.setString(5, "guest");
			ps.setString(6, dto.getPost());
			ps.setString(7, dto.getAddress1());
			ps.setString(8, dto.getAddress2());
			ps.setString(9, dto.getTel1());
			ps.setString(10, dto.getTel2());
			ps.setString(11, dto.getTel3());
			
			su = ps.executeUpdate();		
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
	
	public int getNowSeq() {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select last_number from seq where sequence_name = upper('account_seq')";
		int su = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			if(rs.next()) su = rs.getInt(1);
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
	
	//ȸ����ȣ�� ȸ���̸� ��������
	public String getName(int no) {
		String name=null;
		
		Connection conn = getConnection();	
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		String sql = "select name from account where no = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no); 
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				name=rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return name;
	}
	
	//����Ʈ ����
	public int givePoint(AccountDTO dto, int point) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		String sql = "update account set point = point+? where id = ?";
		int su=0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, point);
			ps.setString(2, dto.getId());
			
			su = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
	
	public int subPoint(AccountDTO dto, int point) {
		Connection conn = getConnection();
		PreparedStatement ps = null;
		String sql = "update account set point = point-? where id = ?";
		int su=0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, point);
			ps.setString(2, dto.getId());
			
			su = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return su;
	}
}