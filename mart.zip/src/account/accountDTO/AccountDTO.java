package account.accountDTO;

import java.sql.Date;

public class AccountDTO {
	private int no;				//ȸ����ȣ
	private String id;			//���̵�
	private String password;	//��й�ȣ
	private String name;		//�̸�
	private int gender;			//����
	private String email;		//�̸���
	private String post;		//������ȣ
	private String address1;	//�ּ�
	private String address2;	//���ּ�
	private String tel1;		//010-1234-5678
	private String tel2;		//tel1 : 010, tel2 : 1234, tel3 : 5678 
	private String tel3;
	private int point;			//������
	private int code;			//������:0, ����:1
	private Date joindate;		//������
	
	//getter
	public int getNo() {
		return no;
	}
	public String getId() {
		return id;
	}
	public String getPassword() {
		return password;
	}
	public String getName() {
		return name;
	}
	public int getGender() {
		return gender;
	}
	public String getEmail() {
		return email;
	}
	public String getPost() {
		return post;
	}
	public String getAddress1() {
		return address1;
	}
	public String getAddress2() {
		return address2;
	}
	public String getTel1() {
		return tel1;
	}
	public String getTel2() {
		return tel2;
	}
	public String getTel3() {
		return tel3;
	}
	public int getPoint() {
		return point;
	}
	public int getCode() {
		return code;
	}
	public Date getJoindate() {
		return joindate;
	}
	
	//setter
	public void setNo(int no) {
		this.no = no;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setGender(int gender) {
		this.gender = gender;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public void setAddress1(String address) {
		this.address1 = address;
	}
	public void setAddress2(String address) {
		this.address2 = address;
	}
	public void setTel1(String tel1) {
		this.tel1 = tel1;
	}
	public void setTel2(String tel2) {
		this.tel2 = tel2;
	}
	public void setTel3(String tel3) {
		this.tel3 = tel3;
	}
	public void setPoint(int point) {
		this.point = point;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}
}
